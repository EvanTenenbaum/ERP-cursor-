# 🎯 **HEMP ERP COMPLETION ROADMAP: FAST VALIDATION PROTOCOL**

## **📋 MISSION STATEMENT**

Complete the remaining **52% of external AI recommendations** with **fast validation at every step** to ensure we actually build what we commit to.

**ACCOUNTABILITY PROTOCOL**: Each step has a **30-second validation test** that proves completion before moving to the next step.

---

## **🚨 CURRENT STATUS RECAP**

**COMPLETED (48%)**:
- ✅ Credential exposure removed
- ✅ Direct NextERP calls replaced
- ✅ Hardcoded passwords removed
- ✅ CORS properly configured
- ✅ Port consistency achieved

**REMAINING (52%)**:
- ❌ Auth verify endpoint missing
- ❌ Token verification on mount missing
- ❌ Rate limiting production-ready
- ❌ CSP headers fixed
- ❌ Dev components cleaned up
- ❌ Environment configuration completed

---

## **🎯 STEP-BY-STEP ROADMAP WITH FAST VALIDATION**

### **STEP 1: Create Auth Verify Endpoint**

**DELIVERABLE**: Backend endpoint `/api/auth/verify` that validates JWT tokens

**IMPLEMENTATION**:
```python
@auth_bp.route('/verify', methods=['GET'])
@jwt_required()
def verify_token():
    current_user = get_jwt_identity()
    return jsonify({
        'success': True, 
        'valid': True, 
        'user': {'username': current_user, 'role': 'admin'}
    })
```

**FAST VALIDATION (30 seconds)**:
```bash
# Test command:
curl -H "Authorization: Bearer <token>" http://localhost:5003/api/auth/verify

# Expected result:
{"success": true, "valid": true, "user": {"username": "admin", "role": "admin"}}

# Failure criteria:
- 404 error = endpoint not created
- 401 error = JWT validation not working
- 500 error = implementation bug
```

**CHECKPOINT**: ✅ Endpoint returns success with valid token, 401 with invalid token

---

### **STEP 2: Implement Frontend Token Verification**

**DELIVERABLE**: AuthProvider verifies token on mount instead of trusting localStorage

**IMPLEMENTATION**:
```javascript
useEffect(() => {
  (async () => {
    const token = localStorage.getItem('hemp_erp_token');
    if (!token) { setLoading(false); return; }
    
    try {
      const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/auth/verify`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      
      if (res.ok && data?.success && data?.valid) {
        setUser(data.user);
        setIsAuthenticated(true);
      } else {
        localStorage.removeItem('hemp_erp_token');
        localStorage.removeItem('hemp_erp_user');
        setIsAuthenticated(false);
      }
    } catch {
      localStorage.removeItem('hemp_erp_token');
      localStorage.removeItem('hemp_erp_user');
      setIsAuthenticated(false);
    } finally { 
      setLoading(false); 
    }
  })();
}, []);
```

**FAST VALIDATION (30 seconds)**:
```javascript
// Test in browser console:
localStorage.setItem('hemp_erp_token', 'invalid_token');
window.location.reload();

// Expected result:
- User should be logged out automatically
- No error in console
- Login form should appear

// Failure criteria:
- User appears logged in with invalid token
- Console errors during verification
- App crashes or hangs
```

**CHECKPOINT**: ✅ Invalid tokens automatically log user out, valid tokens keep user logged in

---

### **STEP 3: Fix Rate Limiting for Production**

**DELIVERABLE**: Rate limiter uses configurable storage (Redis for production)

**IMPLEMENTATION**:
```python
# In main.py
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"],
    storage_uri=os.getenv("RATELIMIT_STORAGE_URI", "memory://")
)
```

**FAST VALIDATION (30 seconds)**:
```bash
# Test command:
RATELIMIT_STORAGE_URI="redis://localhost:6379/0" python src/main.py

# Expected result:
- Server starts without errors
- Falls back to memory:// if Redis not available
- Rate limiting still works

# Failure criteria:
- Server crashes on startup
- Rate limiting stops working
- Environment variable ignored
```

**CHECKPOINT**: ✅ Rate limiter respects RATELIMIT_STORAGE_URI environment variable

---

### **STEP 4: Fix CSP Headers for JSON Responses**

**DELIVERABLE**: CSP headers only applied to HTML responses, not JSON

**IMPLEMENTATION**:
```python
@app.after_request
def add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    
    # Only add CSP for HTML responses
    if response.mimetype == "text/html":
        response.headers['Content-Security-Policy'] = "default-src 'self'"
    
    return response
```

**FAST VALIDATION (30 seconds)**:
```bash
# Test commands:
curl -I http://localhost:5003/api/auth/login  # JSON response
curl -I http://localhost:5003/  # HTML response

# Expected results:
JSON response: No Content-Security-Policy header
HTML response: Content-Security-Policy header present

# Failure criteria:
- JSON responses have CSP header
- HTML responses missing CSP header
- Other security headers missing
```

**CHECKPOINT**: ✅ JSON responses have no CSP header, HTML responses have CSP header

---

### **STEP 5: Clean Up Dev Components**

**DELIVERABLE**: Development-only components guarded or removed from production

**IMPLEMENTATION**:
```javascript
// In App.jsx or routing configuration
{import.meta.env.DEV && (
  <>
    <Route path="/real-foundation-test" element={<RealFoundationTest />} />
    <Route path="/foundation-test-fixed" element={<RealFoundationTestFixed />} />
    <Route path="/foundation-test-fallback" element={<FoundationTestWithFallback />} />
  </>
)}
```

**FAST VALIDATION (30 seconds)**:
```bash
# Test commands:
npm run build
npm run preview
# Navigate to: http://localhost:4173/real-foundation-test

# Expected result:
404 error - route not found in production build

# Failure criteria:
- Dev components accessible in production
- Build fails
- Routes still work in production
```

**CHECKPOINT**: ✅ Dev-only routes return 404 in production build, work in development

---

### **STEP 6: Complete Environment Configuration**

**DELIVERABLE**: All configuration values use environment variables

**IMPLEMENTATION**:
```python
# Update CORS configuration
allowed_origins = os.getenv('CORS_ORIGINS', 'http://localhost:5176,https://5179-ird2lfpa80ntx2pcjnd61-b4881cc0.manusvm.computer').split(',')

# Update rate limiting
default_limits = [
    os.getenv('RATE_LIMIT_DAY', '200 per day'),
    os.getenv('RATE_LIMIT_HOUR', '50 per hour')
]
```

**FAST VALIDATION (30 seconds)**:
```bash
# Test commands:
CORS_ORIGINS="http://example.com" python src/main.py
curl -H "Origin: http://example.com" http://localhost:5003/api/auth/login

# Expected result:
CORS allows http://example.com origin

# Failure criteria:
- Environment variable ignored
- CORS still uses hardcoded values
- Server fails to start
```

**CHECKPOINT**: ✅ CORS origins configurable via CORS_ORIGINS environment variable

---

## **🚀 EXECUTION PROTOCOL**

### **ATOMIC IMPLEMENTATION RULES**

1. **ONE STEP AT A TIME**: Complete each step fully before moving to next
2. **FAST VALIDATION REQUIRED**: Must pass 30-second test before proceeding
3. **NO SHORTCUTS**: If validation fails, fix the issue before continuing
4. **DOCUMENT FAILURES**: Record any issues encountered and solutions

### **VALIDATION CHECKPOINTS**

**After Each Step**:
- [ ] Implementation code written
- [ ] Fast validation test passed
- [ ] No regressions in existing functionality
- [ ] Ready to proceed to next step

**After All Steps**:
- [ ] All 6 validation tests pass
- [ ] Backend starts without errors
- [ ] Frontend authentication flow works
- [ ] Production build succeeds
- [ ] No dev components in production

---

## **📊 PROGRESS TRACKING**

### **COMPLETION MATRIX**

| Step | Component | Deliverable | Validation | Status |
|------|-----------|-------------|------------|--------|
| 1 | Backend | Auth verify endpoint | curl test | ⏳ Pending |
| 2 | Frontend | Token verification | browser test | ⏳ Pending |
| 3 | Backend | Rate limiting config | env var test | ⏳ Pending |
| 4 | Backend | CSP header fix | header test | ⏳ Pending |
| 5 | Frontend | Dev component cleanup | build test | ⏳ Pending |
| 6 | Backend | Environment config | config test | ⏳ Pending |

### **SUCCESS CRITERIA**

**INDIVIDUAL STEP SUCCESS**: ✅ Fast validation test passes in under 30 seconds
**OVERALL SUCCESS**: ✅ All 6 validation tests pass + no regressions
**PRODUCTION READINESS**: ✅ System handles multi-worker deployment + token validation

---

## **⚠️ FAILURE PROTOCOLS**

### **IF VALIDATION FAILS**

1. **STOP IMMEDIATELY**: Do not proceed to next step
2. **DIAGNOSE ISSUE**: Identify root cause of validation failure
3. **FIX IMPLEMENTATION**: Correct the code to meet validation criteria
4. **RE-TEST**: Run validation again until it passes
5. **DOCUMENT**: Record the issue and solution for future reference

### **IF REGRESSION DETECTED**

1. **ROLLBACK**: Revert the change that caused regression
2. **ANALYZE**: Understand why the change broke existing functionality
3. **REDESIGN**: Modify approach to avoid regression
4. **RE-IMPLEMENT**: Apply the fix without breaking existing features
5. **VALIDATE**: Ensure both new feature and existing functionality work

---

## **🎯 FINAL VALIDATION SUITE**

### **COMPREHENSIVE SYSTEM TEST**

**After completing all 6 steps, run this complete validation**:

```bash
# 1. Backend startup test
python src/main.py &
sleep 2

# 2. Authentication test
TOKEN=$(curl -s -X POST http://localhost:5003/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"HempERP_Admin_2025_Secure!@#$"}' \
  | jq -r '.access_token')

# 3. Token verification test
curl -H "Authorization: Bearer $TOKEN" http://localhost:5003/api/auth/verify

# 4. Invalid token test
curl -H "Authorization: Bearer invalid_token" http://localhost:5003/api/auth/verify

# 5. CSP header test
curl -I http://localhost:5003/api/auth/login | grep -i content-security-policy
curl -I http://localhost:5003/ | grep -i content-security-policy

# 6. Frontend build test
cd ../nexterp-hemp-frontend
npm run build
npm run preview &
sleep 2

# 7. Dev component test
curl -I http://localhost:4173/real-foundation-test

# 8. Environment config test
CORS_ORIGINS="http://test.com" python ../nexterp-proxy/src/main.py &
```

**EXPECTED RESULTS**:
- All curl commands return expected responses
- No 500 errors
- Dev components return 404 in production
- Environment variables respected

**SUCCESS CRITERIA**: All tests pass without manual intervention

---

## **📈 ACCOUNTABILITY MEASURES**

### **PROGRESS REPORTING**

**After Each Step**: Report validation result (PASS/FAIL) with evidence
**After All Steps**: Provide complete test suite results
**If Issues Found**: Document problem, solution, and time to resolve

### **QUALITY GATES**

**NO STEP SKIPPING**: Each validation must pass before proceeding
**NO PARTIAL IMPLEMENTATION**: Complete the deliverable fully or don't start
**NO REGRESSION TOLERANCE**: Fix any broken existing functionality immediately

### **COMPLETION DEFINITION**

**DONE = ALL 6 VALIDATIONS PASS + NO REGRESSIONS + COMPREHENSIVE TEST SUITE PASSES**

---

**This roadmap ensures we actually deliver the remaining 52% of external AI recommendations with proof at every step.**

