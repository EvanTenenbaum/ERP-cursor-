# ERPNext Web UI Loading Issues - Research Findings

## Problem: Blank/Broken Web Interface
- Backend services running but web interface shows blank page or missing CSS/JS
- Common on AWS Lightsail and EC2 instances
- Affects login page and general UI functionality

## Root Causes Identified:

### 1. Memory Issues (Most Common)
- **Problem**: 1GB RAM insufficient for bench build process
- **Solution**: Use 2GB+ instances OR increase Node.js memory limit
- **Command**: `export NODE_OPTIONS="--max-old-space-size=8192"`
- **Then**: `bench build`

### 2. Permission Issues
- **Problem**: Frappe directory lacks proper permissions for web server access
- **Solution**: `chmod o+x /home/frappe` (adjust path as needed)
- **Root Cause**: Incorrect user setup during installation

### 3. Missing Asset Files
- **Problem**: CSS/JS files not generated or accessible (404 errors)
- **Check**: Look for files in `sites/assets/js/` and `sites/assets/css/`
- **Solution**: `bench build` to regenerate assets

### 4. Nginx Configuration
- **Problem**: Web server not properly configured to serve static files
- **Solution**: Check nginx config, may need `bench setup nginx`

### 5. Site Configuration
- **Problem**: Wrong site being served or currentsite.txt issues
- **Solution**: `bench use [site-name]` and restart services

## Diagnostic Steps:
1. Check browser console for 404 errors on CSS/JS files
2. Verify asset files exist in sites/assets/
3. Check frappe directory permissions
4. Verify available memory during build process
5. Check nginx configuration

## Quick Fix Sequence:
1. `export NODE_OPTIONS="--max-old-space-size=8192"`
2. `bench build`
3. `chmod o+x /home/frappe`
4. `bench restart`

