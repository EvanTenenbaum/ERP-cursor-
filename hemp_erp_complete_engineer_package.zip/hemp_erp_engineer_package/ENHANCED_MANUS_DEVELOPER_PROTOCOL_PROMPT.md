# ENHANCED MANUS DEVELOPER PROTOCOL PROMPT

## 📌 **MANDATORY PROTOCOL FOR ALL DEVELOPMENT TASKS**

Apply MANUS DEVELOPER PROTOCOL with RELIABILITY FRAMEWORK: Use templates from /home/ubuntu/templates/, follow DECONSTRUCTION DISCIPLINE (UNDERSTAND→ANALYZE→REASON→SYNTHESIZE→CONCLUDE), apply INTEGRATION OVER DUPLICATION, validate with SYSTEMATIC FRAMEWORK, deliver PRODUCTION-READY implementation with evidence-based validation.

---

## 🚨 **RELIABILITY FRAMEWORK (MANDATORY)**

### **CRITICAL RELIABILITY RULES**
1. **NO DEMO DATA ALLOWED** - All data must come from real NextERP API
2. **END-TO-END TESTING REQUIRED** - Test complete user workflows, not isolated components
3. **EVIDENCE-BASED VALIDATION** - Provide proof before claiming completion
4. **NO PARTIAL COMPLETION CLAIMS** - "Working" means full CRUD operations validated

### **MANDATORY VALIDATION GATES**

**Gate 1: Real API Integration**
- ✅ Backend API working via curl
- ✅ Frontend can call backend API successfully
- ✅ **End-to-end user workflow tested and documented**
- ❌ **ZERO DEMO DATA - Real NextERP integration only**

**Gate 2: Complete CRUD Operations**
- ✅ Create: Real document creation in NextERP with returned document ID
- ✅ Read: Real data retrieval and display in frontend
- ✅ Update: Real document modification in NextERP
- ✅ Delete: Real document removal from NextERP
- ❌ **NO PARTIAL IMPLEMENTATIONS ALLOWED**

**Gate 3: Multi-User Validation**
- ✅ Minimum 2 concurrent users tested
- ✅ Authentication state isolation verified
- ✅ Performance under concurrent load validated
- ❌ **NO SINGLE-USER TESTING ONLY**

### **REQUIRED EVIDENCE FOR "COMPLETE" CLAIMS**
1. **Screen Recording**: Complete user workflow from login to task completion
2. **NextERP Document IDs**: Real document creation/modification proof
3. **Multi-User Test Results**: Concurrent user operation validation
4. **Error Handling**: Network failures, invalid data, authentication issues tested

### **BANNED PRACTICES**
- ❌ **Demo data fallbacks** when real integration fails
- ❌ **Claiming "working" based on curl tests only**
- ❌ **Frontend-only testing with mock data**
- ❌ **Partial CRUD implementations presented as complete**
- ❌ **Single-user testing presented as production-ready**

---

## 🎯 **ENHANCED DECONSTRUCTION DISCIPLINE**

**UNDERSTAND**: Restate requirements and identify what "complete" means
- What specific user workflow must work end-to-end?
- What real NextERP documents must be created/modified?
- What evidence will prove the feature actually works?

**ANALYZE**: Identify real integration points and validation requirements
- Which NextERP DocTypes are involved?
- What are the complete CRUD operations needed?
- How will multi-user scenarios be tested?

**REASON**: Map complete workflow and evidence collection
- What is the end-to-end user journey?
- Where are the potential failure points?
- What proof will demonstrate real functionality?

**SYNTHESIZE**: Plan implementation with validation checkpoints
- How will each validation gate be satisfied?
- What evidence will be collected at each step?
- How will real NextERP integration be verified?

**CONCLUDE**: Confirm evidence requirements before implementation
- What specific proof will demonstrate completion?
- How will multi-user testing be conducted?
- What constitutes acceptable evidence for the user?

---

## 🔧 **SYSTEMATIC FRAMEWORK WITH ACCOUNTABILITY**

### **Development Process**
1. **Foundation Validation**: Prove existing components work end-to-end
2. **Real Integration First**: Connect to actual NextERP before building UI
3. **Complete CRUD Implementation**: All operations working before claiming success
4. **Multi-User Testing**: Concurrent user validation required
5. **Evidence Documentation**: Screen recordings and proof collection
6. **Independent Validation**: External verification before "complete" claims

### **Quality Gates**
- **No progression to next feature** until current feature passes all validation gates
- **No "working" claims** without end-to-end user workflow proof
- **No "complete" claims** without full CRUD operations and multi-user testing
- **No "production-ready" claims** without independent validation

### **Accountability Measures**
- **Transparent Testing**: Live demonstration of all claimed functionality
- **Real User Validation**: Actual business user acceptance testing when possible
- **Production Deployment**: Staging environment validation required
- **Performance Documentation**: Response times and system limits documented

---

## 💡 **COOKIE-CUTTER TEMPLATES WITH VALIDATION**

### **Template Usage Requirements**
- **CORS Configuration**: Must be tested with actual frontend-backend communication
- **NextERP Integration**: Must use real API endpoints, not demo data
- **Authentication Flow**: Must be validated across multiple user sessions
- **Error Handling**: Must be tested with actual failure scenarios

### **Template Validation Checklist**
- ✅ Template applied correctly
- ✅ Real data integration working
- ✅ End-to-end workflow tested
- ✅ Multi-user scenario validated
- ✅ Error conditions handled
- ✅ Evidence documented

---

## 🚨 **FAILURE PREVENTION PROTOCOL**

### **Before Starting Any Task**
1. **Review Previous Failures**: What went wrong in similar implementations?
2. **Define Success Criteria**: What specific evidence will prove completion?
3. **Plan Validation Strategy**: How will end-to-end functionality be tested?
4. **Identify Risk Points**: Where are integration failures likely to occur?

### **During Implementation**
1. **Validate Each Step**: Test integration points immediately
2. **Document Evidence**: Collect proof of functionality as you build
3. **Test Real Scenarios**: Use actual data and user workflows
4. **Avoid Demo Data**: Never fall back to mock data when real integration fails

### **Before Claiming Completion**
1. **End-to-End Test**: Complete user workflow from start to finish
2. **Multi-User Validation**: Test with concurrent users
3. **Evidence Collection**: Screen recording and document ID proof
4. **Independent Review**: External validation of all claims

---

## 📋 **TASK EXECUTION CHECKLIST**

**Before Implementation**:
- [ ] Success criteria defined with specific evidence requirements
- [ ] End-to-end workflow mapped out completely
- [ ] Real NextERP integration points identified
- [ ] Multi-user testing strategy planned

**During Implementation**:
- [ ] Real API integration tested at each step
- [ ] No demo data used anywhere in the system
- [ ] End-to-end workflow tested continuously
- [ ] Evidence collected throughout development

**Before Completion Claims**:
- [ ] Complete CRUD operations validated
- [ ] Multi-user concurrent testing completed
- [ ] Screen recording of full user workflow
- [ ] Real NextERP document IDs documented
- [ ] Independent validation requested

**Final Validation**:
- [ ] All validation gates passed
- [ ] Evidence package prepared
- [ ] Independent review completed
- [ ] Production deployment readiness confirmed

---

## 💬 **COMMUNICATION PROTOCOL**

### **Progress Reporting**
- **No "working" claims** without end-to-end proof
- **No "complete" claims** without full validation
- **Evidence-first communication**: Show proof, then explain
- **Honest failure reporting**: Immediate notification of integration issues

### **Completion Criteria**
- **"Working"** = End-to-end user workflow with real data
- **"Complete"** = Full CRUD operations with multi-user validation
- **"Production-ready"** = Independent validation and evidence package

---

## 🎯 **BOTTOM LINE**

**Every task must pass ALL validation gates with documented evidence before any completion claims. No exceptions. No demo data. No partial implementations. Real integration or honest failure reporting only.**

**Use this protocol for every development task to ensure reliability and build confidence through evidence-based validation.**

