import os
import sys
from dotenv import load_dotenv

# Load environment variables first
load_dotenv()

# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, request, g
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import logging
from datetime import datetime
import json
# Import available routes only
from src.routes.nexterp import nexterp_bp
from src.routes.auth import auth_bp
# Note: user_bp and db imports removed until implemented

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))

# Configuration from environment variables
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', 'fallback-secret-key')
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'fallback-jwt-secret')
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = int(os.getenv('JWT_ACCESS_TOKEN_EXPIRES', 3600))

# Initialize JWT
jwt = JWTManager(app)

# Initialize rate limiter
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"],
    storage_uri="memory://"
)

# Configure audit logging
logging.basicConfig(
    level=getattr(logging, os.getenv('LOG_LEVEL', 'INFO')),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
audit_logger = logging.getLogger('hemp_erp_audit')

# Audit logging middleware
@app.before_request
def log_request():
    g.start_time = datetime.utcnow()
    
    # Log authentication attempts and API access
    if request.endpoint in ['auth.login', 'nexterp.foundation_test', 'nexterp.get_hemp_clients']:
        audit_data = {
            'timestamp': g.start_time.isoformat(),
            'ip_address': get_remote_address(),
            'endpoint': request.endpoint,
            'method': request.method,
            'user_agent': request.headers.get('User-Agent', 'Unknown'),
            'path': request.path
        }
        audit_logger.info(f"API_ACCESS: {json.dumps(audit_data)}")

@app.after_request
def add_security_headers(response):
    # Add security headers
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    return response

@app.after_request
def log_response(response):
    if hasattr(g, 'start_time'):
        duration = (datetime.utcnow() - g.start_time).total_seconds()
        
        # Log authentication results and errors
        if request.endpoint in ['auth.login', 'nexterp.foundation_test', 'nexterp.get_hemp_clients']:
            audit_data = {
                'timestamp': datetime.utcnow().isoformat(),
                'ip_address': get_remote_address(),
                'endpoint': request.endpoint,
                'status_code': response.status_code,
                'duration_seconds': duration,
                'success': response.status_code < 400
            }
            
            if request.endpoint == 'auth.login':
                if response.status_code == 200:
                    audit_logger.info(f"LOGIN_SUCCESS: {json.dumps(audit_data)}")
                else:
                    audit_logger.warning(f"LOGIN_FAILED: {json.dumps(audit_data)}")
            else:
                audit_logger.info(f"API_RESPONSE: {json.dumps(audit_data)}")
    
    return response

# Configure CORS with specific origins and proper settings
allowed_origins = os.getenv('ALLOWED_ORIGINS', 'http://localhost:5176,https://5179-ird2lfpa80ntx2pcjnd61-b4881cc0.manusvm.computer').split(',')
CORS(app, 
     resources={r"/api/*": {"origins": allowed_origins}}, 
     supports_credentials=True,
     allow_headers=['Content-Type', 'Authorization'],
     methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])

# Register available blueprints only
app.register_blueprint(nexterp_bp, url_prefix='/api/nexterp')
app.register_blueprint(auth_bp, url_prefix='/api/auth')

# Database configuration commented out until user model is implemented
# app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# db.init_app(app)
# with app.app_context():
#     db.create_all()

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404


if __name__ == '__main__':
    # Use PORT environment variable, default to 5002 for development
    port = int(os.getenv('PORT', '5002'))
    app.run(host='0.0.0.0', port=port, debug=False)
