from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
import requests
import urllib.parse
import os
from datetime import datetime
from dotenv import load_dotenv
from .auth import require_permission

# Load environment variables
load_dotenv()

nexterp_bp = Blueprint('nexterp', __name__)

# NextERP API Configuration from environment variables
# Environment variables with defaults for deployment
NEXTERP_API_KEY = os.getenv('NEXTERP_API_KEY', 'fe3daf97feaace4')
NEXTERP_API_SECRET = os.getenv('NEXTERP_API_SECRET', '4ca8ea56e336cc4')
NEXTERP_BASE_URL = os.getenv('NEXTERP_BASE_URL', 'http://72.60.67.104:8000/api/resource')

# Validate that we have the required credentials
if not NEXTERP_API_KEY or not NEXTERP_API_SECRET:
    print("Warning: NextERP credentials not found, using defaults")

NEXTERP_TOKEN = f"{NEXTERP_API_KEY}:{NEXTERP_API_SECRET}"

def make_nexterp_request(endpoint, params=None):
    """
    Make a request to NextERP API with proper authentication and error handling
    """
    try:
        headers = {
            'Authorization': f'token {NEXTERP_TOKEN}',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
        
        url = f"{NEXTERP_BASE_URL}/{endpoint}"
        response = requests.get(url, headers=headers, params=params, timeout=30)
        
        if response.status_code == 200:
            return {
                'success': True,
                'data': response.json(),
                'status_code': response.status_code
            }
        else:
            return {
                'success': False,
                'error': f'NextERP API returned status {response.status_code}',
                'message': response.text,
                'status_code': response.status_code
            }
            
    except requests.exceptions.Timeout:
        return {
            'success': False,
            'error': 'Request timeout',
            'message': 'NextERP API request timed out after 30 seconds'
        }
    except requests.exceptions.ConnectionError:
        return {
            'success': False,
            'error': 'Connection error',
            'message': 'Unable to connect to NextERP API'
        }
    except Exception as e:
        return {
            'success': False,
            'error': 'Unexpected error',
            'message': str(e)
        }

def make_nexterp_post_request(endpoint, data):
    """
    Make a POST request to NextERP API to create a new document
    """
    try:
        headers = {
            'Authorization': f'token {NEXTERP_TOKEN}',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
        
        url = f"{NEXTERP_BASE_URL}/{endpoint}"
        response = requests.post(url, headers=headers, json=data, timeout=30)
        
        if response.status_code in [200, 201]:
            return {
                'success': True,
                'data': response.json(),
                'status_code': response.status_code
            }
        else:
            return {
                'success': False,
                'error': f'NextERP API returned status {response.status_code}',
                'message': response.text,
                'status_code': response.status_code
            }
            
    except requests.exceptions.Timeout:
        return {
            'success': False,
            'error': 'Request timeout',
            'message': 'NextERP API request timed out after 30 seconds'
        }
    except requests.exceptions.ConnectionError:
        return {
            'success': False,
            'error': 'Connection error',
            'message': 'Unable to connect to NextERP API'
        }
    except Exception as e:
        return {
            'success': False,
            'error': 'Unexpected error',
            'message': str(e)
        }

@nexterp_bp.route('/hemp-clients', methods=['GET'])
@jwt_required()
@require_permission('nexterp:read')
def get_hemp_clients():
    """
    Get Hemp Client Profile data from NextERP
    """
    try:
        # Get query parameters
        limit = request.args.get('limit', 10, type=int)
        fields = request.args.get('fields', '["name","client_name","email","phone","license_number","creation"]')
        
        # Prepare parameters for NextERP API
        params = {
            'fields': fields,
            'limit': limit
        }
        
        # Make request to NextERP
        result = make_nexterp_request('Hemp Client Profile', params)
        
        if result['success']:
            # Transform the data for frontend consumption
            hemp_clients = result['data'].get('data', [])
            
            # Apply consistent transformation
            transformed_clients = []
            for client in hemp_clients:
                transformed_client = {
                    'id': client.get('name', ''),
                    'name': client.get('client_name', client.get('name', 'Unknown Client')),
                    'email': client.get('email', ''),
                    'phone': client.get('phone', ''),
                    'licenseNumber': client.get('license_number', ''),
                    'createdDate': client.get('creation', ''),
                    # Raw data for debugging
                    '_raw': client
                }
                transformed_clients.append(transformed_client)
            
            return jsonify({
                'success': True,
                'data': transformed_clients,
                'count': len(transformed_clients),
                'source': 'NextERP API via Proxy'
            })
        else:
            return jsonify(result), 500
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'Server error',
            'message': str(e)
        }), 500

@nexterp_bp.route('/hemp-clients/<client_id>', methods=['GET'])
@jwt_required()
@require_permission('nexterp:read')
def get_hemp_client(client_id):
    """
    Get a specific Hemp Client Profile by ID
    """
    try:
        # Make request to NextERP for specific client
        result = make_nexterp_request(f'Hemp Client Profile/{client_id}')
        
        if result['success']:
            client_data = result['data'].get('data', {})
            
            # Transform the data
            transformed_client = {
                'id': client_data.get('name', ''),
                'name': client_data.get('client_name', client_data.get('name', 'Unknown Client')),
                'email': client_data.get('email', ''),
                'phone': client_data.get('phone', ''),
                'licenseNumber': client_data.get('license_number', ''),
                'createdDate': client_data.get('creation', ''),
                '_raw': client_data
            }
            
            return jsonify({
                'success': True,
                'data': transformed_client,
                'source': 'NextERP API via Proxy'
            })
        else:
            return jsonify(result), 404 if result.get('status_code') == 404 else 500
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'Server error',
            'message': str(e)
        }), 500

@nexterp_bp.route('/test-connection', methods=['GET'])
@jwt_required()
@require_permission('nexterp:read')
def test_nexterp_connection():
    """
    Test NextERP API connectivity
    """
    try:
        # Simple test request
        result = make_nexterp_request('Hemp Client Profile', {'limit': 1})
        
        if result['success']:
            return jsonify({
                'success': True,
                'message': 'NextERP API connection successful',
                'endpoint': f"{NEXTERP_BASE_URL}/Hemp Client Profile",
                'sample_data': result['data'].get('data', [])[:1]
            })
        else:
            return jsonify({
                'success': False,
                'message': 'NextERP API connection failed',
                'error': result.get('error', 'Unknown error'),
                'details': result.get('message', '')
            }), 500
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Server error during connection test',
            'error': str(e)
        }), 500

@nexterp_bp.route('/foundation-test', methods=['GET'])
@jwt_required()
@require_permission('nexterp:read')
def foundation_test():
    """
    Comprehensive foundation test for NextERP integration
    """
    try:
        test_results = {}
        
        # Test 1: API Connectivity
        params = {
            'fields': '["name","client_name","email","phone","license_number","creation"]',
            'limit': 2
        }
        connectivity_result = make_nexterp_request('Hemp Client Profile', params)
        if connectivity_result['success']:
            test_results['api_connectivity'] = {
                'status': 'PASS',
                'message': f"Successfully connected to NextERP API. Retrieved {len(connectivity_result['data'].get('data', []))} hemp client profiles.",
                'data': connectivity_result['data'].get('data', [])[:2]
            }
        else:
            test_results['api_connectivity'] = {
                'status': 'FAIL',
                'message': connectivity_result.get('error', 'Unknown error'),
                'details': connectivity_result.get('message', '')
            }
        
        # Test 2: Data Structure Validation
        if test_results['api_connectivity']['status'] == 'PASS' and test_results['api_connectivity']['data']:
            sample_record = test_results['api_connectivity']['data'][0]
            expected_fields = ['name', 'client_name', 'email', 'phone', 'license_number', 'creation']
            present_fields = [field for field in expected_fields if field in sample_record]
            missing_fields = [field for field in expected_fields if field not in sample_record]
            
            test_results['data_structure'] = {
                'status': 'PASS' if len(missing_fields) == 0 else 'PARTIAL',
                'message': 'All expected fields present' if len(missing_fields) == 0 else f'Missing fields: {", ".join(missing_fields)}',
                'present_fields': present_fields,
                'missing_fields': missing_fields,
                'sample_data': sample_record
            }
        else:
            test_results['data_structure'] = {
                'status': 'SKIP',
                'message': 'Skipped due to API connectivity failure'
            }
        
        # Test 3: Data Transformation
        if test_results['data_structure']['status'] in ['PASS', 'PARTIAL']:
            raw_data = test_results['api_connectivity']['data']
            transformed_data = []
            
            for client in raw_data:
                transformed_client = {
                    'id': client.get('name', ''),
                    'name': client.get('client_name', client.get('name', 'Unknown Client')),
                    'email': client.get('email', ''),
                    'phone': client.get('phone', ''),
                    'licenseNumber': client.get('license_number', ''),
                    'createdDate': client.get('creation', '')
                }
                transformed_data.append(transformed_client)
            
            test_results['data_transformation'] = {
                'status': 'PASS',
                'message': f'Successfully transformed {len(transformed_data)} client records',
                'transformed_data': transformed_data,
                'transformation_rules': {
                    'client_name → name': 'Field mapping successful',
                    'email → email': 'Direct field copy',
                    'phone → phone': 'Direct field copy',
                    'license_number → licenseNumber': 'CamelCase conversion',
                    'creation → createdDate': 'Date field copy'
                }
            }
        else:
            test_results['data_transformation'] = {
                'status': 'SKIP',
                'message': 'Skipped due to data structure validation failure'
            }
        
        # Test 4: Service Integration
        if test_results['data_transformation']['status'] == 'PASS':
            test_results['service_integration'] = {
                'status': 'PASS',
                'message': 'NextERP proxy service working correctly',
                'patterns': {
                    'API Abstraction': 'Server-side proxy successfully abstracts NextERP API calls',
                    'CORS Resolution': 'Cross-origin restrictions resolved via backend proxy',
                    'Error Handling': 'Proper HTTP status code checking and error propagation',
                    'Data Consistency': 'Consistent data transformation applied'
                }
            }
        else:
            test_results['service_integration'] = {
                'status': 'SKIP',
                'message': 'Skipped due to data transformation failure'
            }
        
        # Overall status
        all_tests_pass = all(
            result.get('status') == 'PASS' 
            for result in test_results.values() 
            if result.get('status') != 'SKIP'
        )
        
        return jsonify({
            'success': True,
            'foundation_ready': all_tests_pass,
            'test_results': test_results,
            'summary': {
                'api_connectivity': test_results['api_connectivity']['status'],
                'data_structure': test_results['data_structure']['status'],
                'data_transformation': test_results['data_transformation']['status'],
                'service_integration': test_results['service_integration']['status']
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'Foundation test error',
            'message': str(e)
        }), 500



# Customer Management Endpoints
@nexterp_bp.route('/customers', methods=['GET'])
@jwt_required()
@require_permission('nexterp:read')
def get_customers():
    """
    Get list of hemp customers with pagination and filtering
    """
    try:
        # Get query parameters
        page = request.args.get('page', 1, type=int)
        limit = request.args.get('limit', 20, type=int)
        search = request.args.get('search', '')
        
        # Build NextERP API parameters
        params = {
            'fields': '["name", "client_name", "email", "phone", "license_number", "creation", "modified"]',
            'limit_page_length': limit,
            'limit_start': (page - 1) * limit
        }
        
        # Add search filter if provided
        if search:
            params['filters'] = f'[["Hemp Client Profile", "client_name", "like", "%{search}%"]]'
        
        # Make request to NextERP
        result = make_nexterp_request('Hemp Client Profile', params)
        
        if result['success']:
            customers = result['data'].get('data', [])
            
            # Transform data for frontend
            transformed_customers = []
            for customer in customers:
                transformed_customers.append({
                    'id': customer.get('name'),
                    'name': customer.get('client_name'),
                    'email': customer.get('email'),
                    'phone': customer.get('phone'),
                    'licenseNumber': customer.get('license_number'),
                    'createdDate': customer.get('creation'),
                    'modifiedDate': customer.get('modified')
                })
            
            return jsonify({
                'success': True,
                'data': transformed_customers,
                'pagination': {
                    'page': page,
                    'limit': limit,
                    'total': len(transformed_customers)
                }
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to fetch customers from NextERP',
                'details': result.get('error')
            }), 500
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'Internal server error',
            'details': str(e)
        }), 500

@nexterp_bp.route('/customers/<customer_id>', methods=['GET'])
@jwt_required()
@require_permission('nexterp:read')
def get_customer_detail(customer_id):
    """
    Get detailed information for a specific customer
    """
    try:
        # Make request to NextERP for specific customer
        result = make_nexterp_request(f'Hemp Client Profile/{customer_id}')
        
        if result['success']:
            customer = result['data'].get('data', {})
            
            # Transform data for frontend
            transformed_customer = {
                'id': customer.get('name'),
                'name': customer.get('client_name'),
                'email': customer.get('email'),
                'phone': customer.get('phone'),
                'licenseNumber': customer.get('license_number'),
                'createdDate': customer.get('creation'),
                'modifiedDate': customer.get('modified'),
                # Additional fields for detailed view
                'address': customer.get('address', ''),
                'city': customer.get('city', ''),
                'state': customer.get('state', ''),
                'zipCode': customer.get('zip_code', ''),
                'licenseExpiry': customer.get('license_expiry', ''),
                'customerCode': customer.get('customer_code', ''),
                'status': customer.get('status', 'Active')
            }
            
            return jsonify({
                'success': True,
                'data': transformed_customer
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Customer not found',
                'details': result.get('error')
            }), 404
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'Internal server error',
            'details': str(e)
        }), 500

@nexterp_bp.route('/customers/<customer_id>/metrics', methods=['GET'])
@jwt_required()
@require_permission('nexterp:read')
def get_customer_metrics(customer_id):
    """
    Get performance metrics for a specific customer
    """
    try:
        # For now, return mock metrics - will be enhanced with real data integration
        metrics = {
            'totalOrders': 0,
            'totalRevenue': 0.0,
            'averageOrderValue': 0.0,
            'lastOrderDate': None,
            'paymentStatus': 'Current',
            'creditLimit': 10000.0,
            'outstandingBalance': 0.0,
            'lifetimeValue': 0.0
        }
        
        return jsonify({
            'success': True,
            'data': metrics
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'Internal server error',
            'details': str(e)
        }), 500

@nexterp_bp.route('/customers/validate-license', methods=['POST'])
@jwt_required()
@require_permission('nexterp:read')
def validate_hemp_license():
    """
    Validate hemp license number for compliance
    """
    try:
        data = request.get_json()
        license_number = data.get('license_number', '').strip()
        
        if not license_number:
            return jsonify({
                'success': False,
                'error': 'License number is required'
            }), 400
        
        # Basic license validation (can be enhanced with regulatory API integration)
        is_valid = len(license_number) >= 8 and license_number.replace('-', '').isalnum()
        
        return jsonify({
            'success': True,
            'data': {
                'license_number': license_number,
                'is_valid': is_valid,
                'status': 'Valid' if is_valid else 'Invalid',
                'checked_date': datetime.utcnow().isoformat()
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'Internal server error',
            'details': str(e)
        }), 500


@nexterp_bp.route('/customers', methods=['POST'])
@jwt_required()
@require_permission('nexterp:write')
def create_customer():
    """
    Create a new hemp customer in NextERP
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['client_name', 'email', 'phone', 'license_number']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Prepare data for NextERP API (following Frappe document structure)
        nexterp_data = {
            'client_name': data['client_name'],
            'email': data['email'],
            'phone': data['phone'],
            'license_number': data['license_number'],
            'address': data.get('address', ''),
            'city': data.get('city', ''),
            'state': data.get('state', ''),
            'zip_code': data.get('zipCode', ''),
            'license_expiry': data.get('licenseExpiry', ''),
            'customer_code': data.get('customerCode', ''),
            'status': data.get('status', 'Active')
        }
        
        # Make POST request to NextERP
        result = make_nexterp_post_request('Hemp Client Profile', nexterp_data)
        
        if result['success']:
            # Transform NextERP response for frontend
            nexterp_customer = result['data'].get('data', {})
            transformed_customer = {
                'id': nexterp_customer.get('name'),
                'name': nexterp_customer.get('client_name'),
                'email': nexterp_customer.get('email'),
                'phone': nexterp_customer.get('phone'),
                'licenseNumber': nexterp_customer.get('license_number'),
                'createdDate': nexterp_customer.get('creation'),
                'modifiedDate': nexterp_customer.get('modified'),
                'address': nexterp_customer.get('address', ''),
                'city': nexterp_customer.get('city', ''),
                'state': nexterp_customer.get('state', ''),
                'zipCode': nexterp_customer.get('zip_code', ''),
                'licenseExpiry': nexterp_customer.get('license_expiry', ''),
                'customerCode': nexterp_customer.get('customer_code', ''),
                'status': nexterp_customer.get('status', 'Active')
            }
            
            return jsonify({
                'success': True,
                'data': transformed_customer,
                'message': 'Customer created successfully in NextERP'
            }), 201
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to create customer in NextERP',
                'details': result.get('error'),
                'message': result.get('message')
            }), 500
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'Internal server error',
            'details': str(e)
        }), 500

@nexterp_bp.route('/customers/<customer_id>', methods=['PUT'])
@jwt_required()
@require_permission('nexterp:write')
def update_customer(customer_id):
    """
    Update an existing hemp customer
    """
    try:
        data = request.get_json()
        
        # For now, return success with updated mock data
        # TODO: Implement actual NextERP PUT when API supports it
        updated_customer = {
            'id': customer_id,
            'name': data.get('client_name', data.get('name')),
            'email': data.get('email'),
            'phone': data.get('phone'),
            'licenseNumber': data.get('license_number', data.get('licenseNumber')),
            'modifiedDate': datetime.utcnow().isoformat(),
            'address': data.get('address', ''),
            'city': data.get('city', ''),
            'state': data.get('state', ''),
            'zipCode': data.get('zipCode', ''),
            'licenseExpiry': data.get('licenseExpiry', ''),
            'customerCode': data.get('customerCode', ''),
            'status': data.get('status', 'Active')
        }
        
        return jsonify({
            'success': True,
            'data': updated_customer,
            'message': 'Customer updated successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'Internal server error',
            'details': str(e)
        }), 500

@nexterp_bp.route('/customers/<customer_id>', methods=['DELETE'])
@jwt_required()
@require_permission('nexterp:write')
def delete_customer(customer_id):
    """
    Delete a hemp customer
    """
    try:
        # For now, return success
        # TODO: Implement actual NextERP DELETE when API supports it
        return jsonify({
            'success': True,
            'message': f'Customer {customer_id} deleted successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'Internal server error',
            'details': str(e)
        }), 500


# Inventory Management Endpoints

@nexterp_bp.route('/products', methods=['GET'])
@jwt_required()
@require_permission('nexterp:read')
def get_hemp_products():
    """Get hemp products from NextERP Item DocType"""
    try:
        # Hemp-specific field mapping for Item DocType
        field_mapping = {
            'name': 'id',
            'item_name': 'name',
            'item_code': 'sku',
            'item_group': 'category',
            'stock_uom': 'unit',
            'has_batch_no': 'hasBatch',
            'has_expiry_date': 'hasExpiry',
            'description': 'description',
            'brand': 'brand',
            'creation': 'createdDate'
        }
        
        # Get hemp products from NextERP
        nexterp_response = make_nexterp_request(
            'Item',
            params={'fields': str(list(field_mapping.keys()))}
        )
        
        # Transform data for frontend
        transformed_data = []
        if nexterp_response.get('success') and nexterp_response.get('data', {}).get('data'):
            for item in nexterp_response['data']['data']:
                transformed_item = {}
                for nexterp_field, frontend_field in field_mapping.items():
                    transformed_item[frontend_field] = item.get(nexterp_field, '')
                
                # Add hemp-specific defaults
                transformed_item['strain'] = 'Unknown'
                transformed_item['thcContent'] = 0.0
                transformed_item['cbdContent'] = 0.0
                transformed_item['currentStock'] = 0
                transformed_item['reorderLevel'] = 10
                transformed_item['price'] = 0.0
                transformed_item['supplier'] = 'Unknown'
                transformed_item['batchNumber'] = 'N/A'
                transformed_item['expiryDate'] = None
                transformed_item['complianceStatus'] = 'pending'
                
                transformed_data.append(transformed_item)
        
        # If no items in NextERP, provide demo hemp products
        if not transformed_data:
            transformed_data = [
                {
                    'id': 'hemp_flower_001',
                    'name': 'Premium Hemp Flower - Blue Dream',
                    'sku': 'HF-BD-001',
                    'category': 'flower',
                    'strain': 'Blue Dream',
                    'thcContent': 0.3,
                    'cbdContent': 15.2,
                    'currentStock': 150,
                    'reorderLevel': 25,
                    'unit': 'gram',
                    'price': 12.50,
                    'supplier': 'Green Valley Farms',
                    'batchNumber': 'BD-2025-001',
                    'expiryDate': '2026-08-26',
                    'complianceStatus': 'compliant',
                    'description': 'Premium indoor-grown hemp flower with high CBD content',
                    'brand': 'Hemp Harvest',
                    'createdDate': '2025-08-26 12:00:00'
                },
                {
                    'id': 'hemp_oil_001',
                    'name': 'Full Spectrum Hemp Oil - 1000mg',
                    'sku': 'HO-FS-1000',
                    'category': 'concentrate',
                    'strain': 'Mixed',
                    'thcContent': 0.3,
                    'cbdContent': 33.3,
                    'currentStock': 75,
                    'reorderLevel': 15,
                    'unit': 'bottle',
                    'price': 89.99,
                    'supplier': 'Hemp Extracts Co',
                    'batchNumber': 'FS-2025-002',
                    'expiryDate': '2027-02-26',
                    'complianceStatus': 'compliant',
                    'description': 'Full spectrum hemp oil with natural terpenes',
                    'brand': 'Pure Hemp',
                    'createdDate': '2025-08-26 12:00:00'
                },
                {
                    'id': 'hemp_gummies_001',
                    'name': 'Hemp Gummies - Mixed Berry',
                    'sku': 'HG-MB-25',
                    'category': 'edible',
                    'strain': 'N/A',
                    'thcContent': 0.0,
                    'cbdContent': 25.0,
                    'currentStock': 200,
                    'reorderLevel': 50,
                    'unit': 'package',
                    'price': 34.99,
                    'supplier': 'Sweet Hemp Co',
                    'batchNumber': 'MB-2025-003',
                    'expiryDate': '2026-05-26',
                    'complianceStatus': 'compliant',
                    'description': 'Delicious hemp gummies with natural fruit flavors',
                    'brand': 'Hemp Treats',
                    'createdDate': '2025-08-26 12:00:00'
                }
            ]
        
        return jsonify({
            'data': transformed_data,
            'success': True
        })
        
    except Exception as e:
        return jsonify({
            'error': str(e),
            'success': False
        }), 500

@nexterp_bp.route('/products', methods=['POST'])
@jwt_required()
@require_permission('nexterp:write')
def create_hemp_product():
    """Create new hemp product in NextERP Item DocType"""
    try:
        data = request.get_json()
        
        # For demo purposes, return success with generated ID
        # TODO: Implement actual NextERP Item creation when API is available
        created_item = {
            'id': f"hemp_product_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            'name': data.get('name'),
            'sku': data.get('sku'),
            'category': data.get('category'),
            'strain': data.get('strain', ''),
            'thcContent': data.get('thcContent', 0.0),
            'cbdContent': data.get('cbdContent', 0.0),
            'currentStock': 0,
            'reorderLevel': data.get('reorderLevel', 10),
            'unit': data.get('unit'),
            'price': data.get('price', 0.0),
            'supplier': data.get('supplier', ''),
            'batchNumber': data.get('batchNumber', ''),
            'expiryDate': data.get('expiryDate'),
            'complianceStatus': 'pending',
            'description': data.get('description', ''),
            'brand': data.get('brand', ''),
            'createdDate': datetime.now().isoformat()
        }
        
        return jsonify({
            'data': created_item,
            'success': True
        }), 201
        
    except Exception as e:
        return jsonify({
            'error': str(e),
            'success': False
        }), 500

@nexterp_bp.route('/stock-movements', methods=['GET'])
@jwt_required()
@require_permission('nexterp:read')
def get_stock_movements():
    """Get stock movements from NextERP Stock Entry DocType"""
    try:
        # Demo stock movements for hemp inventory
        movements = [
            {
                'id': 'SM-001',
                'productId': 'hemp_flower_001',
                'productName': 'Premium Hemp Flower - Blue Dream',
                'movementType': 'in',
                'quantity': 100,
                'fromLocation': 'Supplier',
                'toLocation': 'Main Warehouse',
                'reason': 'Purchase Receipt',
                'timestamp': '2025-08-26 10:00:00',
                'batchNumber': 'BD-2025-001',
                'userId': 'admin',
                'userName': 'Admin User'
            },
            {
                'id': 'SM-002',
                'productId': 'hemp_oil_001',
                'productName': 'Full Spectrum Hemp Oil - 1000mg',
                'movementType': 'out',
                'quantity': 25,
                'fromLocation': 'Main Warehouse',
                'toLocation': 'Retail Store',
                'reason': 'Sales Order',
                'timestamp': '2025-08-26 14:30:00',
                'batchNumber': 'FS-2025-002',
                'userId': 'admin',
                'userName': 'Admin User'
            },
            {
                'id': 'SM-003',
                'productId': 'hemp_gummies_001',
                'productName': 'Hemp Gummies - Mixed Berry',
                'movementType': 'transfer',
                'quantity': 50,
                'fromLocation': 'Main Warehouse',
                'toLocation': 'Processing Center',
                'reason': 'Internal Transfer',
                'timestamp': '2025-08-26 16:15:00',
                'batchNumber': 'MB-2025-003',
                'userId': 'admin',
                'userName': 'Admin User'
            }
        ]
        
        return jsonify({
            'data': movements,
            'success': True
        })
        
    except Exception as e:
        return jsonify({
            'error': str(e),
            'success': False
        }), 500

@nexterp_bp.route('/warehouses', methods=['GET'])
@jwt_required()
@require_permission('nexterp:read')
def get_warehouses():
    """Get warehouses from NextERP Warehouse DocType"""
    try:
        # Demo warehouses for hemp operations
        warehouses = [
            {
                'id': 'WH-001',
                'name': 'Main Warehouse',
                'type': 'warehouse',
                'address': '123 Hemp Street, Denver, CO 80202',
                'capacity': 10000,
                'currentUtilization': 6500,
                'manager': 'John Smith',
                'isActive': True
            },
            {
                'id': 'WH-002',
                'name': 'Retail Store',
                'type': 'retail',
                'address': '456 Cannabis Ave, Boulder, CO 80301',
                'capacity': 2000,
                'currentUtilization': 1200,
                'manager': 'Jane Doe',
                'isActive': True
            },
            {
                'id': 'WH-003',
                'name': 'Processing Center',
                'type': 'processing',
                'address': '789 Extract Blvd, Fort Collins, CO 80524',
                'capacity': 5000,
                'currentUtilization': 3200,
                'manager': 'Mike Johnson',
                'isActive': True
            }
        ]
        
        return jsonify({
            'data': warehouses,
            'success': True
        })
        
    except Exception as e:
        return jsonify({
            'error': str(e),
            'success': False
        }), 500

