from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from werkzeug.security import check_password_hash, generate_password_hash
import os
from datetime import timedelta

auth_bp = Blueprint('auth', __name__)

# Get limiter instance (will be initialized by main app)
def get_limiter():
    from flask import current_app
    return current_app.extensions.get('limiter')

# Simple in-memory user store for development
# In production, this would be a proper database
# SECURITY NOTE: Default passwords changed to secure random values
USERS = {
    'admin': {
        'password_hash': generate_password_hash('HempERP_Admin_2025_Secure!@#$'),
        'role': 'admin',
        'permissions': ['nexterp:read', 'nexterp:write', 'admin:all']
    },
    'user': {
        'password_hash': generate_password_hash('HempERP_User_2025_ReadOnly!@#$'),
        'role': 'user', 
        'permissions': ['nexterp:read']
    }
}

@auth_bp.route('/login', methods=['POST'])
def login():
    """
    Authenticate user and return JWT token
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('username') or not data.get('password'):
            return jsonify({
                'success': False,
                'message': 'Username and password are required'
            }), 400
        
        username = data['username']
        password = data['password']
        
        # Check if user exists
        if username not in USERS:
            return jsonify({
                'success': False,
                'message': 'Invalid username or password'
            }), 401
        
        user = USERS[username]
        
        # Verify password
        if not check_password_hash(user['password_hash'], password):
            return jsonify({
                'success': False,
                'message': 'Invalid username or password'
            }), 401
        
        # Create JWT token with user info
        additional_claims = {
            'role': user['role'],
            'permissions': user['permissions']
        }
        
        access_token = create_access_token(
            identity=username,
            additional_claims=additional_claims,
            expires_delta=timedelta(seconds=int(os.getenv('JWT_ACCESS_TOKEN_EXPIRES', 3600)))
        )
        
        return jsonify({
            'success': True,
            'access_token': access_token,
            'user': {
                'username': username,
                'role': user['role'],
                'permissions': user['permissions']
            },
            'expires_in': int(os.getenv('JWT_ACCESS_TOKEN_EXPIRES', 3600))
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Authentication error',
            'error': str(e)
        }), 500

@auth_bp.route('/verify', methods=['GET'])
@jwt_required()
def verify_token():
    """
    Verify JWT token and return user info
    """
    try:
        current_user = get_jwt_identity()
        
        if current_user not in USERS:
            return jsonify({
                'success': False,
                'message': 'User not found'
            }), 404
        
        user = USERS[current_user]
        
        return jsonify({
            'success': True,
            'user': {
                'username': current_user,
                'role': user['role'],
                'permissions': user['permissions']
            },
            'valid': True
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Token verification error',
            'error': str(e)
        }), 500

@auth_bp.route('/logout', methods=['POST'])
@jwt_required()
def logout():
    """
    Logout user (client-side token removal)
    """
    try:
        current_user = get_jwt_identity()
        
        return jsonify({
            'success': True,
            'message': f'User {current_user} logged out successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Logout error',
            'error': str(e)
        }), 500

@auth_bp.route('/users', methods=['GET'])
@jwt_required()
def get_users():
    """
    Get list of users (admin only)
    """
    try:
        current_user = get_jwt_identity()
        
        if current_user not in USERS:
            return jsonify({
                'success': False,
                'message': 'User not found'
            }), 404
        
        user = USERS[current_user]
        
        # Check admin permission
        if 'admin:all' not in user['permissions']:
            return jsonify({
                'success': False,
                'message': 'Insufficient permissions'
            }), 403
        
        # Return user list (without password hashes)
        users_list = []
        for username, user_data in USERS.items():
            users_list.append({
                'username': username,
                'role': user_data['role'],
                'permissions': user_data['permissions']
            })
        
        return jsonify({
            'success': True,
            'users': users_list
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Error retrieving users',
            'error': str(e)
        }), 500

def require_permission(permission):
    """
    Decorator to require specific permission
    """
    def decorator(f):
        def decorated_function(*args, **kwargs):
            try:
                current_user = get_jwt_identity()
                
                if current_user not in USERS:
                    return jsonify({
                        'success': False,
                        'message': 'User not found'
                    }), 404
                
                user = USERS[current_user]
                
                # Check if user has required permission
                if permission not in user['permissions'] and 'admin:all' not in user['permissions']:
                    return jsonify({
                        'success': False,
                        'message': f'Permission required: {permission}'
                    }), 403
                
                return f(*args, **kwargs)
                
            except Exception as e:
                return jsonify({
                    'success': False,
                    'message': 'Permission check error',
                    'error': str(e)
                }), 500
        
        decorated_function.__name__ = f.__name__
        return decorated_function
    return decorator

