# Gunicorn configuration for Hemp ERP NextERP Proxy
# Production-grade WSGI server configuration

import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Server socket - configurable via environment
bind = os.getenv("BIND", "0.0.0.0:5001")  # Default prod port 5001, dev uses 5002
backlog = 2048

# Worker processes
workers = 4
worker_class = "sync"
worker_connections = 1000
timeout = 30
keepalive = 2

# Restart workers after this many requests, to help prevent memory leaks
max_requests = 1000
max_requests_jitter = 50

# Logging
accesslog = "-"  # Log to stdout
errorlog = "-"   # Log to stderr
loglevel = os.getenv('LOG_LEVEL', 'info').lower()
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(D)s'

# Process naming
proc_name = 'hemp_erp_proxy'

# Server mechanics
daemon = False
pidfile = '/tmp/hemp_erp_proxy.pid'
user = None
group = None
tmp_upload_dir = None

# SSL (for future use)
# keyfile = None
# certfile = None

# Security
limit_request_line = 4094
limit_request_fields = 100
limit_request_field_size = 8190

# Performance tuning
preload_app = True
sendfile = True

# Worker timeout and graceful shutdown
graceful_timeout = 30
worker_tmp_dir = "/dev/shm"

# Environment variables
raw_env = [
    f'NEXTERP_API_KEY={os.getenv("NEXTERP_API_KEY", "")}',
    f'NEXTERP_API_SECRET={os.getenv("NEXTERP_API_SECRET", "")}',
    f'FLASK_SECRET_KEY={os.getenv("FLASK_SECRET_KEY", "")}',
    f'JWT_SECRET_KEY={os.getenv("JWT_SECRET_KEY", "")}',
]

