# Hemp ERP v0.1 - Technical Documentation

## 🏗️ System Architecture

### Technology Stack
- **Framework**: ERPNext 14.x / Frappe Framework
- **Database**: MariaDB 10.6+
- **Web Server**: Nginx 1.18+
- **Application Server**: Gunicorn (Python WSGI)
- **Programming Language**: Python 3.8+
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Operating System**: Ubuntu 22.04 LTS

### Server Configuration
- **Server IP**: 72.60.67.104
- **Application Port**: 8000
- **Database Port**: 3306
- **Web Interface**: http://72.60.67.104:8000/app
- **Backend Services**: Managed via Frappe Bench

### System Requirements
- **CPU**: 2+ cores recommended
- **RAM**: 4GB minimum, 8GB recommended
- **Storage**: 50GB minimum, SSD recommended
- **Network**: Stable internet connection
- **Browser**: Modern browsers (Chrome 90+, Firefox 88+, Safari 14+)

## 📊 DocType Specifications

### 1. Hemp Client Profile
**Module**: Hemp ERP  
**Naming**: Auto-generated (format: random string)  
**Permissions**: Standard ERPNext permissions

#### Field Structure
```python
{
    "client_name": {
        "fieldtype": "Data",
        "label": "Client Name",
        "reqd": 1,
        "in_list_view": 1
    },
    "email": {
        "fieldtype": "Data", 
        "label": "Email",
        "options": "Email"
    },
    "phone": {
        "fieldtype": "Data",
        "label": "Phone"
    },
    "license_number": {
        "fieldtype": "Data",
        "label": "License Number"
    }
}
```

#### Database Schema
- **Table**: `tabHemp Client Profile`
- **Primary Key**: `name` (varchar)
- **Indexes**: client_name, email, license_number
- **Relationships**: Referenced by Hemp Sales Order

### 2. Hemp Vendor Profile
**Module**: Hemp ERP  
**Naming**: Auto-generated (format: random string)  
**Permissions**: Standard ERPNext permissions

#### Field Structure
```python
{
    "vendor_name": {
        "fieldtype": "Data",
        "label": "Vendor Name", 
        "reqd": 1,
        "in_list_view": 1
    },
    "email": {
        "fieldtype": "Data",
        "label": "Email",
        "options": "Email"
    },
    "phone": {
        "fieldtype": "Data", 
        "label": "Phone"
    },
    "license_number": {
        "fieldtype": "Data",
        "label": "License Number"
    }
}
```

#### Database Schema
- **Table**: `tabHemp Vendor Profile`
- **Primary Key**: `name` (varchar)
- **Indexes**: vendor_name, email, license_number
- **Relationships**: Referenced by Hemp Product Item, Hemp Purchase Order

### 3. Hemp Strain Template
**Module**: Hemp ERP  
**Naming**: Auto-generated (format: random string)  
**Permissions**: Standard ERPNext permissions

#### Field Structure
```python
{
    "strain_name": {
        "fieldtype": "Data",
        "label": "Strain Name",
        "reqd": 1,
        "in_list_view": 1
    },
    "strain_type": {
        "fieldtype": "Select",
        "label": "Strain Type",
        "options": "Sativa\nIndica\nHybrid\nCBD\nOther",
        "reqd": 1
    }
}
```

#### Database Schema
- **Table**: `tabHemp Strain Template`
- **Primary Key**: `name` (varchar)
- **Indexes**: strain_name, strain_type
- **Relationships**: Referenced by Hemp Product Item

### 4. Hemp Product Item
**Module**: Hemp ERP  
**Naming**: Auto-generated (format: random string)  
**Permissions**: Standard ERPNext permissions

#### Field Structure
```python
{
    "product_name": {
        "fieldtype": "Data",
        "label": "Product Name",
        "reqd": 1,
        "in_list_view": 1
    },
    "strain": {
        "fieldtype": "Link",
        "label": "Strain",
        "options": "Hemp Strain Template"
    },
    "vendor": {
        "fieldtype": "Link", 
        "label": "Vendor",
        "options": "Hemp Vendor Profile"
    }
}
```

#### Database Schema
- **Table**: `tabHemp Product Item`
- **Primary Key**: `name` (varchar)
- **Indexes**: product_name, strain, vendor
- **Foreign Keys**: 
  - strain → Hemp Strain Template(name)
  - vendor → Hemp Vendor Profile(name)

#### SKU Generation Logic
The system implements automatic SKU generation using the formula:
```python
def generate_sku(strain_name, vendor_code):
    return f"{strain_name}-{vendor_code}"
```

### 5. Hemp Purchase Order
**Module**: Hemp ERP  
**Naming**: Auto-generated (format: random string)  
**Permissions**: Standard ERPNext permissions

#### Field Structure
```python
{
    "vendor": {
        "fieldtype": "Link",
        "label": "Vendor",
        "options": "Hemp Vendor Profile",
        "reqd": 1
    },
    "order_date": {
        "fieldtype": "Date",
        "label": "Order Date",
        "default": "Today"
    },
    "total_amount": {
        "fieldtype": "Currency",
        "label": "Total Amount"
    }
}
```

#### Database Schema
- **Table**: `tabHemp Purchase Order`
- **Primary Key**: `name` (varchar)
- **Indexes**: vendor, order_date
- **Foreign Keys**: vendor → Hemp Vendor Profile(name)

### 6. Hemp Sales Order
**Module**: Hemp ERP  
**Naming**: Auto-generated (format: random string)  
**Permissions**: Standard ERPNext permissions

#### Field Structure
```python
{
    "customer": {
        "fieldtype": "Link",
        "label": "Customer", 
        "options": "Hemp Client Profile",
        "reqd": 1
    },
    "order_date": {
        "fieldtype": "Date",
        "label": "Order Date",
        "default": "Today"
    },
    "total_amount": {
        "fieldtype": "Currency",
        "label": "Total Amount"
    }
}
```

#### Database Schema
- **Table**: `tabHemp Sales Order`
- **Primary Key**: `name` (varchar)
- **Indexes**: customer, order_date
- **Foreign Keys**: customer → Hemp Client Profile(name)

## 🔗 System Relationships

### Entity Relationship Diagram
```
Hemp Client Profile (1) ←→ (N) Hemp Sales Order
Hemp Vendor Profile (1) ←→ (N) Hemp Purchase Order
Hemp Vendor Profile (1) ←→ (N) Hemp Product Item
Hemp Strain Template (1) ←→ (N) Hemp Product Item
```

### Critical Relationships
1. **Hemp Product Item → Hemp Strain Template**: Links products to strain characteristics
2. **Hemp Product Item → Hemp Vendor Profile**: Links products to suppliers for SKU generation
3. **Hemp Sales Order → Hemp Client Profile**: Links sales to customers
4. **Hemp Purchase Order → Hemp Vendor Profile**: Links purchases to suppliers

## 🛠️ Installation and Deployment

### Prerequisites
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y python3-dev python3-pip python3-venv
sudo apt install -y mariadb-server mariadb-client
sudo apt install -y nginx supervisor
sudo apt install -y git curl wget
```

### Frappe/ERPNext Installation
```bash
# Install Frappe Bench
pip3 install frappe-bench

# Create new site
bench new-site hemp-erp.local
bench use hemp-erp.local

# Install ERPNext
bench get-app erpnext
bench install-app erpnext

# Install Hemp ERP custom app
bench get-app hemp_erp [repository_url]
bench install-app hemp_erp
```

### Production Deployment
```bash
# Setup production configuration
bench setup production [user]
bench setup nginx
bench setup supervisor

# Enable and start services
sudo systemctl enable nginx supervisor
sudo systemctl start nginx supervisor

# Setup SSL (optional)
bench setup lets-encrypt [site-name]
```

## 🔧 Configuration Management

### Site Configuration
File: `sites/[site-name]/site_config.json`
```json
{
    "db_name": "hemp_erp_db",
    "db_password": "[secure_password]",
    "encryption_key": "[encryption_key]",
    "host_name": "http://72.60.67.104:8000",
    "install_apps": ["erpnext", "hemp_erp"]
}
```

### Nginx Configuration
File: `/etc/nginx/sites-available/[site-name]`
```nginx
server {
    listen 80;
    server_name 72.60.67.104;
    
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### Database Configuration
File: `/etc/mysql/mariadb.conf.d/50-server.cnf`
```ini
[mysqld]
innodb_file_format=barracuda
innodb_file_per_table=1
innodb_large_prefix=1
character-set-client-handshake=FALSE
character-set-server=utf8mb4
collation-server=utf8mb4_unicode_ci
```

## 🔍 Monitoring and Maintenance

### System Health Checks
```bash
# Check service status
bench status

# Check database connectivity
bench mariadb

# Check application logs
bench logs

# Monitor system resources
htop
df -h
free -m
```

### Performance Optimization
```bash
# Clear caches
bench clear-cache
bench clear-website-cache

# Rebuild assets
bench build

# Database optimization
bench migrate
bench optimize-database
```

### Backup Procedures
```bash
# Create backup
bench backup

# Restore backup
bench restore [backup-file]

# Automated backup setup
bench setup backup --frequency daily
```

## 🐛 Debugging and Troubleshooting

### Common Issues

#### 1. Web Interface Not Loading
**Symptoms**: Blank page, 404 errors, CSS/JS not loading
**Diagnosis**:
```bash
# Check service status
bench status

# Check nginx logs
sudo tail -f /var/log/nginx/error.log

# Check application logs
bench logs
```
**Solutions**:
```bash
# Rebuild assets
bench build

# Restart services
bench restart

# Clear caches
bench clear-cache
```

#### 2. Database Connection Issues
**Symptoms**: Database connection errors, migration failures
**Diagnosis**:
```bash
# Test database connection
bench mariadb

# Check database status
sudo systemctl status mariadb
```
**Solutions**:
```bash
# Restart database
sudo systemctl restart mariadb

# Run migrations
bench migrate

# Fix permissions
bench fix-permissions
```

#### 3. Permission Issues
**Symptoms**: Access denied errors, file permission errors
**Diagnosis**:
```bash
# Check file permissions
ls -la sites/[site-name]/

# Check user ownership
whoami
```
**Solutions**:
```bash
# Fix permissions
bench fix-permissions

# Change ownership
sudo chown -R [user]:[group] /path/to/frappe-bench
```

### Development Mode
```bash
# Start development server
bench start

# Enable developer mode
bench set-config developer_mode 1

# Disable developer mode
bench set-config developer_mode 0
```

### Log Analysis
```bash
# Application logs
tail -f sites/[site-name]/logs/web.log

# Error logs
tail -f sites/[site-name]/logs/error.log

# Database logs
sudo tail -f /var/log/mysql/error.log

# Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

## 🔐 Security Considerations

### Access Control
- **Role-Based Permissions**: Implement granular role-based access control
- **User Authentication**: Strong password policies and multi-factor authentication
- **Session Management**: Secure session handling and timeout policies
- **API Security**: Secure API endpoints with proper authentication

### Data Protection
- **Encryption**: Database encryption for sensitive data
- **Backup Security**: Encrypted backups with secure storage
- **Network Security**: SSL/TLS encryption for all communications
- **Audit Logging**: Comprehensive audit trails for compliance

### Compliance Requirements
- **Data Retention**: Implement data retention policies
- **Privacy Protection**: GDPR/CCPA compliance measures
- **Industry Regulations**: Hemp/cannabis industry compliance
- **Documentation**: Maintain compliance documentation

## 📈 Performance Tuning

### Database Optimization
```sql
-- Index optimization
CREATE INDEX idx_client_name ON `tabHemp Client Profile`(client_name);
CREATE INDEX idx_vendor_name ON `tabHemp Vendor Profile`(vendor_name);
CREATE INDEX idx_product_name ON `tabHemp Product Item`(product_name);

-- Query optimization
ANALYZE TABLE `tabHemp Client Profile`;
OPTIMIZE TABLE `tabHemp Client Profile`;
```

### Application Optimization
```python
# Cache configuration
CACHE_TYPE = "redis"
CACHE_REDIS_URL = "redis://localhost:6379"

# Database connection pooling
DB_POOL_SIZE = 10
DB_MAX_OVERFLOW = 20
```

### Server Optimization
```bash
# Nginx worker processes
worker_processes auto;
worker_connections 1024;

# Gunicorn workers
workers = 4
worker_class = "gevent"
worker_connections = 1000
```

---

## 📋 API Reference

### REST API Endpoints
```
GET    /api/resource/Hemp Client Profile
POST   /api/resource/Hemp Client Profile
PUT    /api/resource/Hemp Client Profile/{name}
DELETE /api/resource/Hemp Client Profile/{name}

GET    /api/resource/Hemp Vendor Profile
POST   /api/resource/Hemp Vendor Profile
PUT    /api/resource/Hemp Vendor Profile/{name}
DELETE /api/resource/Hemp Vendor Profile/{name}

GET    /api/resource/Hemp Product Item
POST   /api/resource/Hemp Product Item
PUT    /api/resource/Hemp Product Item/{name}
DELETE /api/resource/Hemp Product Item/{name}
```

### Authentication
```python
# API Key authentication
headers = {
    'Authorization': 'token [api_key]:[api_secret]'
}
```

---

*Hemp ERP v0.1 Technical Documentation*  
*Version 1.0 - August 2025*

