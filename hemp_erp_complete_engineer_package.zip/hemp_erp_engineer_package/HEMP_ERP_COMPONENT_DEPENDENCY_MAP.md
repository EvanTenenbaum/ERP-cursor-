# 🔗 **HEMP ERP SYSTEM - COMPONENT DEPENDENCY MAP**

## **📋 DEPENDENCY OVERVIEW**

**System Architecture**: Modular React frontend + Flask backend + NextERP integration
**Component Count**: 45+ React components, 8 API endpoints, 12 utility modules
**Dependency Depth**: 4 levels maximum

## **🎯 FRONTEND COMPONENT DEPENDENCY TREE**

### **Level 1: Application Root**
```
App.jsx (Main Application)
├── React Router DOM (external)
├── AuthProvider (internal)
├── NextERPAPI (internal)
└── Global CSS (styles)
```

### **Level 2: Page Components**
```
App.jsx
├── CustomerWorkspacePage.jsx
│   ├── CustomerList.jsx
│   ├── CustomerForm.jsx
│   ├── DataTable.jsx (shared)
│   └── SimpleLayout.jsx (shared)
│
├── InventoryManagementPage.jsx
│   ├── InventoryList.jsx
│   ├── ProductCategorySelect.jsx
│   ├── DataTable.jsx (shared)
│   └── SimpleLayout.jsx (shared)
│
├── StreamlinedSalesPage.jsx
│   ├── StreamlinedSalesModal.jsx
│   ├── CustomerDetailDrawer.jsx
│   ├── PaginatedTable.jsx (shared)
│   └── SimpleLayout.jsx (shared)
│
├── DebtManagementPage.jsx
│   ├── DataTable.jsx (shared)
│   ├── RecordDrawer.jsx (shared)
│   └── SimpleLayout.jsx (shared)
│
├── ReportingDashboardPage.jsx
│   ├── Chart components (ui)
│   ├── Card components (ui)
│   └── SimpleLayout.jsx (shared)
│
└── TestPage.jsx
    ├── FoundationTest.jsx
    ├── RealFoundationTest.jsx
    └── ProxyFoundationTest.jsx
```

### **Level 3: Shared Components**
```
Shared Components
├── SimpleLayout.jsx
│   ├── Navigation (internal)
│   ├── Header (internal)
│   └── Sidebar (ui)
│
├── DataTable.jsx
│   ├── Table (ui)
│   ├── Button (ui)
│   ├── Input (ui)
│   └── Pagination (ui)
│
├── PaginatedTable.jsx
│   ├── DataTable.jsx (shared)
│   ├── Pagination (ui)
│   └── Select (ui)
│
├── CustomerDetailDrawer.jsx
│   ├── Drawer (ui)
│   ├── Form (ui)
│   ├── Button (ui)
│   └── Input (ui)
│
├── RecordDrawer.jsx
│   ├── Drawer (ui)
│   ├── Card (ui)
│   ├── Badge (ui)
│   └── Button (ui)
│
└── StreamlinedSalesModal.jsx
    ├── Dialog (ui)
    ├── Form (ui)
    ├── Select (ui)
    └── Button (ui)
```

### **Level 4: UI Components (Radix UI Based)**
```
UI Components (/components/ui/)
├── Basic Components
│   ├── Button.jsx (Radix UI)
│   ├── Input.jsx (Radix UI)
│   ├── Label.jsx (Radix UI)
│   ├── Card.jsx (Radix UI)
│   ├── Badge.jsx (Radix UI)
│   └── Separator.jsx (Radix UI)
│
├── Form Components
│   ├── Form.jsx (React Hook Form + Radix)
│   ├── Select.jsx (Radix UI)
│   ├── Checkbox.jsx (Radix UI)
│   ├── RadioGroup.jsx (Radix UI)
│   └── Textarea.jsx (Radix UI)
│
├── Layout Components
│   ├── Dialog.jsx (Radix UI)
│   ├── Drawer.jsx (Radix UI)
│   ├── Sheet.jsx (Radix UI)
│   ├── Sidebar.jsx (Radix UI)
│   └── Tabs.jsx (Radix UI)
│
├── Data Display
│   ├── Table.jsx (Radix UI)
│   ├── Pagination.jsx (Radix UI)
│   ├── Chart.jsx (Recharts)
│   ├── Progress.jsx (Radix UI)
│   └── Skeleton.jsx (Radix UI)
│
└── Navigation
    ├── NavigationMenu.jsx (Radix UI)
    ├── Breadcrumb.jsx (Radix UI)
    ├── DropdownMenu.jsx (Radix UI)
    └── ContextMenu.jsx (Radix UI)
```

## **🔧 BACKEND DEPENDENCY STRUCTURE**

### **Flask Application Dependencies**
```
main.py (Flask App)
├── Flask Framework
│   ├── Flask-CORS (cross-origin)
│   ├── Flask-JWT-Extended (authentication)
│   ├── Flask-Limiter (rate limiting)
│   └── Werkzeug (WSGI utilities)
│
├── Route Blueprints
│   ├── auth.py (authentication routes)
│   └── nexterp.py (NextERP integration routes)
│
├── External Services
│   ├── NextERP API (HTTP client)
│   └── Logging system
│
└── Configuration
    ├── Environment variables
    ├── Security headers
    └── CORS policies
```

### **Authentication Module Dependencies**
```
auth.py (Authentication Routes)
├── Flask-JWT-Extended
│   ├── create_access_token()
│   ├── jwt_required()
│   └── get_jwt_identity()
│
├── Security Utilities
│   ├── Password validation
│   ├── Rate limiting
│   └── Audit logging
│
└── User Management
    ├── User validation
    ├── Role checking
    └── Session management
```

### **NextERP Integration Dependencies**
```
nexterp.py (NextERP Routes)
├── HTTP Client (requests)
│   ├── Authentication headers
│   ├── Request/response handling
│   └── Error handling
│
├── Data Transformation
│   ├── Request validation
│   ├── Response formatting
│   └── Error mapping
│
└── Business Logic
    ├── Customer operations
    ├── Inventory management
    └── Hemp compliance
```

## **📡 API INTEGRATION DEPENDENCIES**

### **Frontend API Client Structure**
```
NextERPAPI.js (API Client)
├── HTTP Client (fetch/axios)
│   ├── Request interceptors
│   ├── Response interceptors
│   └── Error handling
│
├── Authentication
│   ├── JWT token management
│   ├── Token refresh logic
│   └── Login/logout handling
│
├── Endpoints
│   ├── Customer operations
│   ├── Inventory management
│   ├── Authentication
│   └── Foundation testing
│
└── Data Transformation
    ├── Request formatting
    ├── Response parsing
    └── Error normalization
```

### **Backend to NextERP Dependencies**
```
NextERP Integration
├── HTTP Client (requests)
│   ├── Connection pooling
│   ├── Timeout handling
│   └── Retry logic
│
├── Authentication
│   ├── API key management
│   ├── Token format (key:secret)
│   └── Header construction
│
├── Data Models
│   ├── Customer schema
│   ├── Product schema
│   ├── Order schema
│   └── Compliance schema
│
└── Error Handling
    ├── HTTP status mapping
    ├── NextERP error codes
    └── Fallback responses
```

## **🎨 STYLING DEPENDENCIES**

### **CSS Framework Dependencies**
```
Styling System
├── Tailwind CSS (utility-first)
│   ├── Base styles
│   ├── Component classes
│   ├── Utility classes
│   └── Custom theme
│
├── CSS Variables
│   ├── Color palette
│   ├── Spacing system
│   ├── Typography scale
│   └── Border radius
│
├── Radix UI Styles
│   ├── Component primitives
│   ├── Accessibility features
│   ├── Animation system
│   └── Theme integration
│
└── Custom Components
    ├── Hemp-specific styling
    ├── Brand colors
    ├── Industry iconography
    └── Responsive design
```

## **🔄 STATE MANAGEMENT DEPENDENCIES**

### **React State Flow**
```
State Management
├── React Hooks
│   ├── useState (local state)
│   ├── useEffect (side effects)
│   ├── useContext (global state)
│   └── useReducer (complex state)
│
├── Context Providers
│   ├── AuthContext (authentication)
│   ├── ThemeContext (UI theme)
│   └── APIContext (API state)
│
├── Custom Hooks
│   ├── useNextERPData (data fetching)
│   ├── useDebounce (input optimization)
│   └── useMobile (responsive design)
│
└── Local Storage
    ├── JWT tokens
    ├── User preferences
    └── Cache data
```

## **🛠️ DEVELOPMENT DEPENDENCIES**

### **Build Tool Dependencies**
```
Development Tools
├── Vite (build tool)
│   ├── React plugin
│   ├── Hot module replacement
│   ├── Asset optimization
│   └── Development server
│
├── Code Quality
│   ├── ESLint (linting)
│   ├── Prettier (formatting)
│   ├── TypeScript (optional)
│   └── Husky (git hooks)
│
├── Testing (planned)
│   ├── Jest (unit testing)
│   ├── React Testing Library
│   ├── Cypress (e2e testing)
│   └── MSW (API mocking)
│
└── Deployment
    ├── Production build
    ├── Static file serving
    ├── Environment configuration
    └── Health monitoring
```

## **📊 DEPENDENCY ANALYSIS**

### **Critical Dependencies (System Breaking)**
1. **React 19.1.0** - Core framework
2. **Flask 3.1.0** - Backend framework
3. **NextERP API** - External data source
4. **Radix UI** - Component primitives
5. **Tailwind CSS** - Styling system

### **Important Dependencies (Feature Breaking)**
1. **React Router** - Navigation
2. **Flask-JWT-Extended** - Authentication
3. **Flask-CORS** - Cross-origin requests
4. **Lucide React** - Icons
5. **Vite** - Development/build

### **Optional Dependencies (Enhancement)**
1. **Chart libraries** - Data visualization
2. **Animation libraries** - UI enhancements
3. **Testing frameworks** - Quality assurance
4. **Monitoring tools** - Performance tracking

## **🔍 DEPENDENCY HEALTH CHECK**

### **Version Compatibility Matrix**
```
React 19.1.0 ✅ Compatible with all UI libraries
Vite 6.3.5   ⚠️  Host validation issues (workaround active)
Flask 3.1.0  ✅ Stable with all extensions
Radix UI     ✅ Full compatibility with React 19
Tailwind     ✅ No conflicts detected
```

### **Security Audit Status**
```
✅ No known vulnerabilities in production dependencies
✅ All security patches applied
✅ Regular dependency updates scheduled
⚠️  Development dependencies may have non-critical warnings
```

### **Performance Impact**
```
Bundle Size Analysis:
- React + React DOM: ~45KB (gzipped)
- Radix UI Components: ~25KB (gzipped)
- Application Code: ~12KB (gzipped)
- Total Frontend: ~82KB (gzipped)

Backend Dependencies:
- Flask + Extensions: ~15MB installed
- Python Runtime: ~50MB
- Total Backend: ~65MB
```

---

**This dependency map provides a complete understanding of how all components interact within the Hemp ERP system, enabling informed development decisions and troubleshooting.**

