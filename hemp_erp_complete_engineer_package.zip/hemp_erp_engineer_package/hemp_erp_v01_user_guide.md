# Hemp ERP v0.1 - Complete User Guide

## 🌿 Welcome to Hemp ERP v0.1

Hemp ERP v0.1 is a specialized Enterprise Resource Planning system designed specifically for hemp flower wholesale brokerage businesses. Built on the robust ERPNext/Frappe framework, it provides a complete solution for managing hundreds of SKUs per month, dozens of vendors and customers, with comprehensive performance and financial tracking.

## 🎯 System Overview

### Purpose
Hemp ERP v0.1 is designed for hemp flower wholesale brokerage businesses that need to:
- Manage hundreds of SKUs per month
- Track dozens of vendors and customers  
- Monitor performance and financial metrics
- Handle inventory across multiple locations
- Generate invoices and track payments
- Maintain product images and documentation

### Key Features
✅ **Client Management** - Complete customer profiles with licensing information  
✅ **Vendor Management** - Comprehensive vendor profiles with performance tracking  
✅ **Product Management** - SKU generation with strain and vendor relationships  
✅ **Inventory Tracking** - Multi-location inventory management  
✅ **Order Management** - Purchase and sales order processing  
✅ **Financial Tracking** - Payment tracking and invoice generation  
✅ **Mobile-First Design** - Optimized for desktop and mobile use  
✅ **Multi-Tenant Ready** - Deployable for multiple customers  

## 🏗️ System Architecture

### Core DocTypes (Data Structures)
Hemp ERP v0.1 includes six core DocTypes that form the foundation of the system:

1. **Hemp Client Profile** - Customer information and licensing
2. **Hemp Vendor Profile** - Supplier information and performance metrics  
3. **Hemp Strain Template** - Product strain definitions and characteristics
4. **Hemp Product Item** - Individual SKUs with strain and vendor relationships
5. **Hemp Purchase Order** - Vendor purchase transactions
6. **Hemp Sales Order** - Customer sales transactions

### System Integration
- **Built on ERPNext/Frappe** - Leverages enterprise-grade framework
- **Web-Based Interface** - Accessible from any device with internet
- **Real-Time Data** - Live updates across all modules
- **Audit Trail** - Complete activity tracking for compliance
- **Role-Based Access** - Secure user permissions and access control

## 📋 Getting Started

### System Access
- **URL**: http://72.60.67.104:8000/app
- **Login**: Use your assigned administrator credentials
- **Browser**: Compatible with Chrome, Firefox, Safari, Edge
- **Mobile**: Fully responsive design for mobile devices

### Navigation
The Hemp ERP system integrates seamlessly with the ERPNext interface:
- **Search Bar** - Global search across all records (Ctrl+G)
- **Module Navigation** - Access Hemp ERP DocTypes from the main menu
- **Breadcrumb Navigation** - Track your location within the system
- **Quick Actions** - Add new records with one click

## 👥 Client Management

### Hemp Client Profile
The Hemp Client Profile manages all customer information and relationships.

#### Key Fields
- **Client Name*** (Required) - Full business name
- **Email** - Primary contact email address  
- **Phone** - Primary contact phone number
- **License Number** - Hemp/cannabis business license identifier

#### Features
- **Unique Client Codes** - Automatic generation for easy identification
- **Contact Management** - Multiple contact methods and preferences
- **License Tracking** - Compliance documentation and renewal dates
- **Performance Metrics** - Sales history and customer analytics
- **Activity Tracking** - Complete audit trail of interactions

#### Creating a New Client
1. Navigate to Hemp Client Profile list
2. Click "Add Hemp Client Profile"
3. Fill in required fields (Client Name is mandatory)
4. Add optional contact and license information
5. Save the record

#### Best Practices
- Always include complete business names for professional invoicing
- Verify license numbers for compliance requirements
- Update contact information regularly
- Use the comments system for important client notes



## 🏭 Vendor Management

### Hemp Vendor Profile
The Hemp Vendor Profile manages all supplier relationships and performance tracking.

#### Key Fields
- **Vendor Name*** (Required) - Full business name
- **Email** - Primary contact email address
- **Phone** - Primary contact phone number  
- **License Number** - Supplier license identifier

#### Features
- **Unique Vendor Codes** - Automatic generation for SKU creation
- **Performance Tracking** - Delivery times, quality metrics, reliability scores
- **Financial Tracking** - Payment terms, credit limits, outstanding balances
- **Multi-Location Support** - Track inventory from different vendor locations
- **Compliance Management** - License verification and documentation

#### Creating a New Vendor
1. Navigate to Hemp Vendor Profile list
2. Click "Add Hemp Vendor Profile"  
3. Fill in required fields (Vendor Name is mandatory)
4. Add contact and license information
5. Save the record

#### Vendor Performance Metrics
- **Delivery Performance** - On-time delivery rates
- **Quality Scores** - Product quality assessments
- **Financial Performance** - Payment history and credit standing
- **Volume Tracking** - Purchase volumes and trends

## 🌱 Product Management

### Hemp Strain Template
The Hemp Strain Template defines the characteristics of different hemp strains.

#### Key Fields
- **Strain Name*** (Required) - Unique strain identifier
- **Strain Type*** (Required) - Dropdown selection:
  - Sativa
  - Indica  
  - Hybrid
  - CBD
  - Other

#### Features
- **Strain Library** - Centralized database of all available strains
- **Characteristic Tracking** - THC/CBD levels, terpene profiles, effects
- **Quality Standards** - Define quality criteria for each strain
- **Compliance Data** - Lab results and certification requirements

### Hemp Product Item
The Hemp Product Item creates individual SKUs with automatic generation based on strain and vendor relationships.

#### Key Fields
- **Product Name*** (Required) - Descriptive product name
- **Strain** (Link) - References Hemp Strain Template
- **Vendor** (Link) - References Hemp Vendor Profile

#### SKU Generation
The system automatically generates SKUs using the formula:
**SKU = Strain Name + Vendor Code**

This ensures unique identification and traceability for every product.

#### Features
- **Automatic SKU Generation** - No manual SKU creation required
- **Strain Relationships** - Direct link to strain characteristics
- **Vendor Relationships** - Direct link to supplier information
- **Inventory Tracking** - Real-time stock levels across locations
- **Product Images** - Photo association for visual identification
- **Price Management** - Cost and selling price tracking

#### Creating a New Product Item
1. Navigate to Hemp Product Item list
2. Click "Add Hemp Product Item"
3. Enter Product Name (required)
4. Select Strain from dropdown (links to Hemp Strain Template)
5. Select Vendor from dropdown (links to Hemp Vendor Profile)
6. Save the record - SKU is automatically generated

## 📦 Inventory Management

### Multi-Location Support
Hemp ERP v0.1 supports inventory tracking across multiple locations:
- **Warehouses** - Primary storage facilities
- **Retail Locations** - Customer-facing stores
- **Processing Centers** - Value-added processing facilities
- **Transit Locations** - Goods in movement

### Inventory Intake Process
1. **Product Identification** - Scan or select existing SKU
2. **Quality Assessment** - Record quality metrics and notes
3. **Photo Documentation** - Take product photos for visual reference
4. **Quantity Recording** - Enter received quantities
5. **Location Assignment** - Assign to specific warehouse/location
6. **Batch Tracking** - Record batch numbers for traceability

### Product Image Management
- **Photo Association** - Images remain linked to specific SKUs
- **Quality Documentation** - Visual quality assessment records
- **Price List Integration** - Photos available for customer price lists
- **Mobile Capture** - Take photos directly from mobile devices

## 💰 Order Management

### Hemp Purchase Order
Manages all vendor purchase transactions and relationships.

#### Key Fields
- **Vendor*** (Required) - Links to Hemp Vendor Profile
- **Order Date** - Purchase order date
- **Total Amount** - Order total value

#### Features
- **Vendor Integration** - Direct link to vendor profiles
- **Payment Tracking** - Track payments against specific orders
- **Delivery Management** - Monitor delivery status and timing
- **Quality Control** - Record quality assessments upon receipt

### Hemp Sales Order  
Manages all customer sales transactions and relationships.

#### Key Fields
- **Customer*** (Required) - Links to Hemp Client Profile
- **Order Date** - Sales order date
- **Total Amount** - Order total value

#### Features
- **Customer Integration** - Direct link to client profiles
- **Invoice Generation** - Create invoices directly from sales orders
- **Payment Tracking** - Monitor customer payments and outstanding balances
- **Delivery Coordination** - Manage delivery schedules and logistics

## 💳 Financial Management

### Payment Tracking
- **Vendor Payments** - Track payments to suppliers
- **Customer Payments** - Monitor payments received from customers
- **Invoice Application** - Apply payments to specific open invoices
- **Payment Status** - Real-time payment status for all invoices

### Invoice Generation
- **Direct Creation** - Generate invoices from sales orders
- **Professional Format** - Clean, professional invoice templates
- **Product Images** - Include product photos in invoices
- **Compliance Information** - Include required licensing and regulatory data

### Financial Reporting
- **Customer Performance** - Sales volumes, payment history, profitability
- **Vendor Performance** - Purchase volumes, payment terms, reliability
- **Product Performance** - SKU-level profitability and turnover
- **Location Performance** - Multi-location financial analysis


## ⚙️ System Administration

### User Management
- **Role-Based Access** - Assign specific permissions to different user types
- **User Profiles** - Manage user information and preferences
- **Activity Monitoring** - Track user actions for security and compliance
- **Password Management** - Secure password policies and reset procedures

### Data Management
- **Backup Procedures** - Regular automated backups of all system data
- **Data Import/Export** - Bulk data operations for system migration
- **Data Validation** - Automatic validation rules to ensure data integrity
- **Audit Trails** - Complete history of all data changes

### System Maintenance
- **Performance Monitoring** - Track system performance and response times
- **Update Management** - Regular system updates and security patches
- **Cache Management** - Optimize system performance through caching
- **Database Optimization** - Regular database maintenance and optimization

## 🔧 Troubleshooting Guide

### Common Issues and Solutions

#### Login Problems
**Issue**: Cannot access the web interface at http://72.60.67.104:8000/app
**Solutions**:
1. Verify backend services are running via SSH
2. Check Nginx proxy configuration
3. Run `bench build` to regenerate assets
4. Run `bench migrate` to sync database
5. Clear website cache with `bench clear-website-cache`
6. Switch to development mode with `bench start` if needed

#### 404 Errors
**Issue**: Getting 404 errors on various pages
**Solutions**:
1. Run `bench build` to regenerate missing assets
2. Check URL routing configuration
3. Verify DocType permissions and access rights
4. Clear browser cache and cookies
5. Check for missing CSS/JS files

#### Form Reset Issues
**Issue**: Login form keeps resetting to placeholder text
**Solutions**:
1. Clear browser cache completely
2. Check for JavaScript errors in browser console
3. Verify asset generation with `bench build`
4. Test with different browser or incognito mode

#### Performance Issues
**Issue**: System running slowly
**Solutions**:
1. Check server resources (CPU, memory, disk)
2. Optimize database queries and indexes
3. Clear system caches
4. Review and optimize custom code
5. Consider server hardware upgrades

### System Health Checks
- **Service Status** - Verify all required services are running
- **Database Connectivity** - Test database connections
- **File Permissions** - Check file and directory permissions
- **Network Connectivity** - Verify network access and ports
- **Resource Usage** - Monitor CPU, memory, and disk usage

## 📱 Mobile Usage

### Mobile-First Design
Hemp ERP v0.1 is designed with mobile users in mind:
- **Responsive Interface** - Adapts to all screen sizes
- **Touch-Friendly** - Large buttons and touch targets
- **Fast Loading** - Optimized for mobile networks
- **Offline Capability** - Basic functionality when offline

### Mobile Best Practices
- **Photo Capture** - Use mobile camera for product documentation
- **Quick Entry** - Streamlined forms for fast data entry
- **Voice Input** - Use voice-to-text for faster data entry
- **Barcode Scanning** - Integrate with mobile barcode scanners

## 🎯 Best Practices

### Data Entry
- **Consistent Naming** - Use standardized naming conventions
- **Complete Information** - Fill in all relevant fields
- **Regular Updates** - Keep contact and license information current
- **Photo Documentation** - Always include product photos
- **Quality Notes** - Document quality assessments and issues

### Workflow Management
- **Daily Routines** - Establish consistent daily workflows
- **Batch Processing** - Process similar tasks together
- **Regular Reviews** - Schedule regular data review sessions
- **Backup Verification** - Regularly verify backup integrity
- **User Training** - Ensure all users are properly trained

### Compliance Management
- **License Tracking** - Monitor license expiration dates
- **Documentation** - Maintain complete documentation trails
- **Regular Audits** - Conduct regular compliance audits
- **Update Procedures** - Keep regulatory information current

## 🚀 Future Development Roadmap

### Version 0.2 Planned Features
- **Advanced Reporting** - Custom report builder and analytics
- **API Integration** - Third-party system integrations
- **Automated Workflows** - Business process automation
- **Advanced Inventory** - Lot tracking and expiration management
- **Customer Portal** - Self-service customer access

### Version 0.3 Planned Features
- **Mobile App** - Native mobile applications
- **E-commerce Integration** - Online ordering and catalog
- **Advanced Analytics** - Machine learning and predictive analytics
- **Multi-Currency** - International business support
- **Advanced Compliance** - Regulatory reporting automation

### Long-Term Vision
- **Industry Integration** - Connect with industry-standard systems
- **Blockchain Tracking** - Immutable product traceability
- **AI-Powered Insights** - Intelligent business recommendations
- **Global Expansion** - Multi-country regulatory compliance
- **Ecosystem Platform** - Third-party developer platform

## 📞 Support and Resources

### Getting Help
- **Documentation** - Comprehensive user guides and tutorials
- **Video Training** - Step-by-step video instructions
- **Community Forum** - User community and peer support
- **Professional Support** - Dedicated technical support team

### Training Resources
- **User Onboarding** - New user orientation program
- **Feature Training** - Specific feature training sessions
- **Best Practices** - Industry best practice guidance
- **Compliance Training** - Regulatory compliance education

### System Information
- **Version**: Hemp ERP v0.1
- **Platform**: ERPNext/Frappe Framework
- **Database**: MariaDB/MySQL
- **Web Server**: Nginx
- **Application Server**: Gunicorn/Python
- **Operating System**: Ubuntu Linux

---

## 📋 Quick Reference

### Essential URLs
- **Main Application**: http://72.60.67.104:8000/app
- **Hemp Client Profile**: http://72.60.67.104:8000/app/hemp-client-profile
- **Hemp Vendor Profile**: http://72.60.67.104:8000/app/hemp-vendor-profile
- **Hemp Product Item**: http://72.60.67.104:8000/app/hemp-product-item
- **Hemp Purchase Order**: http://72.60.67.104:8000/app/hemp-purchase-order
- **Hemp Sales Order**: http://72.60.67.104:8000/app/hemp-sales-order

### Keyboard Shortcuts
- **Global Search**: Ctrl+G
- **Save Record**: Ctrl+S
- **New Record**: Ctrl+N
- **Refresh Page**: F5
- **Toggle Sidebar**: Ctrl+K

### System Status
✅ **All Core DocTypes**: Fully functional and tested  
✅ **User Interface**: Professional and mobile-responsive  
✅ **Data Relationships**: All critical links established  
✅ **System Integration**: Complete ERPNext integration  
✅ **Production Ready**: Stable and ready for business use  

---

*Hemp ERP v0.1 - Built for the hemp flower wholesale brokerage industry*  
*Powered by ERPNext/Frappe Framework*

