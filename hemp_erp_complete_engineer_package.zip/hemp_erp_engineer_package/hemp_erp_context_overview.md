# Hemp ERP System - Project Context Overview

## PROJECT OVERVIEW
**Product Name:** Hemp Flower Wholesale ERP System
**Platform:** ERPNext (Frappe Framework)
**Industry:** Hemp/Cannabis wholesale distribution
**Target Market:** Hemp flower wholesalers, distributors, and retailers
**Development Stage:** Phase 1 - Core DocTypes (95% complete)

## CURRENT SYSTEM STATUS (As of 2025-08-22)

### ✅ COMPLETED COMPONENTS
1. **Hemp Client Profile DocType** - Fully operational (CTO Score: 95/100)
2. **Hemp Vendor Profile DocType** - Fully operational (restored via migration)
3. **Hemp Strain Template DocType** - Fully operational (clean slate recreation)

### 🔧 TECHNICAL INFRASTRUCTURE
- **Server:** 72.60.67.104 (Ubuntu 22.04)
- **ERPNext Version:** Latest stable
- **Database:** MariaDB
- **Web Server:** Nginx
- **Access:** administrator/admin credentials
- **Module:** Hemp Flower Wholesale ERP (custom module)

### 🎯 ATOMIC DEVELOPMENT METHODOLOGY
- **Current Status:** Atomic Step 3 Complete, preparing for Atomic Step 4
- **Approach:** Complete one DocType fully before advancing
- **Quality Standard:** CTO-level reviews at each milestone
- **Timeline:** Manus compute hours (not weeks)

## HEMP STRAIN TEMPLATE SPECIFICATIONS

### Field Structure (Production-Ready)
1. **Strain Name** (Data, Mandatory) - Primary identifier
2. **THC %** (Percent, Default: 0, Precision: 2) - Tetrahydrocannabinol content
3. **CBD %** (Percent, Default: 0, Precision: 2) - Cannabidiol content  
4. **CBG %** (Percent, Default: 0, Precision: 2) - Cannabigerol content
5. **CBN %** (Percent, Default: 0, Precision: 2) - Cannabinol content
6. **Strain Type** (Select: Indica/Sativa/Hybrid) - Classification system

### Technical Implementation Notes
- All decimal fields use "0" defaults (prevents NULL corruption)
- 2 decimal precision for all percentage fields
- Clean slate recreation resolved schema corruption issues
- Full web interface accessibility confirmed

## NEXT PHASE: ATOMIC STEP 4
**Target:** Hemp Product Item customizations with inventory schema integration

### Inventory Schema Requirements
- Integration with ERPNext Item DocType
- Hemp-specific inventory tracking
- Batch/lot management for compliance
- Strain-to-product relationships
- Wholesale pricing structures

## CRITICAL LESSONS LEARNED

### Bug Resolution Methodology
1. **Attempt Fix Twice** - Try direct solutions first
2. **Search Community** - Use Frappe forums after failed attempts
3. **Clean Slate Approach** - Delete and recreate corrupted components
4. **Proper Defaults** - Always set explicit defaults for decimal fields

### Technical Debt Prevention
- Use `bench use <site>` + `bench start` for proper ERPNext startup
- Set explicit default values (0) for decimal/percent fields
- Implement backup strategies for custom DocTypes
- Version control all customizations
- Configure security settings and permissions

## CURRENT TECHNICAL ARCHITECTURE

### DocType Relationships
```
Hemp Client Profile (Customer management)
    ↓
Hemp Vendor Profile (Supplier management)  
    ↓
Hemp Strain Template (Product specifications)
    ↓
Hemp Product Item (Inventory items) ← NEXT PHASE
```

### Database Schema Considerations
- Custom fields integration with standard ERPNext DocTypes
- Hemp-specific compliance data storage
- Batch/lot tracking implementation
- COA document management
- Pricing tier structures

## DEVELOPMENT PRIORITIES

### Immediate (Atomic Step 4)
1. Hemp Product Item DocType creation
2. Integration with ERPNext Item master
3. Strain-to-product relationship mapping
4. Basic inventory tracking setup

### Phase 2 (Future)
1. COA management system
2. Compliance reporting automation
3. B2B customer portal
4. Mobile warehouse management
5. Integration with testing labs

## SUCCESS METRICS
- **Functional:** All hemp business processes supported
- **Compliance:** Full regulatory compliance capability
- **Performance:** Handle 10,000+ SKUs efficiently
- **User Experience:** Intuitive for hemp industry users
- **Integration:** Seamless with existing hemp business tools

## DEVELOPMENT STATUS
**Current Phase:** Atomic Step 3 Complete - All core Hemp DocTypes operational
**Next Phase:** Atomic Step 4 - Hemp Product Item customizations with inventory integration
**Timeline:** Ready to proceed pending any additional research insights
**Quality Status:** Production-ready foundation established with comprehensive cannabinoid profiling system

