# OpenTHC Taxonomy Analysis for Cannabis ERP UI Integration

## 🎯 **ATOMIC STEP 11: OPENTHC TAXONOMY STRUCTURE ANALYSIS**

### **OpenTHC Base Data Categories**

Based on analysis of https://api.openthc.org/base-data, OpenTHC provides comprehensive cannabis industry taxonomy:

#### **1. Company Types [10]**
- Brand
- Carrier  
- Conglomerate
- Grower
- Laboratory
- Processor
- Retail
- Technology

#### **2. License Types [8]**
- Carrier (Delivery/Transport)
- Farmer, Grower, Producer
- Farmer/Grower + Manufacturer/Processor (combination)
- Laboratory, Quality Assurance, Testing
- Retail (medical or recreational)

#### **3. Product Types [48]** ⭐ **CRITICAL FOR INTEGRATION**
Key product categories identified:
- **Generic Bulk Product** - Any bulk goods, flower, oil, kief
- **Flower Products** - Various flower-based products
- **Concentrate Products** - Oils, extracts, concentrates
- **Edible Products** - Consumable cannabis products
- **Topical Products** - Creams, lotions, balms
- **Pre-Roll Products** - Pre-rolled joints and blunts
- **Vape Products** - Vaporizer cartridges and devices

#### **4. Contact Types [12]**
- Various contact classification types for business relationships

#### **5. Lab Metric Types (Groups) [8]**
- Testing category groups for quality assurance

#### **6. Lab Metric (Test Types) [368]**
- Detailed testing metrics for cannabis products

## 🎯 **INTEGRATION STRATEGY**

### **Priority 1: Product Type Enhancement**
- Extend **Hemp Product Item** DocType with OpenTHC product categories
- Add product type classification dropdown
- Maintain existing SKU generation while adding taxonomy

### **Priority 2: Company Type Integration**
- Enhance **Hemp Vendor Profile** with company type classification
- Add license type tracking for compliance
- Extend **Hemp Client Profile** with business type categories

### **Priority 3: Strain Classification**
- Research OpenTHC strain taxonomy (separate from base data)
- Enhance **Hemp Strain Template** with industry-standard classifications
- Add strain type categories (Indica, Sativa, Hybrid, etc.)

## 🚀 **IMPLEMENTATION APPROACH**

### **Zero-Bloat Extension Strategy**
1. **Add new fields** to existing DocTypes (no new parallel systems)
2. **Optional taxonomy** - can be enabled/disabled per business needs
3. **Backward compatibility** - all existing functionality preserved
4. **Industry standards** - align with OpenTHC taxonomy for interoperability

### **Next Steps**
- Research OpenTHC strain classification system
- Design taxonomy field additions for existing DocTypes
- Plan frontend UI enhancements for taxonomy display
- Create migration strategy for existing data

## 🎯 **OPENTHC JSON DATA STRUCTURE ANALYSIS**

### **Complete Strain Database Structure**
```json
{
    "id": "018NY6XC00VTHTTQVRBK27ZAHT",    // Unique UUID (industry standard)
    "name": "$100 OG",                      // Human-readable strain name
    "stub": "100og",                        // URL-friendly identifier
    "type": null                            // Strain type (mostly null in dataset)
}
```

### **Key Findings from 3,000+ Strain Analysis**
- ✅ **Universal Unique IDs**: Each strain has a UUID for cross-system compatibility
- ✅ **Standardized Naming**: Consistent strain name normalization
- ✅ **URL-Friendly Stubs**: SEO-optimized identifiers for web integration
- ⚠️ **Limited Type Classification**: Most "type" fields are null (not Indica/Sativa/Hybrid classified)

### **Integration Implications**
1. **Primary Value**: Strain name standardization and unique identification
2. **Secondary Value**: Industry-standard UUID system for interoperability
3. **Limited Value**: Strain type classification (would need separate taxonomy)

## 🚀 **FINAL INTEGRATION STRATEGY**

### **Phase 2A: Strain Name Standardization (2 weeks)**
- Import OpenTHC strain database as reference data
- Enhance **Hemp Strain Template** with OpenTHC UUID mapping
- Add strain name validation against industry standards
- Implement autocomplete with 3,000+ verified strain names

### **Phase 2B: Product Type Enhancement (1 week)**
- Add OpenTHC product type categories to **Hemp Product Item**
- Implement product classification dropdown
- Maintain existing SKU generation system

### **Phase 2C: Company Type Integration (1 week)**
- Enhance vendor/client profiles with OpenTHC company types
- Add license type tracking for compliance
- Extend business relationship categorization

**Status**: ✅ **ATOMIC STEP 11 COMPLETE - Complete OpenTHC taxonomy analysis and integration strategy finalized**

