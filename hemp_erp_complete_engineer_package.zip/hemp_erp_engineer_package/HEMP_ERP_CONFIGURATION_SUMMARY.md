# ⚙️ **HEMP ERP SYSTEM - CONFIGURATION SUMMARY**

## **📋 CONFIGURATION OVERVIEW**

**System Type**: Full-stack web application
**Deployment**: Production-ready with live URLs
**Environment**: Development + Production configurations

## **🎯 FRONTEND CONFIGURATION SUMMARY**

### **Package Dependencies (package.json)**
```json
{
  "name": "nexterp-hemp-frontend",
  "version": "0.0.0",
  "type": "module",
  
  "key_dependencies": {
    "react": "^19.1.0",
    "react-dom": "^19.1.0", 
    "react-router-dom": "^7.1.1",
    "lucide-react": "^0.468.0",
    "@radix-ui/react-*": "1.1.x (multiple UI components)"
  },
  
  "dev_dependencies": {
    "vite": "^6.0.3",
    "tailwindcss": "^3.4.17",
    "@vitejs/plugin-react": "^4.3.4",
    "eslint": "^9.15.0"
  },
  
  "scripts": {
    "dev": "vite --host 0.0.0.0 --port 5176",
    "build": "vite build",
    "preview": "vite preview --host 0.0.0.0 --port 5176",
    "dev:external": "vite --host 0.0.0.0 --port 5176 --force"
  }
}
```

### **Vite Configuration (vite.config.js)**
```javascript
// Key settings for external access and path resolution
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { "@": path.resolve(__dirname, "./src") }
  },
  server: {
    host: '0.0.0.0',        // Allow external connections
    port: 5176,             // Development port
    strictPort: true,       // Fail if port unavailable
    allowedHosts: 'all'     // Bypass host validation (attempted fix)
  },
  preview: {
    host: '0.0.0.0',
    port: 5176
  }
})
```

### **Environment Variables**
```bash
# Development (.env.development)
VITE_NEXTERP_BASE_URL=http://72.60.67.104:8000
VITE_NEXTERP_API_KEY=c4ca4238a0b923820dcc509a6f75849b
VITE_NEXTERP_API_SECRET=c81e728d9d4c2f636f067f89cc14862c
VITE_API_BASE_URL=http://localhost:5000
VITE_APP_ENV=development

# Production (.env.production)
VITE_NEXTERP_BASE_URL=http://72.60.67.104:8000
VITE_NEXTERP_API_KEY=c4ca4238a0b923820dcc509a6f75849b
VITE_NEXTERP_API_SECRET=c81e728d9d4c2f636f067f89cc14862c
VITE_API_BASE_URL=https://dyh6i3cvyy5z.manus.space
VITE_APP_ENV=production
```

### **Tailwind CSS Configuration**
```javascript
// Comprehensive UI framework setup
module.exports = {
  darkMode: ["class"],
  content: [
    './pages/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
    './src/**/*.{js,jsx}'
  ],
  theme: {
    extend: {
      colors: {
        // Custom color palette for hemp industry
        primary: "hsl(var(--primary))",
        secondary: "hsl(var(--secondary))",
        // ... extensive color system
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)"
      }
    }
  },
  plugins: [require("tailwindcss-animate")]
}
```

### **Production Server Configuration (serve-production.cjs)**
```javascript
// Custom HTTP server for production deployment
const server = http.createServer((req, res) => {
  // CORS headers for cross-origin requests
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
  
  // SPA routing support (serve index.html for all routes)
  let filePath = path.join(DIST_DIR, req.url === '/' ? 'index.html' : req.url)
  if (!path.extname(filePath) && !fs.existsSync(filePath)) {
    filePath = path.join(DIST_DIR, 'index.html')
  }
  
  // MIME type handling for static assets
  const contentType = mimeTypes[path.extname(filePath)] || 'application/octet-stream'
})

server.listen(5179, '0.0.0.0')  // Production port
```

## **🔧 BACKEND CONFIGURATION SUMMARY**

### **Python Dependencies (requirements.txt)**
```txt
# Core framework
Flask==3.1.0
gunicorn==23.0.0

# Security and authentication
Flask-JWT-Extended==4.7.1
Flask-CORS==5.0.0
Flask-Limiter==3.8.0

# HTTP client for NextERP integration
requests==2.32.3

# Utilities
python-dotenv==1.0.1
```

### **Flask Application Configuration (main.py)**
```python
# Core Flask setup with security
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')
app.config['JWT_SECRET_KEY'] = os.getenv('SECRET_KEY')
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=1)

# CORS configuration for cross-origin requests
CORS(app, 
     origins=os.getenv('CORS_ORIGINS', '').split(','),
     supports_credentials=True)

# Rate limiting for security
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# Security headers
@app.after_request
def after_request(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    return response
```

### **Gunicorn Configuration (gunicorn.conf.py)**
```python
# Production WSGI server configuration
bind = "0.0.0.0:5000"
workers = 4
worker_class = "sync"
worker_connections = 1000
max_requests = 1000
max_requests_jitter = 50
timeout = 30
keepalive = 2

# Logging
accesslog = "-"
errorlog = "-"
loglevel = "info"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"'
```

### **Environment Variables**
```bash
# Development (.env)
FLASK_ENV=development
SECRET_KEY=HempERP_Secret_Key_2025_Development
NEXTERP_BASE_URL=http://72.60.67.104:8000
NEXTERP_API_KEY=c4ca4238a0b923820dcc509a6f75849b
NEXTERP_API_SECRET=c81e728d9d4c2f636f067f89cc14862c
CORS_ORIGINS=http://localhost:5173,http://localhost:5176

# Production (.env.production)
FLASK_ENV=production
SECRET_KEY=HempERP_Secret_Key_2025_Production_Secure
NEXTERP_BASE_URL=http://72.60.67.104:8000
NEXTERP_API_KEY=c4ca4238a0b923820dcc509a6f75849b
NEXTERP_API_SECRET=c81e728d9d4c2f636f067f89cc14862c
CORS_ORIGINS=https://5179-ird2lfpa80ntx2pcjnd61-b4881cc0.manusvm.computer
```

## **🔗 INTEGRATION CONFIGURATION**

### **NextERP API Configuration**
```javascript
// Frontend API client configuration
class NextERPAPI {
  constructor() {
    this.baseURL = import.meta.env.VITE_API_BASE_URL
    this.nexterpBaseURL = import.meta.env.VITE_NEXTERP_BASE_URL
    this.apiKey = import.meta.env.VITE_NEXTERP_API_KEY
    this.apiSecret = import.meta.env.VITE_NEXTERP_API_SECRET
  }
  
  getAuthHeaders() {
    return {
      'Authorization': `token ${this.apiKey}:${this.apiSecret}`,
      'Content-Type': 'application/json'
    }
  }
}
```

```python
# Backend NextERP integration
NEXTERP_CONFIG = {
    'base_url': os.getenv('NEXTERP_BASE_URL'),
    'api_key': os.getenv('NEXTERP_API_KEY'),
    'api_secret': os.getenv('NEXTERP_API_SECRET'),
    'timeout': 30,
    'retry_attempts': 3
}

def get_nexterp_headers():
    return {
        'Authorization': f"token {NEXTERP_CONFIG['api_key']}:{NEXTERP_CONFIG['api_secret']}",
        'Content-Type': 'application/json'
    }
```

## **🚀 DEPLOYMENT CONFIGURATION**

### **Production URLs**
```
Frontend: https://5179-ird2lfpa80ntx2pcjnd61-b4881cc0.manusvm.computer
Backend:  https://dyh6i3cvyy5z.manus.space
NextERP:  http://72.60.67.104:8000
```

### **Port Configuration**
```
Development:
- Frontend: 5176 (Vite dev server)
- Backend:  5000 (Flask development)
- Production Server: 5179 (Custom HTTP server)

Production:
- Frontend: 5179 (Custom HTTP server)
- Backend:  Deployed via Manus service
- NextERP:  8000 (External service)
```

### **Security Configuration**
```python
# JWT Configuration
JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=1)
JWT_ALGORITHM = 'HS256'

# Rate Limiting
RATE_LIMITS = {
    'login': "5 per minute",
    'api_general': "200 per day, 50 per hour",
    'nexterp_operations': "100 per hour"
}

# CORS Policy
CORS_ORIGINS = [
    'http://localhost:5176',  # Development
    'https://5179-ird2lfpa80ntx2pcjnd61-b4881cc0.manusvm.computer'  # Production
]
```

## **📊 PERFORMANCE CONFIGURATION**

### **Frontend Optimization**
```javascript
// Vite build optimization
build: {
  rollupOptions: {
    output: {
      manualChunks: {
        vendor: ['react', 'react-dom'],
        ui: ['@radix-ui/react-dialog', '@radix-ui/react-button']
      }
    }
  },
  chunkSizeWarningLimit: 1000
}
```

### **Backend Optimization**
```python
# Gunicorn worker configuration
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = "sync"
max_requests = 1000
max_requests_jitter = 50
preload_app = True
```

## **🔍 MONITORING CONFIGURATION**

### **Logging Setup**
```python
# Backend logging
LOGGING_CONFIG = {
    'version': 1,
    'formatters': {
        'default': {
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        }
    },
    'handlers': {
        'file': {
            'class': 'logging.FileHandler',
            'filename': 'hemp_erp.log',
            'formatter': 'default'
        }
    },
    'root': {
        'level': 'INFO',
        'handlers': ['file']
    }
}
```

### **Health Check Endpoints**
```python
@app.route('/health')
def health_check():
    return {
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '1.0.0',
        'nexterp_connectivity': check_nexterp_connection()
    }
```

## **⚙️ DEVELOPMENT TOOLS CONFIGURATION**

### **ESLint Configuration**
```javascript
// Code quality and React best practices
export default [
  {
    files: ['**/*.{js,jsx}'],
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
    },
    plugins: {
      react: reactPlugin,
      'react-hooks': reactHooks,
      'react-refresh': reactRefresh,
    },
    rules: {
      'react-hooks/rules-of-hooks': 'error',
      'react-hooks/exhaustive-deps': 'warn',
    }
  }
]
```

### **Git Configuration**
```bash
# Repository structure
.git/
├── hooks/          # Git hooks for quality control
├── config          # Repository configuration
└── refs/           # Branch references

# Key branches
- main: Production-ready code
- development: Active development
- feature/*: Feature branches
```

---

**This configuration summary provides all essential settings without overwhelming file details, enabling quick understanding and modification of the Hemp ERP system.**

