# NextERP Integration Template
# Apply this pattern to all NextERP API integrations

import os
import requests
from flask import jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from functools import wraps

# 1. Environment Variables (.env file)
"""
# NextERP API Configuration
NEXTERP_API_KEY=your_api_key
NEXTERP_API_SECRET=your_api_secret
NEXTERP_BASE_URL=http://your-nexterp-domain.com/api/resource
"""

# 2. Authentication Decorator
def require_permission(permission):
    def decorator(f):
        @wraps(f)
        @jwt_required()
        def decorated_function(*args, **kwargs):
            current_user = get_jwt_identity()
            # Add permission checking logic here
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# 3. NextERP API Client
def make_nexterp_request(endpoint, method='GET', data=None, fields=None):
    """
    Standard NextERP API request function
    """
    try:
        api_key = os.getenv('NEXTERP_API_KEY')
        api_secret = os.getenv('NEXTERP_API_SECRET')
        base_url = os.getenv('NEXTERP_BASE_URL')
        
        if not all([api_key, api_secret, base_url]):
            raise ValueError("NextERP API credentials not configured")
        
        url = f"{base_url}/{endpoint}"
        headers = {
            'Authorization': f'token {api_key}:{api_secret}',
            'Content-Type': 'application/json'
        }
        
        params = {}
        if fields:
            params['fields'] = json.dumps(fields)
        
        if method == 'GET':
            response = requests.get(url, headers=headers, params=params)
        elif method == 'POST':
            response = requests.post(url, headers=headers, json=data)
        elif method == 'PUT':
            response = requests.put(url, headers=headers, json=data)
        elif method == 'DELETE':
            response = requests.delete(url, headers=headers)
        
        response.raise_for_status()
        return response.json()
        
    except requests.exceptions.RequestException as e:
        raise Exception(f"NextERP API error: {str(e)}")

# 4. Data Transformation Pattern
def transform_nexterp_data(nexterp_response, field_mapping):
    """
    Standard data transformation for NextERP responses
    """
    if 'data' not in nexterp_response:
        return []
    
    transformed_data = []
    for item in nexterp_response['data']:
        transformed_item = {}
        for nexterp_field, frontend_field in field_mapping.items():
            transformed_item[frontend_field] = item.get(nexterp_field, '')
        transformed_data.append(transformed_item)
    
    return transformed_data

# 5. Standard Route Pattern
@app.route('/api/nexterp/<doctype>', methods=['GET'])
@require_permission('nexterp:read')
def get_nexterp_documents(doctype):
    try:
        # Define field mapping for this doctype
        field_mapping = {
            'name': 'id',
            'client_name': 'name',
            'email': 'email',
            'phone': 'phone',
            'license_number': 'licenseNumber',
            'creation': 'createdDate'
        }
        
        # Get data from NextERP
        nexterp_response = make_nexterp_request(
            doctype,
            fields=list(field_mapping.keys())
        )
        
        # Transform data for frontend
        transformed_data = transform_nexterp_data(nexterp_response, field_mapping)
        
        return jsonify({
            'data': transformed_data,
            'success': True
        })
        
    except Exception as e:
        return jsonify({
            'error': str(e),
            'success': False
        }), 500

# 6. Error Handling Pattern
class NextERPAPIError(Exception):
    def __init__(self, message, status_code=500):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)

# 7. Testing Pattern
def test_nexterp_integration():
    """
    Standard test for NextERP integration
    """
    try:
        response = make_nexterp_request('Hemp Client Profile', fields=['name', 'client_name'])
        assert 'data' in response
        print("✅ NextERP integration test passed")
        return True
    except Exception as e:
        print(f"❌ NextERP integration test failed: {e}")
        return False

