# Cannabis ERP UI - Manual Testing Checklist

## 🎯 **MANUAL TESTING OVERVIEW**

**Purpose**: Comprehensive manual validation to complement automated testing  
**Focus**: User experience, visual validation, edge cases, and scenarios difficult to automate  
**Duration**: 4-6 hours for complete manual testing cycle  
**Frequency**: Before each release and after major changes  

---

## 📋 **PRE-TESTING SETUP**

### **Environment Preparation**
- [ ] Clear browser cache and cookies
- [ ] Disable browser extensions that might interfere
- [ ] Ensure stable internet connection
- [ ] Have test data ready (customer names, product names, etc.)
- [ ] Open browser developer tools for console monitoring
- [ ] Prepare screenshot capture tool
- [ ] Set up multiple browser tabs for cross-reference testing

### **Test Data Preparation**
- [ ] **Test Products**: Hemp Flower varieties with different strains
- [ ] **Test Customers**: Various business types and license numbers
- [ ] **Test Vendors**: Different supplier categories and locations
- [ ] **Edge Case Data**: Special characters, very long names, empty fields
- [ ] **Invalid Data**: Malformed emails, invalid phone numbers

---

## 🏠 **PHASE 1: INITIAL LOAD & NAVIGATION**

### **1.1 Application Loading**
- [ ] **URL Access**: Navigate to Cannabis ERP UI URL
- [ ] **Loading Time**: Page loads within 3 seconds
- [ ] **Visual Elements**: All UI elements render correctly
- [ ] **Console Errors**: No JavaScript errors in browser console
- [ ] **Responsive Layout**: Page adapts to browser window size
- [ ] **Branding**: Cannabis ERP logo and branding visible
- [ ] **Color Scheme**: Green theme applied consistently

**Visual Validation:**
- [ ] Header displays correctly with search bar
- [ ] Sidebar navigation visible with all 7 sections
- [ ] Main content area renders without layout issues
- [ ] Footer (if present) displays properly
- [ ] No broken images or missing icons

### **1.2 Primary Navigation Testing**
- [ ] **Intake**: Click navigates to product intake form
- [ ] **Inventory**: Click shows inventory management page
- [ ] **Orders**: Click displays order management interface
- [ ] **Vendors**: Click shows vendor profile list
- [ ] **Customers**: Click displays customer profile list
- [ ] **Accounting**: Click shows financial dashboard
- [ ] **Settings**: Click navigates to system settings

**Navigation Validation:**
- [ ] Active page highlighted in sidebar
- [ ] Page titles update correctly
- [ ] URL changes reflect navigation
- [ ] Back button works correctly
- [ ] Forward button works correctly

### **1.3 Mobile Navigation**
- [ ] **Resize Browser**: Test at 375px width (mobile)
- [ ] **Mobile Menu**: Hamburger menu appears and functions
- [ ] **Touch Targets**: All buttons large enough for touch
- [ ] **Scrolling**: Smooth scrolling on mobile devices
- [ ] **Orientation**: Test both portrait and landscape modes

---

## 📊 **PHASE 2: DATA DISPLAY & MANAGEMENT**

### **2.1 Inventory Management**
- [ ] **Data Loading**: Inventory table loads with product data
- [ ] **Column Headers**: Name, Strain, Vendor, Updated columns visible
- [ ] **Data Accuracy**: Product information displays correctly
- [ ] **Row Formatting**: Consistent row styling and spacing
- [ ] **Pagination**: If present, pagination controls work
- [ ] **Sorting**: Click column headers to sort data
- [ ] **Empty State**: Proper message if no products exist

**Data Validation:**
- [ ] Product names display completely (no truncation)
- [ ] Strain names link correctly to strain information
- [ ] Vendor names link correctly to vendor profiles
- [ ] Dates format consistently (MM/DD/YYYY)
- [ ] SKU codes display properly

### **2.2 Search Functionality**
- [ ] **Search Box**: Search input field visible and accessible
- [ ] **Real-time Search**: Results filter as you type
- [ ] **Case Insensitive**: Search works regardless of case
- [ ] **Partial Matches**: Finds products with partial name matches
- [ ] **Clear Search**: Empty search shows all results
- [ ] **No Results**: Proper message when no matches found

**Search Edge Cases:**
- [ ] **Special Characters**: Search with @, #, $, %, etc.
- [ ] **Numbers**: Search with numeric values
- [ ] **Spaces**: Leading/trailing spaces handled correctly
- [ ] **Very Long Terms**: Long search terms don't break layout
- [ ] **Unicode**: International characters work correctly

### **2.3 Customer Management**
- [ ] **Customer List**: All customers display in table format
- [ ] **Contact Information**: Email, phone, address visible
- [ ] **License Numbers**: Business licenses display correctly
- [ ] **Customer Codes**: Unique codes assigned and visible
- [ ] **Performance Metrics**: Customer performance data shown
- [ ] **Profile Access**: Click customer name opens profile

**Customer Data Validation:**
- [ ] Email addresses formatted correctly
- [ ] Phone numbers formatted consistently
- [ ] License numbers display completely
- [ ] Customer status indicators work
- [ ] Payment history accessible

### **2.4 Vendor Management**
- [ ] **Vendor List**: All vendors display in organized table
- [ ] **Vendor Details**: Company name, contact, license visible
- [ ] **Performance Tracking**: Vendor metrics displayed
- [ ] **Quality Ratings**: Rating system functional
- [ ] **Order History**: Past orders accessible
- [ ] **Payment Terms**: Terms and conditions visible

**Vendor Data Validation:**
- [ ] Vendor codes unique and consistent
- [ ] Contact information complete
- [ ] Performance calculations accurate
- [ ] Quality ratings update correctly
- [ ] Payment status tracking works

---

## 📝 **PHASE 3: FORM FUNCTIONALITY**

### **3.1 Product Intake Form**
- [ ] **Form Access**: "New Product" button navigates to intake form
- [ ] **Form Layout**: Professional, clean form design
- [ ] **Field Labels**: Clear, descriptive field labels
- [ ] **Required Fields**: Asterisk (*) indicates required fields
- [ ] **Field Types**: Appropriate input types for each field

**Form Fields Validation:**
- [ ] **Product Name**: Text input accepts alphanumeric characters
- [ ] **Strain Selection**: Dropdown populated with available strains
- [ ] **Vendor Selection**: Dropdown shows active vendors
- [ ] **Additional Fields**: Any other fields render correctly

### **3.2 Form Input Testing**
- [ ] **Valid Data Entry**: Form accepts proper product information
- [ ] **Field Validation**: Required fields show error when empty
- [ ] **Character Limits**: Long inputs handled appropriately
- [ ] **Special Characters**: Form handles special characters safely
- [ ] **Dropdown Selection**: All dropdown options selectable

**Input Edge Cases:**
- [ ] **Empty Submission**: Form prevents submission with empty required fields
- [ ] **Maximum Length**: Very long product names handled correctly
- [ ] **Minimum Length**: Single character entries work
- [ ] **Copy/Paste**: Pasted content works correctly
- [ ] **Tab Navigation**: Tab key moves between fields logically

### **3.3 Form Submission**
- [ ] **Submit Button**: "Create Product" button clearly visible
- [ ] **Submission Process**: Form submits without errors
- [ ] **Success Feedback**: Success message or redirect occurs
- [ ] **Data Persistence**: New product appears in inventory
- [ ] **Form Reset**: Form clears after successful submission
- [ ] **Error Handling**: Submission errors display clearly

**Submission Validation:**
- [ ] Network interruption during submission handled
- [ ] Duplicate product name prevention
- [ ] Server error responses handled gracefully
- [ ] Form remains usable after errors
- [ ] Cancel button returns to inventory

---

## 💰 **PHASE 4: PAYMENT RESTRICTIONS**

### **4.1 Accounting Dashboard**
- [ ] **Restriction Warning**: Prominent CASH/CHECK only warning visible
- [ ] **Warning Styling**: Warning uses appropriate colors/styling
- [ ] **Module Access**: All 9 accounting modules accessible
- [ ] **Financial Widgets**: Balance widgets display correctly
- [ ] **Module Descriptions**: Each module has clear description

**Accounting Modules Validation:**
- [ ] **Invoices**: Customer invoices and billing module
- [ ] **Bills**: Vendor bills and payables module
- [ ] **Payments**: CASH/CHECK payments only module
- [ ] **Credit Notes**: Customer credit notes module
- [ ] **Chart of Accounts**: Account structure (preset) module
- [ ] **Journal Entries**: Manual journal entries module
- [ ] **Ledgers**: General ledger reports module
- [ ] **Banks**: Bank and cash accounts module
- [ ] **Reconcile**: Bank reconciliation module

### **4.2 Payment Method Enforcement**
- [ ] **Allowed Methods**: Only CASH and CHECK options visible
- [ ] **Restricted Methods**: No credit card, wire, PayPal options
- [ ] **Method Selection**: Payment method dropdowns limited correctly
- [ ] **Warning Messages**: Restrictions explained clearly
- [ ] **Help Text**: Additional guidance provided

**Restriction Validation:**
- [ ] **UI Enforcement**: Restricted methods not selectable
- [ ] **Form Validation**: Invalid methods rejected
- [ ] **Error Messages**: Clear errors for invalid payment attempts
- [ ] **Compliance Text**: Regulatory compliance information visible

### **4.3 Payment Processing**
- [ ] **Payment Forms**: Payment entry forms functional
- [ ] **Method Validation**: Only allowed methods accepted
- [ ] **Amount Validation**: Proper currency formatting
- [ ] **Date Validation**: Payment dates validated
- [ ] **Reference Numbers**: Check numbers, cash receipt tracking

---

## 📱 **PHASE 5: RESPONSIVE DESIGN**

### **5.1 Desktop Testing (1920x1080)**
- [ ] **Full Layout**: All elements visible without scrolling
- [ ] **Sidebar Width**: Appropriate sidebar proportions
- [ ] **Content Area**: Main content uses available space efficiently
- [ ] **Table Display**: Data tables fit comfortably
- [ ] **Form Layout**: Forms well-proportioned and readable

### **5.2 Laptop Testing (1366x768)**
- [ ] **Layout Adaptation**: Interface adapts to smaller screen
- [ ] **Scrolling**: Minimal horizontal scrolling required
- [ ] **Element Sizing**: UI elements appropriately sized
- [ ] **Text Readability**: All text remains readable
- [ ] **Button Accessibility**: All buttons easily clickable

### **5.3 Tablet Testing (768x1024)**
- [ ] **Touch Interface**: Elements sized for touch interaction
- [ ] **Layout Stacking**: Elements stack appropriately
- [ ] **Navigation**: Touch navigation works smoothly
- [ ] **Form Usability**: Forms remain usable on tablet
- [ ] **Table Scrolling**: Data tables scroll horizontally if needed

### **5.4 Mobile Testing (375x667)**
- [ ] **Mobile Layout**: Interface optimized for mobile
- [ ] **Touch Targets**: All interactive elements touch-friendly
- [ ] **Text Size**: Text large enough to read without zooming
- [ ] **Navigation Menu**: Mobile navigation menu functional
- [ ] **Form Fields**: Form fields appropriately sized
- [ ] **Scrolling**: Smooth vertical scrolling
- [ ] **Orientation**: Works in both portrait and landscape

---

## 🔍 **PHASE 6: EDGE CASES & ERROR SCENARIOS**

### **6.1 Data Edge Cases**
- [ ] **Empty Database**: Application handles no data gracefully
- [ ] **Large Datasets**: Performance with 1000+ records
- [ ] **Long Text**: Very long product/customer names
- [ ] **Special Characters**: Unicode, emojis, symbols
- [ ] **Null Values**: Missing or null data handled correctly

### **6.2 Network Edge Cases**
- [ ] **Slow Connection**: Application usable on slow networks
- [ ] **Connection Loss**: Handles network interruptions
- [ ] **Server Errors**: 500 errors handled gracefully
- [ ] **Timeout Errors**: Request timeouts handled properly
- [ ] **API Failures**: Backend API failures handled

### **6.3 Browser Edge Cases**
- [ ] **Browser Refresh**: State preserved across refreshes
- [ ] **Back/Forward**: Browser navigation works correctly
- [ ] **Multiple Tabs**: Application works in multiple tabs
- [ ] **Bookmarking**: Deep links work when bookmarked
- [ ] **Cache Issues**: Cache clearing doesn't break functionality

### **6.4 User Input Edge Cases**
- [ ] **Copy/Paste**: Large amounts of pasted text
- [ ] **Keyboard Navigation**: Tab, Enter, Escape keys work
- [ ] **Accessibility**: Screen reader compatibility
- [ ] **Autocomplete**: Browser autocomplete works correctly
- [ ] **Form Validation**: Client-side validation comprehensive

---

## 🔒 **PHASE 7: SECURITY TESTING**

### **7.1 Input Security**
- [ ] **XSS Prevention**: Script tags in input don't execute
- [ ] **SQL Injection**: Database queries protected
- [ ] **HTML Injection**: HTML tags in input handled safely
- [ ] **URL Manipulation**: Direct URL access properly controlled
- [ ] **Parameter Tampering**: URL parameters validated

**Security Test Cases:**
- [ ] Enter `<script>alert('xss')</script>` in product name
- [ ] Enter `'; DROP TABLE products; --` in search
- [ ] Enter `<img src=x onerror=alert('xss')>` in forms
- [ ] Modify URL parameters to access unauthorized data
- [ ] Test with malformed JSON in API requests

### **7.2 Authentication Security**
- [ ] **Session Management**: Sessions expire appropriately
- [ ] **Unauthorized Access**: Protected pages require authentication
- [ ] **Password Security**: Passwords handled securely
- [ ] **CSRF Protection**: Cross-site request forgery prevented
- [ ] **Data Access**: Users only see authorized data

---

## ⚡ **PHASE 8: PERFORMANCE VALIDATION**

### **8.1 Load Performance**
- [ ] **Initial Load**: Page loads within 3 seconds
- [ ] **Navigation Speed**: Page transitions under 1 second
- [ ] **Search Performance**: Search results appear quickly
- [ ] **Form Submission**: Forms submit within 2 seconds
- [ ] **Data Loading**: Tables populate within 2 seconds

### **8.2 Resource Usage**
- [ ] **Memory Usage**: No excessive memory consumption
- [ ] **CPU Usage**: Application doesn't cause high CPU usage
- [ ] **Network Usage**: Efficient API calls, no excessive requests
- [ ] **Storage Usage**: Local storage used appropriately
- [ ] **Battery Impact**: Minimal battery drain on mobile devices

### **8.3 Stress Testing**
- [ ] **Rapid Clicking**: Multiple rapid clicks handled correctly
- [ ] **Form Spam**: Rapid form submissions handled
- [ ] **Search Spam**: Rapid search queries handled
- [ ] **Navigation Spam**: Rapid navigation handled
- [ ] **Concurrent Actions**: Multiple simultaneous actions work

---

## 🎯 **PHASE 9: USER EXPERIENCE VALIDATION**

### **9.1 Visual Design**
- [ ] **Consistent Styling**: Uniform colors, fonts, spacing
- [ ] **Professional Appearance**: Clean, business-appropriate design
- [ ] **Cannabis Branding**: Appropriate cannabis industry styling
- [ ] **Icon Usage**: Icons clear and meaningful
- [ ] **Color Contrast**: Text readable against backgrounds
- [ ] **Visual Hierarchy**: Important elements stand out

### **9.2 Usability Testing**
- [ ] **Intuitive Navigation**: Users can find features easily
- [ ] **Clear Labels**: All buttons and fields clearly labeled
- [ ] **Helpful Messages**: Error and success messages helpful
- [ ] **Logical Flow**: Workflows follow logical sequences
- [ ] **Minimal Clicks**: Common tasks require few clicks
- [ ] **Undo Capability**: Users can reverse actions when appropriate

### **9.3 Accessibility**
- [ ] **Keyboard Navigation**: All features accessible via keyboard
- [ ] **Screen Reader**: Compatible with screen reading software
- [ ] **Color Blindness**: Interface usable for color-blind users
- [ ] **Font Scaling**: Text remains usable when browser font size increased
- [ ] **Focus Indicators**: Clear focus indicators for keyboard users

---

## 📊 **TESTING RESULTS DOCUMENTATION**

### **Issue Tracking Template**
For each issue found:
```
Issue ID: [Unique identifier]
Severity: [Critical/High/Medium/Low]
Component: [Navigation/Forms/Data/etc.]
Description: [Clear description of the issue]
Steps to Reproduce:
1. [Step 1]
2. [Step 2]
3. [Step 3]
Expected Result: [What should happen]
Actual Result: [What actually happened]
Browser: [Chrome/Firefox/Safari/Edge]
Device: [Desktop/Tablet/Mobile]
Screenshot: [Attach if applicable]
Notes: [Additional observations]
```

### **Severity Definitions**
- **Critical**: Application unusable, data loss, security vulnerability
- **High**: Major feature broken, significant user impact
- **Medium**: Minor feature issue, workaround available
- **Low**: Cosmetic issue, minimal user impact

### **Test Completion Criteria**
- [ ] **All Test Phases Completed**: 100% of manual tests executed
- [ ] **Zero Critical Issues**: No critical bugs remaining
- [ ] **High Issues Resolved**: All high-priority issues fixed
- [ ] **Documentation Complete**: All issues documented
- [ ] **Stakeholder Approval**: Testing results approved by stakeholders

---

## 🎉 **FINAL VALIDATION CHECKLIST**

### **Pre-Release Validation**
- [ ] **All Features Functional**: Every feature works as designed
- [ ] **Payment Restrictions Enforced**: CASH/CHECK only confirmed
- [ ] **Mobile Compatibility**: Full functionality on mobile devices
- [ ] **Performance Acceptable**: Meets performance benchmarks
- [ ] **Security Validated**: No security vulnerabilities found
- [ ] **User Experience Positive**: Interface intuitive and professional
- [ ] **Documentation Updated**: All documentation reflects current state
- [ ] **Stakeholder Sign-off**: Final approval received

### **Go-Live Readiness**
- [ ] **Production Environment**: Deployed to production successfully
- [ ] **Monitoring Active**: Error monitoring and logging active
- [ ] **Backup Systems**: Data backup systems operational
- [ ] **Support Documentation**: User guides and support materials ready
- [ ] **Training Complete**: Users trained on new interface
- [ ] **Rollback Plan**: Plan in place if issues arise
- [ ] **Success Metrics**: KPIs defined for measuring success

---

**This comprehensive manual testing checklist ensures thorough validation of all Cannabis ERP UI functionality, user experience, and edge cases before production deployment.**

