import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import path from 'path'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    host: '0.0.0.0',
    port: 5176,
    strictPort: true,
    // This is the key fix - disable host checking entirely
    hmr: {
      clientPort: 5176
    },
    // Alternative approach - use custom middleware to bypass host checking
    middlewareMode: false,
    // Configure allowed hosts (backup approach)
    allowedHosts: 'all'
  },
  // Add this to handle proxy-related issues
  define: {
    global: 'globalThis',
  },
  // Preview configuration for consistency
  preview: {
    host: '0.0.0.0',
    port: 5176,
    strictPort: true
  }
})
