# NextERP Hemp Frontend - API Documentation

## Overview
This document provides comprehensive API documentation for the NextERP Hemp Frontend integration, detailing all endpoints, authentication, and data structures used by the three Week 1 features.

## Authentication

### API Credentials
- **Base URL**: `http://72.60.67.104:8000`
- **Authentication Method**: Token-based authentication
- **API Key**: `fe3daf97feaace4`
- **API Secret**: `4ca8ea56e336cc4`
- **Authorization Header**: `token fe3daf97feaace4:4ca8ea56e336cc4`

### Request Headers
```javascript
{
  'Accept': 'application/json',
  'Content-Type': 'application/json',
  'Authorization': 'token fe3daf97feaace4:4ca8ea56e336cc4'
}
```

## Hemp DocTypes

### Available DocTypes
1. **Hemp Client Profile** - Customer management
2. **Hemp Vendor Profile** - Vendor management  
3. **Hemp Product Item** - Product catalog
4. **Hemp Sales Order** - Sales transactions
5. **Hemp Purchase Order** - Purchase transactions
6. **Hemp Strain Template** - Strain information

## API Endpoints

### 1. Hemp Client Profile (Customer Management)

#### List Clients
```
GET /api/resource/Hemp%20Client%20Profile
```

**Query Parameters**:
- `fields`: JSON array of field names to return
- `filters`: JSON object with filter conditions
- `limit`: Maximum number of records to return
- `start`: Offset for pagination

**Example Request**:
```javascript
const clients = await nexterpAPI.hemp.getClients({
  fields: ['name', 'company_name', 'customer_name', 'email', 'phone', 'address', 'contact_person'],
  limit: 50
});
```

**Response Format**:
```json
{
  "data": [
    {
      "name": "CUST-001",
      "company_name": "Hemp Wholesale Co",
      "customer_name": "John Smith",
      "email": "john@hempwholesale.com",
      "phone": "+1-555-0123",
      "address": "123 Hemp St, Cannabis City, CA",
      "contact_person": "John Smith"
    }
  ]
}
```

#### Get Single Client
```
GET /api/resource/Hemp%20Client%20Profile/{client_name}
```

#### Create Client
```
POST /api/resource/Hemp%20Client%20Profile
```

**Request Body**:
```json
{
  "company_name": "New Hemp Company",
  "customer_name": "Jane Doe",
  "email": "jane@newhempco.com",
  "phone": "+1-555-0456",
  "address": "456 Cannabis Ave, Hemp City, CA"
}
```

### 2. Hemp Vendor Profile (Vendor Management)

#### List Vendors
```
GET /api/resource/Hemp%20Vendor%20Profile
```

**Example Request**:
```javascript
const vendors = await nexterpAPI.hemp.getVendors({
  fields: ['name', 'company_name', 'contact_person', 'email', 'phone'],
  filters: { 'status': 'Active' }
});
```

**Response Format**:
```json
{
  "data": [
    {
      "name": "VEND-001",
      "company_name": "Premium Hemp Farms",
      "contact_person": "Bob Johnson",
      "email": "bob@premiumhemp.com",
      "phone": "+1-555-0789"
    }
  ]
}
```

### 3. Hemp Product Item (Product Catalog)

#### List Products
```
GET /api/resource/Hemp%20Product%20Item
```

**Example Request**:
```javascript
const products = await nexterpAPI.hemp.getProducts({
  fields: ['name', 'item_name', 'product_name', 'item_code', 'standard_rate'],
  filters: { 'is_stock_item': 1 }
});
```

**Response Format**:
```json
{
  "data": [
    {
      "name": "HEMP-001",
      "item_name": "Premium Hemp Flower",
      "product_name": "OG Kush Hemp",
      "item_code": "SKU-001234",
      "standard_rate": 150.00
    }
  ]
}
```

## Error Handling

### Error Response Format
```json
{
  "message": "Error description",
  "exc_type": "ValidationError",
  "exc": "Detailed error information"
}
```

### Common HTTP Status Codes
- **200**: Success
- **400**: Bad Request (validation errors)
- **401**: Unauthorized (authentication failed)
- **403**: Forbidden (insufficient permissions)
- **404**: Not Found (resource doesn't exist)
- **500**: Internal Server Error

### Error Handling Implementation
```javascript
try {
  const data = await nexterpAPI.hemp.getClients();
  return data;
} catch (error) {
  if (error instanceof NextERPAPIError) {
    console.error(`API Error (${error.status}):`, error.message);
    // Handle specific error types
    if (error.status === 401) {
      // Handle authentication error
    } else if (error.status === 404) {
      // Handle not found error
    }
  }
  throw error;
}
```

## Data Validation Rules

### Client Profile Validation
- **company_name**: Required, max 140 characters
- **email**: Valid email format, unique
- **phone**: Valid phone format
- **customer_name**: Required if company_name not provided

### Vendor Profile Validation
- **company_name**: Required, max 140 characters
- **contact_person**: Required, max 140 characters
- **email**: Valid email format
- **phone**: Valid phone format

### Product Item Validation
- **item_name**: Required, max 140 characters
- **item_code**: Required, unique, max 140 characters
- **standard_rate**: Positive number
- **is_stock_item**: Boolean (0 or 1)

## Rate Limiting

### API Limits
- **Requests per minute**: 100
- **Concurrent connections**: 10
- **Timeout**: 30 seconds per request

### Retry Logic
The API client implements automatic retry logic:
- **Retry attempts**: 3
- **Retry delay**: 1 second (exponential backoff)
- **Retry conditions**: HTTP 5xx errors only

## Security Considerations

### Authentication Security
- API keys should be rotated every 90 days
- Never expose API credentials in client-side code
- Use environment variables for credential storage

### Data Security
- All requests use HTTPS encryption
- Input validation on both client and server side
- SQL injection protection through parameterized queries

### Access Control
- Role-based access control through NextERP permissions
- User-specific data filtering
- Audit trail for all API operations

## Performance Optimization

### Caching Strategy
- Client-side caching for reference data
- Cache invalidation on data updates
- ETags for conditional requests

### Pagination
- Use `limit` and `start` parameters for large datasets
- Default limit: 20 records
- Maximum limit: 200 records

### Field Selection
- Always specify required fields to reduce payload size
- Avoid selecting large text fields unless necessary
- Use field aliases for complex queries

## Integration Examples

### Enhanced Payables Integration
```javascript
// Load vendor payables data
const loadPayables = async () => {
  try {
    const vendors = await nexterpAPI.hemp.getVendors({
      fields: ['name', 'company_name', 'contact_person', 'email', 'phone']
    });
    
    // Transform to payables format
    const payables = vendors.map((vendor, index) => ({
      name: `PO-${String(index + 1).padStart(4, '0')}`,
      vendor: vendor.company_name || vendor.name,
      contact_person: vendor.contact_person,
      email: vendor.email,
      phone: vendor.phone
    }));
    
    return payables;
  } catch (error) {
    console.error('Failed to load payables:', error);
    throw error;
  }
};
```

### Customer Workspace Integration
```javascript
// Load customer data with metrics
const loadCustomers = async () => {
  try {
    const clients = await nexterpAPI.hemp.getClients({
      fields: ['name', 'company_name', 'customer_name', 'email', 'phone', 'address']
    });
    
    // Enhance with business metrics
    const customers = clients.map(client => ({
      id: client.name,
      name: client.company_name || client.customer_name,
      email: client.email,
      phone: client.phone,
      address: client.address,
      // Add calculated metrics
      totalOrders: 0, // To be calculated from sales orders
      totalSpent: 0,  // To be calculated from invoices
      status: 'active'
    }));
    
    return customers;
  } catch (error) {
    console.error('Failed to load customers:', error);
    throw error;
  }
};
```

### Streamlined Sales Integration
```javascript
// Load sales data (customers + products)
const loadSalesData = async () => {
  try {
    const [clients, products] = await Promise.all([
      nexterpAPI.hemp.getClients({
        fields: ['name', 'company_name', 'customer_name', 'email']
      }),
      nexterpAPI.hemp.getProducts({
        fields: ['name', 'item_name', 'item_code', 'standard_rate']
      })
    ]);
    
    return { clients, products };
  } catch (error) {
    console.error('Failed to load sales data:', error);
    throw error;
  }
};
```

## Testing and Development

### API Testing
- Use Postman or similar tools for API testing
- Test all CRUD operations for each DocType
- Verify error handling and edge cases

### Development Environment
- Development server: `npm run dev`
- API endpoint: Same as production for consistency
- Test data: Use separate test DocTypes if available

### Debugging
- Enable console logging for API calls
- Use browser network tab to inspect requests
- Check NextERP logs for server-side errors

---

**Document Version**: 1.0  
**Last Updated**: August 26, 2025  
**Next Review**: September 26, 2025

