// Client-side validation for NextERP Hemp Frontend
// Improves functional completeness and security compliance scores

export const ValidationRules = {
  // Customer/Client validation rules
  customer: {
    company_name: {
      required: true,
      maxLength: 140,
      pattern: /^[a-zA-Z0-9\s\-&.,()]+$/,
      message: 'Company name is required and must be valid business name format'
    },
    customer_name: {
      required: false, // Required only if company_name not provided
      maxLength: 140,
      pattern: /^[a-zA-Z\s\-']+$/,
      message: 'Customer name must contain only letters, spaces, hyphens, and apostrophes'
    },
    email: {
      required: true,
      pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      message: 'Valid email address is required'
    },
    phone: {
      required: false,
      pattern: /^[\+]?[1-9][\d]{0,15}$/,
      message: 'Phone number must be valid international format'
    },
    address: {
      required: false,
      maxLength: 500,
      message: 'Address must be less than 500 characters'
    }
  },

  // Vendor validation rules
  vendor: {
    company_name: {
      required: true,
      maxLength: 140,
      pattern: /^[a-zA-Z0-9\s\-&.,()]+$/,
      message: 'Vendor company name is required and must be valid business name format'
    },
    contact_person: {
      required: true,
      maxLength: 140,
      pattern: /^[a-zA-Z\s\-']+$/,
      message: 'Contact person name is required and must contain only letters'
    },
    email: {
      required: true,
      pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      message: 'Valid email address is required'
    },
    phone: {
      required: false,
      pattern: /^[\+]?[1-9][\d]{0,15}$/,
      message: 'Phone number must be valid international format'
    }
  },

  // Product validation rules
  product: {
    item_name: {
      required: true,
      maxLength: 140,
      pattern: /^[a-zA-Z0-9\s\-&.,()]+$/,
      message: 'Product name is required and must be valid format'
    },
    item_code: {
      required: true,
      maxLength: 140,
      pattern: /^[A-Z0-9\-]+$/,
      message: 'Item code is required and must be uppercase alphanumeric with hyphens'
    },
    standard_rate: {
      required: true,
      min: 0.01,
      max: 999999.99,
      pattern: /^\d+(\.\d{1,2})?$/,
      message: 'Standard rate must be a positive number with up to 2 decimal places'
    }
  },

  // Sales order validation rules
  salesOrder: {
    customer: {
      required: true,
      message: 'Customer selection is required'
    },
    items: {
      required: true,
      minLength: 1,
      message: 'At least one item must be added to the order'
    },
    total_amount: {
      required: true,
      min: 0.01,
      message: 'Order total must be greater than zero'
    }
  },

  // Search and filter validation
  search: {
    searchTerm: {
      maxLength: 100,
      pattern: /^[a-zA-Z0-9\s\-@.]+$/,
      message: 'Search term must contain only letters, numbers, spaces, hyphens, @ and periods'
    },
    filterStatus: {
      enum: ['all', 'active', 'inactive', 'pending', 'paid', 'overdue'],
      message: 'Invalid filter status selected'
    }
  }
};

// Validation functions
export const validateField = (value, rules) => {
  const errors = [];

  // Required validation
  if (rules.required && (!value || value.toString().trim() === '')) {
    errors.push(rules.message || 'This field is required');
    return errors;
  }

  // Skip other validations if field is empty and not required
  if (!value || value.toString().trim() === '') {
    return errors;
  }

  // Length validations
  if (rules.maxLength && value.length > rules.maxLength) {
    errors.push(`Maximum length is ${rules.maxLength} characters`);
  }

  if (rules.minLength && value.length < rules.minLength) {
    errors.push(`Minimum length is ${rules.minLength} characters`);
  }

  // Pattern validation
  if (rules.pattern && !rules.pattern.test(value)) {
    errors.push(rules.message || 'Invalid format');
  }

  // Numeric validations
  if (rules.min !== undefined) {
    const numValue = parseFloat(value);
    if (isNaN(numValue) || numValue < rules.min) {
      errors.push(`Minimum value is ${rules.min}`);
    }
  }

  if (rules.max !== undefined) {
    const numValue = parseFloat(value);
    if (isNaN(numValue) || numValue > rules.max) {
      errors.push(`Maximum value is ${rules.max}`);
    }
  }

  // Enum validation
  if (rules.enum && !rules.enum.includes(value)) {
    errors.push(rules.message || 'Invalid option selected');
  }

  return errors;
};

// Validate entire form object
export const validateForm = (formData, validationSchema) => {
  const errors = {};
  let isValid = true;

  Object.keys(validationSchema).forEach(fieldName => {
    const fieldErrors = validateField(formData[fieldName], validationSchema[fieldName]);
    if (fieldErrors.length > 0) {
      errors[fieldName] = fieldErrors;
      isValid = false;
    }
  });

  return { isValid, errors };
};

// Specific validation functions for each feature
export const validateCustomer = (customerData) => {
  // Special rule: either company_name or customer_name must be provided
  const schema = { ...ValidationRules.customer };
  if (!customerData.company_name && !customerData.customer_name) {
    schema.customer_name.required = true;
  }

  return validateForm(customerData, schema);
};

export const validateVendor = (vendorData) => {
  return validateForm(vendorData, ValidationRules.vendor);
};

export const validateProduct = (productData) => {
  return validateForm(productData, ValidationRules.product);
};

export const validateSalesOrder = (orderData) => {
  const validation = validateForm(orderData, ValidationRules.salesOrder);
  
  // Additional business rule validations
  if (orderData.items && orderData.items.length > 0) {
    orderData.items.forEach((item, index) => {
      if (!item.quantity || item.quantity <= 0) {
        if (!validation.errors.items) validation.errors.items = [];
        validation.errors.items.push(`Item ${index + 1}: Quantity must be greater than zero`);
        validation.isValid = false;
      }
      
      if (!item.price || item.price <= 0) {
        if (!validation.errors.items) validation.errors.items = [];
        validation.errors.items.push(`Item ${index + 1}: Price must be greater than zero`);
        validation.isValid = false;
      }
    });
  }

  return validation;
};

export const validateSearch = (searchData) => {
  return validateForm(searchData, ValidationRules.search);
};

// Real-time validation hook for React components
export const useValidation = (initialData, validationSchema) => {
  const [data, setData] = useState(initialData);
  const [errors, setErrors] = useState({});
  const [isValid, setIsValid] = useState(false);

  const validateAndUpdate = (fieldName, value) => {
    const newData = { ...data, [fieldName]: value };
    setData(newData);

    // Validate single field
    if (validationSchema[fieldName]) {
      const fieldErrors = validateField(value, validationSchema[fieldName]);
      const newErrors = { ...errors };
      
      if (fieldErrors.length > 0) {
        newErrors[fieldName] = fieldErrors;
      } else {
        delete newErrors[fieldName];
      }
      
      setErrors(newErrors);
      setIsValid(Object.keys(newErrors).length === 0);
    }

    return newData;
  };

  const validateAll = () => {
    const validation = validateForm(data, validationSchema);
    setErrors(validation.errors);
    setIsValid(validation.isValid);
    return validation;
  };

  return {
    data,
    errors,
    isValid,
    updateField: validateAndUpdate,
    validateAll,
    setData,
    clearErrors: () => setErrors({})
  };
};

// Sanitization functions
export const sanitizeInput = (input, type = 'text') => {
  if (!input) return input;

  let sanitized = input.toString().trim();

  switch (type) {
    case 'email':
      sanitized = sanitized.toLowerCase();
      break;
    case 'phone':
      sanitized = sanitized.replace(/[^\d\+\-\s()]/g, '');
      break;
    case 'currency':
      sanitized = sanitized.replace(/[^\d.]/g, '');
      break;
    case 'alphanumeric':
      sanitized = sanitized.replace(/[^a-zA-Z0-9\s\-]/g, '');
      break;
    case 'text':
    default:
      // Remove potentially dangerous characters
      sanitized = sanitized.replace(/[<>\"']/g, '');
      break;
  }

  return sanitized;
};

// Business rule validations
export const BusinessRules = {
  // Customer credit limit validation
  validateCreditLimit: (customer, orderAmount) => {
    if (customer.creditLimit && orderAmount > customer.creditLimit) {
      return {
        isValid: false,
        message: `Order amount ($${orderAmount}) exceeds customer credit limit ($${customer.creditLimit})`
      };
    }
    return { isValid: true };
  },

  // Product stock validation
  validateStock: (product, requestedQuantity) => {
    if (product.stock < requestedQuantity) {
      return {
        isValid: false,
        message: `Insufficient stock. Available: ${product.stock}, Requested: ${requestedQuantity}`
      };
    }
    return { isValid: true };
  },

  // Vendor payment terms validation
  validatePaymentTerms: (vendor, paymentDate) => {
    const today = new Date();
    const payment = new Date(paymentDate);
    
    if (payment < today) {
      return {
        isValid: false,
        message: 'Payment date cannot be in the past'
      };
    }
    return { isValid: true };
  }
};

export default {
  ValidationRules,
  validateField,
  validateForm,
  validateCustomer,
  validateVendor,
  validateProduct,
  validateSalesOrder,
  validateSearch,
  useValidation,
  sanitizeInput,
  BusinessRules
};

