/**
 * Foundation Architecture Test Component
 * Comprehensive testing of NextERP Data Service, Transformers, and React Hooks
 * Validates cookie-cutter patterns before template creation
 */

import React, { useState, useEffect } from 'react';
import { CheckCircle, XCircle, Clock, AlertTriangle, RefreshCw } from 'lucide-react';

// Import foundation layers
import nexterpDataService from '../services/NextERPDataServiceFixed';
import { PayablesTransformer, CustomersTransformer, InventoryTransformer } from '../transformers/DataTransformers';
import { usePayables, useCustomers, useInventory } from '../hooks/useNextERPData';

const FoundationTest = () => {
  const [testResults, setTestResults] = useState({});
  const [currentTest, setCurrentTest] = useState(null);
  const [overallStatus, setOverallStatus] = useState('pending');

  // Test the React Hooks
  const payablesHook = usePayables();
  const customersHook = useCustomers();
  const inventoryHook = useInventory();

  const tests = [
    {
      id: 'data_service_connectivity',
      name: 'NextERP Data Service Connectivity',
      description: 'Test API connectivity and authentication'
    },
    {
      id: 'data_service_caching',
      name: 'Data Service Caching',
      description: 'Test cache functionality and performance'
    },
    {
      id: 'payables_transformer',
      name: 'Payables Transformer',
      description: 'Test Purchase Invoice data transformation'
    },
    {
      id: 'customers_transformer',
      name: 'Customers Transformer',
      description: 'Test Hemp Client Profile data transformation'
    },
    {
      id: 'inventory_transformer',
      name: 'Inventory Transformer',
      description: 'Test Hemp Product data transformation'
    },
    {
      id: 'payables_hook',
      name: 'Payables React Hook',
      description: 'Test usePayables hook functionality'
    },
    {
      id: 'customers_hook',
      name: 'Customers React Hook',
      description: 'Test useCustomers hook functionality'
    },
    {
      id: 'inventory_hook',
      name: 'Inventory React Hook',
      description: 'Test useInventory hook functionality'
    },
    {
      id: 'end_to_end',
      name: 'End-to-End Data Flow',
      description: 'Test complete data flow from API to UI'
    }
  ];

  const runTest = async (testId) => {
    setCurrentTest(testId);
    setTestResults(prev => ({
      ...prev,
      [testId]: { status: 'running', message: 'Running test...', startTime: Date.now() }
    }));

    try {
      let result;
      
      switch (testId) {
        case 'data_service_connectivity':
          result = await testDataServiceConnectivity();
          break;
        case 'data_service_caching':
          result = await testDataServiceCaching();
          break;
        case 'payables_transformer':
          result = await testPayablesTransformer();
          break;
        case 'customers_transformer':
          result = await testCustomersTransformer();
          break;
        case 'inventory_transformer':
          result = await testInventoryTransformer();
          break;
        case 'payables_hook':
          result = await testPayablesHook();
          break;
        case 'customers_hook':
          result = await testCustomersHook();
          break;
        case 'inventory_hook':
          result = await testInventoryHook();
          break;
        case 'end_to_end':
          result = await testEndToEnd();
          break;
        default:
          throw new Error('Unknown test');
      }

      setTestResults(prev => ({
        ...prev,
        [testId]: {
          status: 'passed',
          message: result.message,
          details: result.details,
          duration: Date.now() - prev[testId].startTime
        }
      }));

    } catch (error) {
      setTestResults(prev => ({
        ...prev,
        [testId]: {
          status: 'failed',
          message: error.message,
          error: error.stack,
          duration: Date.now() - prev[testId].startTime
        }
      }));
    }

    setCurrentTest(null);
  };

  const runAllTests = async () => {
    setOverallStatus('running');
    
    for (const test of tests) {
      await runTest(test.id);
      // Small delay between tests
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    // Calculate overall status
    const results = Object.values(testResults);
    const passed = results.filter(r => r.status === 'passed').length;
    const failed = results.filter(r => r.status === 'failed').length;
    
    if (failed === 0) {
      setOverallStatus('passed');
    } else if (passed > failed) {
      setOverallStatus('partial');
    } else {
      setOverallStatus('failed');
    }
  };

  // Individual test functions
  const testDataServiceConnectivity = async () => {
    // Test basic API connectivity
    const payables = await nexterpDataService.getPayables({ limit: 1 });
    const customers = await nexterpDataService.getCustomers({ limit: 1 });
    
    if (!Array.isArray(payables) || !Array.isArray(customers)) {
      throw new Error('API did not return expected array format');
    }

    return {
      message: 'API connectivity successful',
      details: {
        payablesCount: payables.length,
        customersCount: customers.length,
        apiEndpoint: 'NextERP REST API'
      }
    };
  };

  const testDataServiceCaching = async () => {
    // Clear cache first
    nexterpDataService.clearCache();
    
    // First call (should hit API)
    const start1 = Date.now();
    const data1 = await nexterpDataService.getPayables({ limit: 5 });
    const duration1 = Date.now() - start1;
    
    // Second call (should hit cache)
    const start2 = Date.now();
    const data2 = await nexterpDataService.getPayables({ limit: 5 });
    const duration2 = Date.now() - start2;
    
    if (duration2 >= duration1) {
      throw new Error('Cache not working - second call was not faster');
    }

    return {
      message: 'Caching working correctly',
      details: {
        firstCallDuration: duration1,
        secondCallDuration: duration2,
        speedImprovement: `${Math.round((duration1 - duration2) / duration1 * 100)}%`,
        cacheStats: nexterpDataService.getCacheStats()
      }
    };
  };

  const testPayablesTransformer = async () => {
    // Get raw data
    const rawData = await nexterpDataService.getPayables({ limit: 3 });
    
    // Transform data
    const transformed = PayablesTransformer.transform(rawData);
    
    if (!Array.isArray(transformed) || transformed.length === 0) {
      throw new Error('Transformer did not return expected format');
    }

    // Validate required fields
    const requiredFields = ['id', 'vendor', 'amount', 'dueDate', 'status'];
    const firstItem = transformed[0];
    
    for (const field of requiredFields) {
      if (!(field in firstItem)) {
        throw new Error(`Missing required field: ${field}`);
      }
    }

    // Test summary metrics
    const summary = PayablesTransformer.getSummaryMetrics(transformed);
    
    return {
      message: 'Payables transformer working correctly',
      details: {
        rawDataCount: rawData.length,
        transformedCount: transformed.length,
        sampleFields: Object.keys(firstItem),
        summaryMetrics: summary
      }
    };
  };

  const testCustomersTransformer = async () => {
    const rawData = await nexterpDataService.getCustomers({ limit: 3 });
    const transformed = CustomersTransformer.transform(rawData);
    
    if (!Array.isArray(transformed) || transformed.length === 0) {
      throw new Error('Transformer did not return expected format');
    }

    const requiredFields = ['id', 'name', 'email', 'status'];
    const firstItem = transformed[0];
    
    for (const field of requiredFields) {
      if (!(field in firstItem)) {
        throw new Error(`Missing required field: ${field}`);
      }
    }

    return {
      message: 'Customers transformer working correctly',
      details: {
        rawDataCount: rawData.length,
        transformedCount: transformed.length,
        sampleFields: Object.keys(firstItem)
      }
    };
  };

  const testInventoryTransformer = async () => {
    const rawData = await nexterpDataService.getInventory({ limit: 3 });
    const transformed = InventoryTransformer.transform(rawData);
    
    if (!Array.isArray(transformed) || transformed.length === 0) {
      throw new Error('Transformer did not return expected format');
    }

    const requiredFields = ['id', 'name', 'sku', 'quantity', 'status'];
    const firstItem = transformed[0];
    
    for (const field of requiredFields) {
      if (!(field in firstItem)) {
        throw new Error(`Missing required field: ${field}`);
      }
    }

    return {
      message: 'Inventory transformer working correctly',
      details: {
        rawDataCount: rawData.length,
        transformedCount: transformed.length,
        sampleFields: Object.keys(firstItem)
      }
    };
  };

  const testPayablesHook = async () => {
    // Wait for hook to load
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    if (payablesHook.loading) {
      throw new Error('Hook still loading after timeout');
    }

    if (payablesHook.error) {
      throw new Error(`Hook error: ${payablesHook.error}`);
    }

    if (!Array.isArray(payablesHook.data)) {
      throw new Error('Hook did not return array data');
    }

    return {
      message: 'Payables hook working correctly',
      details: {
        dataCount: payablesHook.data.length,
        hasError: !!payablesHook.error,
        isLoading: payablesHook.loading,
        hasSummaryMetrics: !!payablesHook.summaryMetrics
      }
    };
  };

  const testCustomersHook = async () => {
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    if (customersHook.loading) {
      throw new Error('Hook still loading after timeout');
    }

    if (customersHook.error) {
      throw new Error(`Hook error: ${customersHook.error}`);
    }

    return {
      message: 'Customers hook working correctly',
      details: {
        dataCount: customersHook.data.length,
        hasError: !!customersHook.error,
        isLoading: customersHook.loading
      }
    };
  };

  const testInventoryHook = async () => {
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    if (inventoryHook.loading) {
      throw new Error('Hook still loading after timeout');
    }

    if (inventoryHook.error) {
      throw new Error(`Hook error: ${inventoryHook.error}`);
    }

    return {
      message: 'Inventory hook working correctly',
      details: {
        dataCount: inventoryHook.data.length,
        hasError: !!inventoryHook.error,
        isLoading: inventoryHook.loading
      }
    };
  };

  const testEndToEnd = async () => {
    // Test complete data flow
    const payablesData = payablesHook.data;
    const customersData = customersHook.data;
    const inventoryData = inventoryHook.data;
    
    if (payablesData.length === 0 && customersData.length === 0 && inventoryData.length === 0) {
      throw new Error('No data available for end-to-end test');
    }

    return {
      message: 'End-to-end data flow working correctly',
      details: {
        payablesCount: payablesData.length,
        customersCount: customersData.length,
        inventoryCount: inventoryData.length,
        totalDataPoints: payablesData.length + customersData.length + inventoryData.length
      }
    };
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'passed':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'failed':
        return <XCircle className="w-5 h-5 text-red-600" />;
      case 'running':
        return <Clock className="w-5 h-5 text-blue-600 animate-spin" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'passed':
        return 'bg-green-50 border-green-200';
      case 'failed':
        return 'bg-red-50 border-red-200';
      case 'running':
        return 'bg-blue-50 border-blue-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Foundation Architecture Test</h1>
              <p className="text-gray-600 mt-1">
                Comprehensive testing of NextERP Data Service, Transformers, and React Hooks
              </p>
            </div>
            <button
              onClick={runAllTests}
              disabled={overallStatus === 'running'}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${overallStatus === 'running' ? 'animate-spin' : ''}`} />
              <span>Run All Tests</span>
            </button>
          </div>

          {/* Overall Status */}
          {overallStatus !== 'pending' && (
            <div className={`mt-4 p-4 rounded-lg border ${getStatusColor(overallStatus)}`}>
              <div className="flex items-center space-x-2">
                {getStatusIcon(overallStatus)}
                <span className="font-medium">
                  Overall Status: {overallStatus.charAt(0).toUpperCase() + overallStatus.slice(1)}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Test Results */}
        <div className="space-y-4">
          {tests.map(test => {
            const result = testResults[test.id];
            const isRunning = currentTest === test.id;
            
            return (
              <div
                key={test.id}
                className={`bg-white rounded-lg shadow-sm border p-6 ${
                  result ? getStatusColor(result.status) : 'border-gray-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(result?.status || 'pending')}
                    <div>
                      <h3 className="font-medium text-gray-900">{test.name}</h3>
                      <p className="text-sm text-gray-600">{test.description}</p>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => runTest(test.id)}
                    disabled={isRunning}
                    className="px-3 py-1 text-sm bg-gray-100 text-gray-700 rounded hover:bg-gray-200 disabled:opacity-50"
                  >
                    {isRunning ? 'Running...' : 'Run Test'}
                  </button>
                </div>

                {/* Test Results */}
                {result && (
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">
                        {result.message}
                      </span>
                      {result.duration && (
                        <span className="text-gray-500">
                          {result.duration}ms
                        </span>
                      )}
                    </div>
                    
                    {result.details && (
                      <div className="mt-2 p-3 bg-gray-50 rounded text-sm">
                        <pre className="text-gray-700 whitespace-pre-wrap">
                          {JSON.stringify(result.details, null, 2)}
                        </pre>
                      </div>
                    )}
                    
                    {result.error && (
                      <div className="mt-2 p-3 bg-red-50 rounded text-sm">
                        <pre className="text-red-700 whitespace-pre-wrap">
                          {result.error}
                        </pre>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default FoundationTest;

