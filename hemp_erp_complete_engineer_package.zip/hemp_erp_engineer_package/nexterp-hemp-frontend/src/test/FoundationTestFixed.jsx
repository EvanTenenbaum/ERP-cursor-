import React, { useState } from 'react';
import { NextERPDataService } from '../services/NextERPDataService';
import { CustomersTransformer } from '../transformers/DataTransformers';

const FoundationTestFixed = () => {
  const [testResults, setTestResults] = useState({});
  const [isRunning, setIsRunning] = useState(false);

  const runTests = async () => {
    setIsRunning(true);
    const results = {};

    // Test 1: NextERP Data Service Connectivity (Hemp Client Profile)
    try {
      console.log('Testing NextERP Data Service connectivity...');
      const clients = await NextERPDataService.getClients();
      results.dataService = {
        status: 'PASS',
        message: `Successfully retrieved ${clients.length} hemp client profiles`,
        data: clients.slice(0, 2) // Show first 2 for verification
      };
    } catch (error) {
      results.dataService = {
        status: 'FAIL',
        message: `Data service error: ${error.message}`,
        error: error.toString()
      };
    }

    // Test 2: Data Transformation (only if data service works)
    if (results.dataService.status === 'PASS') {
      try {
        console.log('Testing Data Transformation...');
        const rawData = results.dataService.data;
        const transformedData = CustomersTransformer.transform(rawData);
        
        results.transformation = {
          status: 'PASS',
          message: `Successfully transformed ${transformedData.length} client records`,
          data: transformedData,
          fieldMapping: {
            'client_name': transformedData[0]?.name,
            'email': transformedData[0]?.email,
            'phone': transformedData[0]?.phone,
            'license_number': transformedData[0]?.licenseNumber
          }
        };
      } catch (error) {
        results.transformation = {
          status: 'FAIL',
          message: `Transformation error: ${error.message}`,
          error: error.toString()
        };
      }
    } else {
      results.transformation = {
        status: 'SKIP',
        message: 'Skipped due to data service failure'
      };
    }

    // Test 3: Field Validation
    if (results.transformation.status === 'PASS') {
      const transformed = results.transformation.data[0];
      const requiredFields = ['id', 'name', 'email', 'phone', 'licenseNumber'];
      const missingFields = requiredFields.filter(field => !transformed[field]);
      
      results.fieldValidation = {
        status: missingFields.length === 0 ? 'PASS' : 'PARTIAL',
        message: missingFields.length === 0 
          ? 'All required fields present' 
          : `Missing fields: ${missingFields.join(', ')}`,
        fields: requiredFields.map(field => ({
          field,
          present: !!transformed[field],
          value: transformed[field] || 'MISSING'
        }))
      };
    } else {
      results.fieldValidation = {
        status: 'SKIP',
        message: 'Skipped due to transformation failure'
      };
    }

    setTestResults(results);
    setIsRunning(false);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'PASS': return 'text-green-600 bg-green-50';
      case 'FAIL': return 'text-red-600 bg-red-50';
      case 'PARTIAL': return 'text-yellow-600 bg-yellow-50';
      case 'SKIP': return 'text-gray-600 bg-gray-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          Foundation Architecture Test (Fixed)
        </h1>
        <p className="text-gray-600">
          Testing NextERP integration with corrected Hemp Client Profile field names
        </p>
      </div>

      <button
        onClick={runTests}
        disabled={isRunning}
        className="mb-6 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
      >
        {isRunning ? 'Running Tests...' : 'Run Foundation Tests'}
      </button>

      {Object.keys(testResults).length > 0 && (
        <div className="space-y-4">
          {/* Test 1: Data Service */}
          <div className="border rounded-lg p-4">
            <div className={`inline-flex px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(testResults.dataService?.status)}`}>
              {testResults.dataService?.status || 'PENDING'}
            </div>
            <h3 className="text-lg font-semibold mt-2">NextERP Data Service Connectivity</h3>
            <p className="text-gray-600 mt-1">{testResults.dataService?.message}</p>
            
            {testResults.dataService?.data && (
              <div className="mt-3 p-3 bg-gray-50 rounded">
                <h4 className="font-medium mb-2">Sample Data:</h4>
                <pre className="text-sm overflow-x-auto">
                  {JSON.stringify(testResults.dataService.data, null, 2)}
                </pre>
              </div>
            )}
            
            {testResults.dataService?.error && (
              <div className="mt-3 p-3 bg-red-50 rounded">
                <h4 className="font-medium text-red-800 mb-2">Error Details:</h4>
                <pre className="text-sm text-red-700">{testResults.dataService.error}</pre>
              </div>
            )}
          </div>

          {/* Test 2: Transformation */}
          <div className="border rounded-lg p-4">
            <div className={`inline-flex px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(testResults.transformation?.status)}`}>
              {testResults.transformation?.status || 'PENDING'}
            </div>
            <h3 className="text-lg font-semibold mt-2">Data Transformation</h3>
            <p className="text-gray-600 mt-1">{testResults.transformation?.message}</p>
            
            {testResults.transformation?.fieldMapping && (
              <div className="mt-3 p-3 bg-gray-50 rounded">
                <h4 className="font-medium mb-2">Field Mapping Results:</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  {Object.entries(testResults.transformation.fieldMapping).map(([field, value]) => (
                    <div key={field} className="flex justify-between">
                      <span className="font-medium">{field}:</span>
                      <span className="text-gray-600">{value || 'EMPTY'}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Test 3: Field Validation */}
          <div className="border rounded-lg p-4">
            <div className={`inline-flex px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(testResults.fieldValidation?.status)}`}>
              {testResults.fieldValidation?.status || 'PENDING'}
            </div>
            <h3 className="text-lg font-semibold mt-2">Field Validation</h3>
            <p className="text-gray-600 mt-1">{testResults.fieldValidation?.message}</p>
            
            {testResults.fieldValidation?.fields && (
              <div className="mt-3 p-3 bg-gray-50 rounded">
                <h4 className="font-medium mb-2">Field Status:</h4>
                <div className="space-y-1">
                  {testResults.fieldValidation.fields.map((field) => (
                    <div key={field.field} className="flex items-center justify-between text-sm">
                      <span className="font-medium">{field.field}:</span>
                      <div className="flex items-center space-x-2">
                        <span className={field.present ? 'text-green-600' : 'text-red-600'}>
                          {field.present ? '✓' : '✗'}
                        </span>
                        <span className="text-gray-600 max-w-xs truncate">
                          {field.value}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {Object.keys(testResults).length > 0 && (
        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h3 className="font-semibold text-blue-900 mb-2">Test Summary</h3>
          <div className="text-sm text-blue-800">
            <p>• Data Service: {testResults.dataService?.status}</p>
            <p>• Transformation: {testResults.transformation?.status}</p>
            <p>• Field Validation: {testResults.fieldValidation?.status}</p>
          </div>
          
          {testResults.dataService?.status === 'PASS' && 
           testResults.transformation?.status === 'PASS' && 
           testResults.fieldValidation?.status === 'PASS' && (
            <div className="mt-3 p-3 bg-green-100 rounded border border-green-200">
              <p className="text-green-800 font-medium">
                🎉 Foundation Architecture Ready for Cookie-Cutter Templates!
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default FoundationTestFixed;

