# Cannabis ERP - Modular Architecture Documentation

## 🎯 **ATOMIC ENGINEERING PRINCIPLES**

This system is built using **Atomic Engineering** methodology for maximum modularity, zero-dependency iteration, and self-documenting architecture.

## 📁 **SYSTEM ARCHITECTURE**

```
src/
├── lib/
│   ├── config.js           # ⚙️ CENTRAL CONFIGURATION
│   ├── api.js              # 🔌 API INTEGRATION
│   ├── pageFactory.js      # 🏭 AUTO-PAGE GENERATION
│   └── componentRegistry.js # 📦 COMPONENT REGISTRY
├── components/
│   ├── Layout.jsx          # 🏗️ MAIN LAYOUT
│   ├── DataTable.jsx       # 📊 REUSABLE TABLE
│   └── RecordDrawer.jsx    # 📋 RECORD DETAILS
└── pages/
    ├── InventoryPage.jsx   # 📦 AUTO-GENERATED
    ├── CustomersPage.jsx   # 👥 AUTO-GENERATED
    └── VendorsPage.jsx     # 🏢 AUTO-GENERATED
```

## 🔧 **HOW TO ADD/MODIFY FEATURES**

### ✅ **Adding a New Page (Zero Code Required)**

1. **Update Configuration** in `config.js`:
```javascript
DOCTYPES: {
  NEW_ENTITY: {
    name: 'My New DocType',
    endpoint: '/resource/My New DocType',
    fields: {
      id: 'name',
      title: 'entity_name',
      searchable: ['entity_name', 'description']
    }
  }
}
```

2. **Add Route** in `config.js`:
```javascript
ROUTES: {
  MAIN: [
    { path: '/new-entity', name: 'New Entity', icon: 'Star', component: 'NewEntityPage' }
  ]
}
```

3. **Create Page File** (3 lines of code):
```javascript
import { createListPage } from '@/lib/pageFactory';
import { Star } from 'lucide-react';

export default createListPage('NEW_ENTITY', {
  title: 'New Entity',
  icon: <Star className="h-8 w-8" />
});
```

**DONE!** Your new page is fully functional with:
- ✅ Data table with sorting/filtering
- ✅ Search functionality  
- ✅ Record drawer for details
- ✅ Pagination
- ✅ Error handling

### ✅ **Modifying Payment Methods**

**Location**: `config.js` → `PAYMENTS.ALLOWED_METHODS`

```javascript
PAYMENTS: {
  ALLOWED_METHODS: ['CASH', 'CHECK'], // Modify this array
  CHECK_FIELDS: {
    REQUIRED: ['check_number'],
    OPTIONAL: ['bank_name']
  }
}
```

### ✅ **Adding New Table Columns**

**Location**: `pageFactory.js` → `generateColumns()` function

```javascript
if (docTypeKey === 'INVENTORY') {
  dynamicColumns.push({
    key: 'new_field',
    label: 'New Field',
    sortable: true,
    render: (value) => <span className="text-blue-600">{value}</span>
  });
}
```

### ✅ **Enabling/Disabling Features**

**Location**: `config.js` → `FEATURES`

```javascript
FEATURES: {
  SEARCH_ENABLED: true,        // Toggle search bars
  PAGINATION_ENABLED: true,    // Toggle pagination
  EXPORT_ENABLED: false,       // Toggle export buttons
  BULK_ACTIONS_ENABLED: false  // Toggle bulk actions
}
```

### ✅ **Modifying Chart of Accounts**

**Location**: `config.js` → `CHART_OF_ACCOUNTS`

```javascript
CHART_OF_ACCOUNTS: {
  EXPENSES: {
    '6000': { name: 'Office Supplies', type: 'Expense', locked: false },
    '6010': { name: 'Marketing', type: 'Expense', locked: false }
    // Add new accounts here
  }
}
```

## 🚀 **RAPID ITERATION WORKFLOW**

### **Scenario 1: Add New Field to Inventory**
1. Update Hemp ERP backend (add field to Hemp Product Item DocType)
2. Update `CONFIG.DOCTYPES.INVENTORY.fields.searchable` array
3. **DONE** - Field automatically appears in table and search

### **Scenario 2: Add New Payment Method**
1. Update `CONFIG.PAYMENTS.ALLOWED_METHODS` array
2. **DONE** - New method appears in all payment forms

### **Scenario 3: Create New Accounting Report**
1. Add route to `CONFIG.ROUTES.ACCOUNTING`
2. Create 3-line page file using `createListPage()`
3. **DONE** - Report page is live with full functionality

## 🔍 **DEBUGGING & TROUBLESHOOTING**

### **Component Not Loading**
- Check `componentRegistry.js` for registration
- Verify component path in lazy import
- Check browser console for import errors

### **API Calls Failing**
- Verify `CONFIG.API.BASE_URL` is correct
- Check ERPNext backend is running
- Verify DocType endpoint in `CONFIG.DOCTYPES`

### **Page Not Rendering**
- Check route configuration in `CONFIG.ROUTES`
- Verify page component export
- Check for JavaScript errors in console

## 📊 **PERFORMANCE OPTIMIZATION**

### **Lazy Loading**
All components use React.lazy() for code splitting:
```javascript
const Component = lazy(() => import('./Component'));
```

### **API Caching**
Implement TanStack Query for automatic caching:
```javascript
// TODO: Add TanStack Query integration
```

### **Bundle Optimization**
- Components auto-register to avoid unused imports
- Pages generate on-demand from factory
- Configuration drives behavior vs. hardcoded logic

## 🛡️ **SECURITY CONSIDERATIONS**

### **Payment Method Restrictions**
- Hard-coded in `CONFIG.PAYMENTS.ALLOWED_METHODS`
- Validated in frontend AND backend
- Cannot be bypassed through UI manipulation

### **API Security**
- All requests use ERPNext session authentication
- CORS configured for same-origin requests
- No sensitive data in frontend configuration

## 📈 **SCALABILITY FEATURES**

### **Auto-Discovery**
System can auto-discover new components:
```javascript
// Future: Auto-scan components directory
discoverComponents('/components');
```

### **Plugin Architecture**
Components register themselves:
```javascript
componentRegistry.register('MyComponent', {
  component: lazy(() => import('./MyComponent')),
  props: ['data', 'onSave']
});
```

### **Configuration-Driven**
Everything configurable without code changes:
- Routes
- DocTypes  
- Validation rules
- UI features
- Payment methods

## 🎯 **MODIFICATION RULES**

1. **NEVER modify component files directly**
2. **ALWAYS update configuration first**
3. **USE factory functions for new pages**
4. **REGISTER new components in registry**
5. **DOCUMENT changes in this README**

This architecture ensures **zero-dependency iteration** - you can add/modify features without reviewing existing code or understanding the entire system.

