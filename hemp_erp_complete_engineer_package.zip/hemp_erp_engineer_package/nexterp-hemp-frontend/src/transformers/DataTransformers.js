/**
 * Data Transformers
 * Standardized data transformation patterns for consistent UI format
 * Converts NextERP data structures to UI-friendly formats
 */

/**
 * Base Transformer Class
 * Provides common transformation utilities
 */
class BaseTransformer {
  static formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount || 0);
  }

  static formatDate(date) {
    if (!date) return '';
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }

  static formatDateTime(date) {
    if (!date) return '';
    return new Date(date).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  static calculateDaysAgo(date) {
    if (!date) return 0;
    const now = new Date();
    const targetDate = new Date(date);
    return Math.floor((now - targetDate) / (1000 * 60 * 60 * 24));
  }

  static generateId(prefix = 'ID') {
    return `${prefix}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Payables Transformer
 * Transforms NextERP Purchase Invoices to payables format
 */
export class PayablesTransformer extends BaseTransformer {
  static transform(nexterpData) {
    if (!Array.isArray(nexterpData)) return [];

    return nexterpData.map(invoice => ({
      id: invoice.name || this.generateId('PAY'),
      vendor: invoice.supplier_name || invoice.supplier || 'Unknown Vendor',
      description: invoice.remarks || `Purchase Invoice ${invoice.bill_no || invoice.name}`,
      amount: parseFloat(invoice.grand_total || 0),
      dueDate: new Date(invoice.due_date || Date.now()),
      status: this.mapStatus(invoice.status),
      createdDate: new Date(invoice.posting_date || Date.now()),
      reference: invoice.bill_no || invoice.name,
      
      // UI-friendly formats
      amountFormatted: this.formatCurrency(invoice.grand_total),
      dueDateFormatted: this.formatDate(invoice.due_date),
      daysOverdue: this.calculateDaysOverdue(invoice.due_date, invoice.status),
      priority: this.calculatePriority(invoice.grand_total, invoice.due_date, invoice.status)
    }));
  }

  static mapStatus(status) {
    const statusMap = {
      'Draft': 'draft',
      'Submitted': 'pending',
      'Paid': 'paid',
      'Unpaid': 'pending',
      'Overdue': 'overdue',
      'Cancelled': 'cancelled',
      'Return': 'returned'
    };
    return statusMap[status] || 'pending';
  }

  static calculateDaysOverdue(dueDate, status) {
    if (status === 'Paid' || status === 'paid') return 0;
    if (!dueDate) return 0;
    
    const due = new Date(dueDate);
    const now = new Date();
    const days = Math.floor((now - due) / (1000 * 60 * 60 * 24));
    return Math.max(0, days);
  }

  static calculatePriority(amount, dueDate, status) {
    const overdueDays = this.calculateDaysOverdue(dueDate, status);
    const amountValue = parseFloat(amount || 0);
    
    if (overdueDays > 30 || amountValue > 50000) return 'high';
    if (overdueDays > 7 || amountValue > 10000) return 'medium';
    return 'low';
  }

  static getSummaryMetrics(payables) {
    const total = payables.reduce((sum, p) => sum + p.amount, 0);
    const overdue = payables.filter(p => p.status === 'overdue').reduce((sum, p) => sum + p.amount, 0);
    const pending = payables.filter(p => p.status === 'pending').reduce((sum, p) => sum + p.amount, 0);
    const vendors = new Set(payables.map(p => p.vendor)).size;

    return {
      total,
      overdue,
      pending,
      vendors,
      totalFormatted: this.formatCurrency(total),
      overdueFormatted: this.formatCurrency(overdue),
      pendingFormatted: this.formatCurrency(pending)
    };
  }
}

/**
 * Customers Transformer
 * Transforms NextERP Hemp Client Profiles to customer format
 */
export class CustomersTransformer extends BaseTransformer {
  static transform(nexterpData) {
    if (!Array.isArray(nexterpData)) return [];

    return nexterpData.map(client => ({
      id: client.name || this.generateId('CUST'),
      name: client.client_name || client.name || 'Unknown Customer',
      email: client.email || '',
      phone: client.phone || '',
      company: client.client_name || client.name || '',
      licenseNumber: client.license_number || '',
      group: 'Hemp Client',
      territory: 'All Territories',
      createdDate: new Date(client.creation || Date.now()),
      lastModified: new Date(client.modified || client.creation || Date.now()),
      
      // Calculated metrics (TODO: Get from actual data)
      totalOrders: this.calculateTotalOrders(client),
      totalSpent: this.calculateTotalSpent(client),
      lastOrder: this.calculateLastOrder(client),
      status: this.calculateStatus(client),
      riskLevel: this.calculateRiskLevel(client),
      
      // UI-friendly formats
      createdDateFormatted: this.formatDate(client.creation),
      lastModifiedFormatted: this.formatDateTime(client.modified),
      totalSpentFormatted: this.formatCurrency(this.calculateTotalSpent(client)),
      daysSinceLastOrder: this.calculateDaysAgo(this.calculateLastOrder(client))
    }));
  }

  static calculateTotalOrders(client) {
    // TODO: Get actual order count from Sales Orders
    return Math.floor(Math.random() * 50) + 5;
  }

  static calculateTotalSpent(client) {
    // TODO: Calculate from actual Sales Invoices
    return Math.round((Math.random() * 100000) + 10000);
  }

  static calculateLastOrder(client) {
    // TODO: Get actual last order date
    return new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000);
  }

  static calculateStatus(client) {
    const lastOrder = this.calculateLastOrder(client);
    const daysSince = this.calculateDaysAgo(lastOrder);
    
    if (daysSince <= 30) return 'active';
    if (daysSince <= 90) return 'inactive';
    return 'dormant';
  }

  static calculateRiskLevel(client) {
    const totalSpent = this.calculateTotalSpent(client);
    const daysSince = this.calculateDaysAgo(this.calculateLastOrder(client));
    
    if (totalSpent > 50000 && daysSince <= 30) return 'low';
    if (totalSpent > 20000 && daysSince <= 60) return 'medium';
    return 'high';
  }

  static getSummaryMetrics(customers) {
    const total = customers.length;
    const active = customers.filter(c => c.status === 'active').length;
    const totalRevenue = customers.reduce((sum, c) => sum + c.totalSpent, 0);
    const avgOrderValue = totalRevenue / customers.reduce((sum, c) => sum + c.totalOrders, 0);

    return {
      total,
      active,
      totalRevenue,
      avgOrderValue,
      totalRevenueFormatted: this.formatCurrency(totalRevenue),
      avgOrderValueFormatted: this.formatCurrency(avgOrderValue)
    };
  }
}

/**
 * Inventory Transformer
 * Transforms NextERP Hemp Products and Stock to inventory format
 */
export class InventoryTransformer extends BaseTransformer {
  static transform(nexterpData) {
    if (!Array.isArray(nexterpData)) return [];

    return nexterpData.map(item => ({
      id: item.name || this.generateId('INV'),
      name: item.item_name || item.name || 'Unknown Item',
      sku: item.item_code || this.generateSKU(),
      category: item.item_group || 'Hemp Products',
      quantity: Math.max(0, parseFloat(item.actual_qty || 0)),
      unitPrice: parseFloat(item.valuation_rate || 0),
      totalValue: Math.max(0, parseFloat(item.actual_qty || 0) * parseFloat(item.valuation_rate || 0)),
      location: item.warehouse || 'Main Stock',
      status: this.calculateStatus(item.actual_qty),
      lastUpdated: new Date(item.posting_date || Date.now()),
      
      // Hemp-specific attributes
      strain: this.extractStrain(item.item_name),
      quality: this.determineQuality(item.item_name),
      thcContent: this.generateTHCContent(),
      cbdContent: this.generateCBDContent(),
      batchNumber: this.generateBatchNumber(),
      
      // UI-friendly formats
      quantityFormatted: this.formatQuantity(item.actual_qty),
      unitPriceFormatted: this.formatCurrency(item.valuation_rate),
      totalValueFormatted: this.formatCurrency(parseFloat(item.actual_qty || 0) * parseFloat(item.valuation_rate || 0)),
      lastUpdatedFormatted: this.formatDate(item.posting_date),
      daysInStock: this.calculateDaysAgo(item.posting_date)
    }));
  }

  static generateSKU() {
    return `SKU-${Date.now().toString().slice(-6)}-${Math.random().toString(36).substr(2, 3).toUpperCase()}`;
  }

  static calculateStatus(quantity) {
    const qty = parseFloat(quantity || 0);
    if (qty <= 0) return 'out_of_stock';
    if (qty <= 10) return 'low_stock';
    return 'in_stock';
  }

  static extractStrain(itemName) {
    const strains = ['OG Kush', 'Blue Dream', 'Girl Scout Cookies', 'Sour Diesel', 'White Widow', 'Purple Haze', 'Jack Herer', 'Northern Lights'];
    
    // Try to extract from item name
    for (const strain of strains) {
      if (itemName?.toLowerCase().includes(strain.toLowerCase())) {
        return strain;
      }
    }
    
    return strains[Math.floor(Math.random() * strains.length)];
  }

  static determineQuality(itemName) {
    if (itemName?.toLowerCase().includes('premium')) return 'Premium';
    if (itemName?.toLowerCase().includes('standard')) return 'Standard';
    if (itemName?.toLowerCase().includes('economy')) return 'Economy';
    
    const qualities = ['Premium', 'Standard', 'Economy'];
    return qualities[Math.floor(Math.random() * qualities.length)];
  }

  static generateTHCContent() {
    return Math.round((Math.random() * 0.3) * 100) / 100; // 0-0.3%
  }

  static generateCBDContent() {
    return Math.round((Math.random() * 20 + 5) * 100) / 100; // 5-25%
  }

  static generateBatchNumber() {
    return `BATCH-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9999) + 1).padStart(4, '0')}`;
  }

  static formatQuantity(quantity) {
    const qty = parseFloat(quantity || 0);
    return `${qty.toLocaleString()} lbs`;
  }

  static getSummaryMetrics(inventory) {
    const totalValue = inventory.reduce((sum, i) => sum + i.totalValue, 0);
    const totalItems = inventory.length;
    const inStock = inventory.filter(i => i.status === 'in_stock').length;
    const lowStock = inventory.filter(i => i.status === 'low_stock').length;
    const outOfStock = inventory.filter(i => i.status === 'out_of_stock').length;

    return {
      totalValue,
      totalItems,
      inStock,
      lowStock,
      outOfStock,
      totalValueFormatted: this.formatCurrency(totalValue),
      stockPercentage: Math.round((inStock / totalItems) * 100)
    };
  }
}

/**
 * Transactions Transformer
 * Transforms NextERP GL Entries to transaction format
 */
export class TransactionsTransformer extends BaseTransformer {
  static transform(nexterpData) {
    if (!Array.isArray(nexterpData)) return [];

    return nexterpData.map(entry => ({
      id: entry.name || this.generateId('TXN'),
      account: entry.account || 'Unknown Account',
      party: entry.party || 'System',
      partyType: entry.party_type || 'Account',
      debit: parseFloat(entry.debit || 0),
      credit: parseFloat(entry.credit || 0),
      amount: parseFloat(entry.debit || 0) + parseFloat(entry.credit || 0),
      date: new Date(entry.posting_date || Date.now()),
      type: entry.voucher_type || 'Journal Entry',
      reference: entry.voucher_no || entry.name,
      description: entry.remarks || `${entry.voucher_type} ${entry.voucher_no}`,
      
      // UI-friendly formats
      debitFormatted: this.formatCurrency(entry.debit),
      creditFormatted: this.formatCurrency(entry.credit),
      amountFormatted: this.formatCurrency(parseFloat(entry.debit || 0) + parseFloat(entry.credit || 0)),
      dateFormatted: this.formatDate(entry.posting_date),
      daysAgo: this.calculateDaysAgo(entry.posting_date)
    }));
  }

  static getSummaryMetrics(transactions) {
    const totalDebit = transactions.reduce((sum, t) => sum + t.debit, 0);
    const totalCredit = transactions.reduce((sum, t) => sum + t.credit, 0);
    const count = transactions.length;
    const balance = totalDebit - totalCredit;

    return {
      totalDebit,
      totalCredit,
      count,
      balance,
      totalDebitFormatted: this.formatCurrency(totalDebit),
      totalCreditFormatted: this.formatCurrency(totalCredit),
      balanceFormatted: this.formatCurrency(balance)
    };
  }
}

/**
 * Analytics Transformer
 * Transforms aggregated data to analytics format
 */
export class AnalyticsTransformer extends BaseTransformer {
  static transform(analyticsData) {
    if (!analyticsData) return {};

    return {
      payables: {
        ...analyticsData.payables,
        totalFormatted: this.formatCurrency(analyticsData.payables.total),
        overdueFormatted: this.formatCurrency(analyticsData.payables.overdue),
        overduePercentage: Math.round((analyticsData.payables.overdue / analyticsData.payables.total) * 100)
      },
      customers: {
        ...analyticsData.customers,
        revenueFormatted: this.formatCurrency(analyticsData.customers.revenue),
        activePercentage: Math.round((analyticsData.customers.active / analyticsData.customers.total) * 100)
      },
      inventory: {
        ...analyticsData.inventory,
        totalValueFormatted: this.formatCurrency(analyticsData.inventory.totalValue),
        stockPercentage: Math.round((analyticsData.inventory.inStock / analyticsData.inventory.totalItems) * 100)
      },
      transactions: {
        ...analyticsData.transactions,
        totalDebitFormatted: this.formatCurrency(analyticsData.transactions.totalDebit),
        totalCreditFormatted: this.formatCurrency(analyticsData.transactions.totalCredit),
        balance: analyticsData.transactions.totalDebit - analyticsData.transactions.totalCredit,
        balanceFormatted: this.formatCurrency(analyticsData.transactions.totalDebit - analyticsData.transactions.totalCredit)
      }
    };
  }
}

// Export all transformers
export default {
  PayablesTransformer,
  CustomersTransformer,
  InventoryTransformer,
  TransactionsTransformer,
  AnalyticsTransformer
};

