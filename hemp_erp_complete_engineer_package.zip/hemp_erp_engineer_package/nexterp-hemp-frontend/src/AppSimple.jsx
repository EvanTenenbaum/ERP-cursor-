import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import MinimalTest from './MinimalTest.jsx';
import RealFoundationTest from './components/RealFoundationTest.jsx';
import FoundationTestWithFallback from './components/FoundationTestWithFallback.jsx';
import RealFoundationTestFixed from './components/RealFoundationTestFixed.jsx';
import ProxyFoundationTest from './components/ProxyFoundationTest.jsx';
import CustomerList from './components/customers/CustomerList.jsx';
import InventoryList from './components/inventory/InventoryList.jsx';
import AuthProvider, { useAuth } from './components/auth/AuthProvider.jsx';
import LoginFormDirect from './components/auth/LoginFormDirect.jsx';

// Simple Layout Component with Authentication
const SimpleLayout = ({ children }) => {
  const { isAuthenticated, user, logout } = useAuth();
  
  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f8f9fa' }}>
      <nav style={{ 
        backgroundColor: '#2563eb', 
        color: 'white', 
        padding: '1rem',
        marginBottom: '2rem'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h1 style={{ margin: 0, fontSize: '1.5rem' }}>Hemp ERP System</h1>
          {isAuthenticated && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
              <span style={{ fontSize: '0.9rem' }}>
                Welcome, {user?.username} ({user?.role})
              </span>
              <button 
                onClick={logout}
                style={{
                  padding: '0.5rem 1rem',
                  backgroundColor: '#dc2626',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '0.9rem'
                }}
              >
                Logout
              </button>
            </div>
          )}
        </div>
        <div style={{ marginTop: '0.5rem' }}>
          <a href="/" style={{ color: 'white', marginRight: '1rem', textDecoration: 'none' }}>Home</a>
          {isAuthenticated && (
            <>
              <a href="/customers" style={{ color: 'white', marginRight: '1rem', textDecoration: 'none' }}>Customers</a>
              <a href="/inventory" style={{ color: 'white', marginRight: '1rem', textDecoration: 'none' }}>Inventory</a>
            </>
          )}
          <a href="/test" style={{ color: 'white', marginRight: '1rem', textDecoration: 'none' }}>Test</a>
          <a href="/foundation-test" style={{ color: 'white', marginRight: '1rem', textDecoration: 'none' }}>Foundation Test</a>
          <a href="/foundation-fallback" style={{ color: 'white', marginRight: '1rem', textDecoration: 'none' }}>Foundation Fallback</a>
          <a href="/foundation-fixed" style={{ color: 'white', marginRight: '1rem', textDecoration: 'none' }}>Foundation Fixed</a>
          <a href="/proxy-foundation" style={{ color: 'white', marginRight: '1rem', textDecoration: 'none' }}>Proxy Foundation</a>
        </div>
      </nav>
      <div style={{ padding: '0 2rem' }}>
        {children}
      </div>
    </div>
  );
};

// Simple Foundation Test Component
const SimpleFoundationTest = () => {
  return (
    <div style={{ padding: '2rem' }}>
      <h2>Simple Foundation Test</h2>
      <p>This is a basic test to verify the foundation architecture works.</p>
      <div style={{ 
        padding: '1rem', 
        backgroundColor: '#e3f2fd', 
        border: '1px solid #2196f3',
        borderRadius: '4px',
        marginTop: '1rem'
      }}>
        <h3>Test Status: Ready</h3>
        <p>Foundation components are loading successfully.</p>
        <button 
          style={{
            padding: '0.5rem 1rem',
            backgroundColor: '#2196f3',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
          onClick={() => alert('Foundation test button clicked!')}
        >
          Run Foundation Test
        </button>
      </div>
    </div>
  );
};

// Authentication wrapper component
const AuthenticatedApp = () => {
  const { isAuthenticated, loading, login } = useAuth();

  if (loading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        minHeight: '100vh' 
      }}>
        <div>Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginFormDirect onLoginSuccess={login} />;
  }

  return (
    <Routes>
      <Route path="/" element={
        <SimpleLayout>
          <MinimalTest />
        </SimpleLayout>
      } />
      <Route path="/customers" element={
        <SimpleLayout>
          <CustomerList />
        </SimpleLayout>
      } />
      <Route path="/inventory" element={
        <SimpleLayout>
          <InventoryList />
        </SimpleLayout>
      } />
      <Route path="/test" element={
        <SimpleLayout>
          <SimpleFoundationTest />
        </SimpleLayout>
      } />
      <Route path="/foundation-test" element={
        <SimpleLayout>
          <RealFoundationTest />
        </SimpleLayout>
      } />
      <Route path="/foundation-fallback" element={
        <SimpleLayout>
          <FoundationTestWithFallback />
        </SimpleLayout>
      } />
      <Route path="/foundation-fixed" element={
        <SimpleLayout>
          <RealFoundationTestFixed />
        </SimpleLayout>
      } />
      <Route path="/proxy-foundation" element={
        <SimpleLayout>
          <ProxyFoundationTest />
        </SimpleLayout>
      } />
    </Routes>
  );
};

function AppSimple() {
  return (
    <AuthProvider>
      <Router>
        <AuthenticatedApp />
      </Router>
    </AuthProvider>
  );
}

export default AppSimple;

