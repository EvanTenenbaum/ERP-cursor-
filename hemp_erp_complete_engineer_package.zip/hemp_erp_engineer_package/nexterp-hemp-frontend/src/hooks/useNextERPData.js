/**
 * NextERP Data Hooks
 * Standardized React hooks for data fetching with caching, error handling, and loading states
 * Cookie-cutter patterns for all hemp ERP features
 */

import { useState, useEffect, useCallback, useMemo } from 'react';
import nexterpDataService from '../services/NextERPDataService';
import { 
  PayablesTransformer, 
  CustomersTransformer, 
  InventoryTransformer, 
  TransactionsTransformer,
  AnalyticsTransformer 
} from '../transformers/DataTransformers';

/**
 * Base hook for standardized data fetching patterns
 */
const useBaseData = (fetchFunction, transformer, dependencies = []) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastFetch, setLastFetch] = useState(null);

  const fetchData = useCallback(async (filters = {}) => {
    try {
      setLoading(true);
      setError(null);
      
      const rawData = await fetchFunction(filters);
      const transformedData = transformer ? transformer.transform(rawData) : rawData;
      
      setData(transformedData);
      setLastFetch(new Date());
      
      return transformedData;
    } catch (err) {
      console.error('Data fetch error:', err);
      setError(err.message || 'Failed to load data');
      return [];
    } finally {
      setLoading(false);
    }
  }, [fetchFunction, transformer, ...dependencies]);

  const refresh = useCallback(() => {
    return fetchData();
  }, [fetchData]);

  const clearCache = useCallback(() => {
    nexterpDataService.clearCache();
  }, []);

  return {
    data,
    loading,
    error,
    lastFetch,
    fetchData,
    refresh,
    clearCache
  };
};

/**
 * Payables Hook
 * Real NextERP Purchase Invoice integration
 */
export const usePayables = (filters = {}) => {
  const baseHook = useBaseData(
    nexterpDataService.getPayables.bind(nexterpDataService),
    PayablesTransformer,
    [JSON.stringify(filters)]
  );

  // Auto-fetch on mount and filter changes
  useEffect(() => {
    baseHook.fetchData(filters);
  }, [JSON.stringify(filters)]);

  // Memoized summary metrics
  const summaryMetrics = useMemo(() => {
    if (!baseHook.data.length) return null;
    return PayablesTransformer.getSummaryMetrics(baseHook.data);
  }, [baseHook.data]);

  // Filtered data based on search and status
  const getFilteredData = useCallback((searchTerm = '', statusFilter = 'all') => {
    return baseHook.data.filter(payable => {
      const matchesSearch = payable.vendor.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           payable.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'all' || payable.status === statusFilter;
      
      return matchesSearch && matchesStatus;
    });
  }, [baseHook.data]);

  return {
    ...baseHook,
    summaryMetrics,
    getFilteredData,
    // Convenience methods
    getOverduePayables: () => baseHook.data.filter(p => p.status === 'overdue'),
    getPendingPayables: () => baseHook.data.filter(p => p.status === 'pending'),
    getPayablesByVendor: (vendor) => baseHook.data.filter(p => p.vendor === vendor)
  };
};

/**
 * Customers Hook
 * Real NextERP Hemp Client Profile integration
 */
export const useCustomers = (filters = {}) => {
  const baseHook = useBaseData(
    nexterpDataService.getCustomers.bind(nexterpDataService),
    CustomersTransformer,
    [JSON.stringify(filters)]
  );

  // Auto-fetch on mount and filter changes
  useEffect(() => {
    baseHook.fetchData(filters);
  }, [JSON.stringify(filters)]);

  // Memoized summary metrics
  const summaryMetrics = useMemo(() => {
    if (!baseHook.data.length) return null;
    return CustomersTransformer.getSummaryMetrics(baseHook.data);
  }, [baseHook.data]);

  // Filtered data based on search and status
  const getFilteredData = useCallback((searchTerm = '', statusFilter = 'all') => {
    return baseHook.data.filter(customer => {
      const matchesSearch = customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           customer.company.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'all' || customer.status === statusFilter;
      
      return matchesSearch && matchesStatus;
    });
  }, [baseHook.data]);

  return {
    ...baseHook,
    summaryMetrics,
    getFilteredData,
    // Convenience methods
    getActiveCustomers: () => baseHook.data.filter(c => c.status === 'active'),
    getHighValueCustomers: () => baseHook.data.filter(c => c.totalSpent > 50000),
    getCustomersByRisk: (riskLevel) => baseHook.data.filter(c => c.riskLevel === riskLevel)
  };
};

/**
 * Inventory Hook
 * Real NextERP Hemp Products and Stock integration
 */
export const useInventory = (filters = {}) => {
  const baseHook = useBaseData(
    nexterpDataService.getInventory.bind(nexterpDataService),
    InventoryTransformer,
    [JSON.stringify(filters)]
  );

  // Auto-fetch on mount and filter changes
  useEffect(() => {
    baseHook.fetchData(filters);
  }, [JSON.stringify(filters)]);

  // Memoized summary metrics
  const summaryMetrics = useMemo(() => {
    if (!baseHook.data.length) return null;
    return InventoryTransformer.getSummaryMetrics(baseHook.data);
  }, [baseHook.data]);

  // Filtered data based on search and status
  const getFilteredData = useCallback((searchTerm = '', statusFilter = 'all', locationFilter = 'all') => {
    return baseHook.data.filter(item => {
      const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           item.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           item.strain.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
      const matchesLocation = locationFilter === 'all' || item.location === locationFilter;
      
      return matchesSearch && matchesStatus && matchesLocation;
    });
  }, [baseHook.data]);

  return {
    ...baseHook,
    summaryMetrics,
    getFilteredData,
    // Convenience methods
    getLowStockItems: () => baseHook.data.filter(i => i.status === 'low_stock'),
    getOutOfStockItems: () => baseHook.data.filter(i => i.status === 'out_of_stock'),
    getItemsByCategory: (category) => baseHook.data.filter(i => i.category === category),
    getItemsByStrain: (strain) => baseHook.data.filter(i => i.strain === strain)
  };
};

/**
 * Transactions Hook
 * Real NextERP GL Entry integration
 */
export const useTransactions = (filters = {}) => {
  const baseHook = useBaseData(
    nexterpDataService.getTransactions.bind(nexterpDataService),
    TransactionsTransformer,
    [JSON.stringify(filters)]
  );

  // Auto-fetch on mount and filter changes
  useEffect(() => {
    baseHook.fetchData(filters);
  }, [JSON.stringify(filters)]);

  // Memoized summary metrics
  const summaryMetrics = useMemo(() => {
    if (!baseHook.data.length) return null;
    return TransactionsTransformer.getSummaryMetrics(baseHook.data);
  }, [baseHook.data]);

  // Filtered data based on search and type
  const getFilteredData = useCallback((searchTerm = '', typeFilter = 'all', dateRange = null) => {
    return baseHook.data.filter(transaction => {
      const matchesSearch = transaction.account.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           transaction.party.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           transaction.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = typeFilter === 'all' || transaction.type === typeFilter;
      
      let matchesDate = true;
      if (dateRange && dateRange.start && dateRange.end) {
        const transactionDate = new Date(transaction.date);
        matchesDate = transactionDate >= dateRange.start && transactionDate <= dateRange.end;
      }
      
      return matchesSearch && matchesType && matchesDate;
    });
  }, [baseHook.data]);

  return {
    ...baseHook,
    summaryMetrics,
    getFilteredData,
    // Convenience methods
    getDebitTransactions: () => baseHook.data.filter(t => t.debit > 0),
    getCreditTransactions: () => baseHook.data.filter(t => t.credit > 0),
    getTransactionsByType: (type) => baseHook.data.filter(t => t.type === type),
    getTransactionsByParty: (party) => baseHook.data.filter(t => t.party === party)
  };
};

/**
 * Analytics Hook
 * Aggregated business metrics
 */
export const useAnalytics = (filters = {}) => {
  const baseHook = useBaseData(
    nexterpDataService.getAnalytics.bind(nexterpDataService),
    AnalyticsTransformer,
    [JSON.stringify(filters)]
  );

  // Auto-fetch on mount and filter changes
  useEffect(() => {
    baseHook.fetchData(filters);
  }, [JSON.stringify(filters)]);

  // Generate trend data for charts
  const getTrendData = useCallback((metric = 'revenue', period = 'monthly') => {
    // TODO: Implement actual trend calculation from real data
    const months = [];
    for (let i = 11; i >= 0; i--) {
      const date = new Date();
      date.setMonth(date.getMonth() - i);
      
      months.push({
        month: date.toLocaleDateString('en-US', { month: 'short', year: '2-digit' }),
        value: Math.round(Math.random() * 100000 + 50000),
        growth: Math.round((Math.random() - 0.3) * 20)
      });
    }
    return months;
  }, [baseHook.data]);

  return {
    ...baseHook,
    getTrendData,
    // Convenience methods for dashboard
    getKPIs: () => baseHook.data,
    getHealthScore: () => {
      if (!baseHook.data.payables) return 0;
      const overdueRatio = baseHook.data.payables.overdue / baseHook.data.payables.total;
      return Math.round((1 - overdueRatio) * 100);
    }
  };
};

/**
 * Generic hook factory for creating new data hooks
 * Cookie-cutter pattern for rapid feature development
 */
export const createDataHook = (config) => {
  const { 
    fetchFunction, 
    transformer, 
    autoFetch = true,
    dependencies = [] 
  } = config;

  return (filters = {}) => {
    const baseHook = useBaseData(fetchFunction, transformer, dependencies);

    // Auto-fetch if enabled
    useEffect(() => {
      if (autoFetch) {
        baseHook.fetchData(filters);
      }
    }, [JSON.stringify(filters)]);

    return baseHook;
  };
};

/**
 * Multi-data hook for components that need multiple data sources
 */
export const useMultipleData = (hooks) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [data, setData] = useState({});

  const fetchAll = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const results = {};
      const promises = Object.entries(hooks).map(async ([key, hook]) => {
        const result = await hook.fetchData();
        results[key] = result;
      });

      await Promise.all(promises);
      setData(results);
    } catch (err) {
      setError(err.message || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }, [hooks]);

  const refresh = useCallback(() => {
    return fetchAll();
  }, [fetchAll]);

  return {
    data,
    loading,
    error,
    fetchAll,
    refresh
  };
};

// Export all hooks
export default {
  usePayables,
  useCustomers,
  useInventory,
  useTransactions,
  useAnalytics,
  createDataHook,
  useMultipleData
};

