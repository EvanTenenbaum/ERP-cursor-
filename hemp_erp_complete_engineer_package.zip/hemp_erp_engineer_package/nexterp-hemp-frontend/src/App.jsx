import React, { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Loader2, CheckCircle, XCircle, Database, Users, Package, ShoppingCart, DollarSign, FileText, Settings } from 'lucide-react'
import nexterpAPI from './lib/nexterp-api.js'
import './App.css'

// Import existing UI components from cannabis-erp-ui
import SimpleLayout from './components/SimpleLayout.jsx'
import TestPage from './pages/TestPage.jsx'
import FoundationTest from './test/FoundationTest.jsx'
import FoundationTestFixed from './test/FoundationTestFixed.jsx'
import EnhancedPayablesPage from './pages/EnhancedPayablesWorking.jsx'
import CustomerWorkspacePage from './pages/CustomerWorkspacePage.jsx'
import StreamlinedSalesPage from './pages/StreamlinedSalesPage.jsx'
import DebtManagementPage from './pages/DebtManagementPage.jsx'
import InteractionsPage from './pages/InteractionsPage.jsx'
import InventoryManagementPage from './pages/InventoryManagementPage.jsx'
import ReportingDashboardPage from './pages/ReportingDashboardPage.jsx'

function App() {
  const [connectionStatus, setConnectionStatus] = useState('testing')
  const [apiData, setApiData] = useState(null)
  const [hempData, setHempData] = useState({
    clients: [],
    vendors: [],
    products: [],
    orders: []
  })

  useEffect(() => {
    testNextERPConnection()
  }, [])

  const testNextERPConnection = async () => {
    setConnectionStatus('testing')
    
    try {
      const result = await nexterpAPI.testConnection()
      
      if (result.success) {
        setConnectionStatus('connected')
        setApiData(result.data)
        
        // Load hemp data
        await loadHempData()
      } else {
        setConnectionStatus('failed')
        console.error('NextERP connection failed:', result.message)
      }
    } catch (error) {
      setConnectionStatus('failed')
      console.error('NextERP connection error:', error)
    }
  }

  const loadHempData = async () => {
    try {
      const [clients, vendors, products, salesOrders] = await Promise.all([
        nexterpAPI.getHempClients(),
        nexterpAPI.getHempVendors(),
        nexterpAPI.getHempProducts(),
        nexterpAPI.getHempSalesOrders()
      ])

      setHempData({
        clients: clients.data || [],
        vendors: vendors.data || [],
        products: products.data || [],
        orders: salesOrders.data || []
      })
    } catch (error) {
      console.error('Failed to load hemp data:', error)
    }
  }

  const DashboardPage = () => (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold text-gray-900">Hemp ERP</h1>
          <p className="text-lg text-gray-600">Enhanced Frontend for NextERP Backend</p>
        </div>

        {/* Connection Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              NextERP Backend Integration
            </CardTitle>
            <CardDescription>
              Real-time connection to the working NextERP hemp management system
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {connectionStatus === 'testing' && <Loader2 className="h-4 w-4 animate-spin" />}
                {connectionStatus === 'connected' && <CheckCircle className="h-4 w-4 text-green-500" />}
                {connectionStatus === 'failed' && <XCircle className="h-4 w-4 text-red-500" />}
                <span className="font-medium">
                  {connectionStatus === 'testing' && 'Testing NextERP Connection...'}
                  {connectionStatus === 'connected' && 'Connected to NextERP Backend'}
                  {connectionStatus === 'failed' && 'NextERP Connection Failed'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                {connectionStatus === 'testing' && <Badge variant="secondary">Testing</Badge>}
                {connectionStatus === 'connected' && <Badge variant="default" className="bg-green-500">Connected</Badge>}
                {connectionStatus === 'failed' && <Badge variant="destructive">Failed</Badge>}
                <Button 
                  onClick={testNextERPConnection}
                  variant="outline"
                  size="sm"
                  disabled={connectionStatus === 'testing'}
                >
                  Test Connection
                </Button>
              </div>
            </div>
            
            {connectionStatus === 'connected' && apiData && (
              <div className="mt-4 p-3 bg-green-50 rounded-lg">
                <p className="text-sm text-green-700">
                  ✅ Successfully connected to NextERP backend
                  {apiData.data && apiData.data.length > 0 && (
                    <span className="ml-2">
                      • Found {apiData.data.length} hemp client record(s)
                    </span>
                  )}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Hemp Data Overview */}
        {connectionStatus === 'connected' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Hemp Clients</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{hempData.clients.length}</div>
                <p className="text-xs text-muted-foreground">
                  Active client profiles
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Hemp Vendors</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{hempData.vendors.length}</div>
                <p className="text-xs text-muted-foreground">
                  Vendor partnerships
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Hemp Products</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{hempData.products.length}</div>
                <p className="text-xs text-muted-foreground">
                  Product catalog
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Sales Orders</CardTitle>
                <ShoppingCart className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{hempData.orders.length}</div>
                <p className="text-xs text-muted-foreground">
                  Order transactions
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Enhanced Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="cursor-pointer hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Enhanced Payables</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">
                Advanced accounts payable management with aging analysis
              </p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Customer Workspace</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">
                Comprehensive customer management and relationship tracking
              </p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Streamlined Sales</CardTitle>
              <ShoppingCart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">
                Quick sales order creation with optimized workflow
              </p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Returns Processing</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">
                Product return workflow and refund management
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )

  return (
    <Router>
      <Routes>
        {/* Dashboard */}
        <Route path="/" element={<DashboardPage />} />
        
        {/* Test Route */}
        <Route path="/test" element={
          <SimpleLayout>
            <TestPage />
          </SimpleLayout>
        } />
        
        {/* Enhanced Features */}
        <Route path="/enhanced-payables" element={
          <SimpleLayout>
            <EnhancedPayablesPage />
          </SimpleLayout>
        } />
        <Route path="/customer-workspace" element={
          <SimpleLayout>
            <CustomerWorkspacePage />
          </SimpleLayout>
        } />
        <Route path="/streamlined-sales" element={
          <SimpleLayout>
            <StreamlinedSalesPage />
          </SimpleLayout>
        } />
        <Route path="/debt-management" element={
          <SimpleLayout>
            <DebtManagementPage />
          </SimpleLayout>
        } />
        <Route path="/interactions" element={
          <SimpleLayout>
            <InteractionsPage />
          </SimpleLayout>
        } />
        <Route path="/inventory-management" element={
          <SimpleLayout>
            <InventoryManagementPage />
          </SimpleLayout>
        } />
        <Route path="/reporting-dashboard" element={
          <SimpleLayout>
            <ReportingDashboardPage />
          </SimpleLayout>
        } />
        <Route path="/foundation-test" element={
          <SimpleLayout>
            <FoundationTest />
          </SimpleLayout>
        } />
        <Route path="/foundation-test-fixed" element={
          <SimpleLayout>
            <FoundationTestFixed />
          </SimpleLayout>
        } />
      </Routes>
    </Router>
  )
}

export default App
