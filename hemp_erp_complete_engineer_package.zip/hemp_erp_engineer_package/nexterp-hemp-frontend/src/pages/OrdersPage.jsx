// Cannabis ERP - Orders Page (Enhanced with Streamlined Sales)
// ATOMIC PRINCIPLE: Tabbed interface with quick sale functionality
// MODIFICATION RULE: Maintains existing structure while adding streamlined sales

import React, { useState } from 'react';
import { ShoppingCart, ArrowDownCircle, ArrowUpCircle, Zap, RotateCcw } from 'lucide-react';
import { createListPage } from '../lib/pageFactory.jsx';
import StreamlinedSalesModal from '../components/StreamlinedSalesModal.jsx';

const OrdersPage = () => {
  const [activeTab, setActiveTab] = useState('purchases');
  const [isQuickSaleOpen, setIsQuickSaleOpen] = useState(false);

  // Generate sub-pages using factory
  const PurchaseOrdersPage = createListPage('PURCHASE_ORDERS', {
    title: 'Purchase Orders',
    description: 'Orders from vendors',
    buttonText: 'Purchase Order',
    icon: <ArrowDownCircle className="h-6 w-6" />
  });

  const SalesOrdersPage = createListPage('SALES_ORDERS', {
    title: 'Sales Orders', 
    description: 'Orders to customers',
    buttonText: 'Sales Order',
    icon: <ArrowUpCircle className="h-6 w-6" />
  });

  const ReturnsPage = createListPage('RETURNS', {
    title: 'Returns',
    description: 'Product return requests and processing',
    buttonText: 'Return Request',
    icon: <RotateCcw className="h-6 w-6" />
  });

  const tabs = [
    { id: 'purchases', label: 'Purchase Orders', icon: ArrowDownCircle, component: PurchaseOrdersPage },
    { id: 'sales', label: 'Sales Orders', icon: ArrowUpCircle, component: SalesOrdersPage },
    { id: 'returns', label: 'Returns', icon: RotateCcw, component: ReturnsPage }
  ];

  const ActiveComponent = tabs.find(tab => tab.id === activeTab)?.component;

  const handleSaleCreated = (saleData) => {
    // Refresh sales orders if on sales tab
    if (activeTab === 'sales') {
      window.location.reload(); // Simple refresh for now
    }
  };

  return (
    <>
      <div className="space-y-6">
        {/* Header with Quick Sale */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <ShoppingCart className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-2xl font-bold text-foreground">Orders</h1>
              <p className="text-muted-foreground">Manage purchase and sales orders</p>
            </div>
          </div>
          
          {/* Quick Sale Button */}
          <button
            onClick={() => setIsQuickSaleOpen(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            <Zap className="h-4 w-4" />
            <span>Quick Sale</span>
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-border">
          <nav className="flex space-x-8">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-primary text-primary'
                      : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Active Tab Content */}
        <div>
          {ActiveComponent && <ActiveComponent />}
        </div>
      </div>

      {/* Streamlined Sales Modal */}
      <StreamlinedSalesModal
        isOpen={isQuickSaleOpen}
        onClose={() => setIsQuickSaleOpen(false)}
        onSaleCreated={handleSaleCreated}
      />
    </>
  );
};

export default OrdersPage;

