// Cannabis ERP - Accounting Page (Main Dashboard)
// ATOMIC PRINCIPLE: Central hub for all accounting functions
// MODIFICATION RULE: Update CONFIG.ROUTES.ACCOUNTING to add new modules

import { Calculator, FileText, CreditCard, Receipt, BookOpen, TrendingUp, Building, Banknote, GitMerge } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const AccountingPage = () => {
  const accountingModules = [
    {
      title: 'Invoices',
      description: 'Customer invoices and billing',
      icon: FileText,
      path: '/accounting/invoices',
      color: 'text-blue-600 bg-blue-50'
    },
    {
      title: 'Bills',
      description: 'Vendor bills and payables',
      icon: Receipt,
      path: '/accounting/bills',
      color: 'text-red-600 bg-red-50'
    },
    {
      title: 'Payments',
      description: 'CASH/CHECK payments only',
      icon: CreditCard,
      path: '/accounting/payments',
      color: 'text-green-600 bg-green-50'
    },
    {
      title: 'Credit Notes',
      description: 'Customer credit notes',
      icon: BookOpen,
      path: '/accounting/credit-notes',
      color: 'text-purple-600 bg-purple-50'
    },
    {
      title: 'Chart of Accounts',
      description: 'Account structure (preset)',
      icon: TrendingUp,
      path: '/accounting/chart-of-accounts',
      color: 'text-indigo-600 bg-indigo-50'
    },
    {
      title: 'Journal Entries',
      description: 'Manual journal entries',
      icon: BookOpen,
      path: '/accounting/journal-entries',
      color: 'text-yellow-600 bg-yellow-50'
    },
    {
      title: 'Ledgers',
      description: 'General ledger reports',
      icon: TrendingUp,
      path: '/accounting/ledgers',
      color: 'text-pink-600 bg-pink-50'
    },
    {
      title: 'Banks',
      description: 'Bank and cash accounts',
      icon: Building,
      path: '/accounting/banks',
      color: 'text-cyan-600 bg-cyan-50'
    },
    {
      title: 'Reconcile',
      description: 'Bank reconciliation',
      icon: GitMerge,
      path: '/accounting/reconcile',
      color: 'text-orange-600 bg-orange-50'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <Calculator className="h-8 w-8 text-primary" />
        <div>
          <h1 className="text-2xl font-bold text-foreground">Accounting</h1>
          <p className="text-muted-foreground">Financial management with CASH/CHECK restrictions</p>
        </div>
      </div>

      {/* Payment Method Notice */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <div className="flex items-center space-x-2">
          <Banknote className="h-5 w-5 text-yellow-600" />
          <p className="text-yellow-800 font-medium">Payment Methods Restricted</p>
        </div>
        <p className="text-yellow-700 text-sm mt-1">
          This system only accepts <strong>CASH</strong> and <strong>CHECK</strong> payments. Credit cards and other payment methods are not supported.
        </p>
      </div>

      {/* Accounting Modules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {accountingModules.map((module) => {
          const Icon = module.icon;
          return (
            <Link
              key={module.path}
              to={module.path}
              className="block group"
            >
              <div className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-shadow">
                <div className="flex items-center space-x-3 mb-3">
                  <div className={`p-2 rounded-lg ${module.color}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground group-hover:text-primary">
                    {module.title}
                  </h3>
                </div>
                <p className="text-muted-foreground text-sm">
                  {module.description}
                </p>
              </div>
            </Link>
          );
        })}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Outstanding Invoices</p>
              <p className="text-2xl font-bold text-foreground">$0.00</p>
            </div>
            <FileText className="h-8 w-8 text-blue-600" />
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Unpaid Bills</p>
              <p className="text-2xl font-bold text-foreground">$0.00</p>
            </div>
            <Receipt className="h-8 w-8 text-red-600" />
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Cash Balance</p>
              <p className="text-2xl font-bold text-foreground">$0.00</p>
            </div>
            <Banknote className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Bank Balance</p>
              <p className="text-2xl font-bold text-foreground">$0.00</p>
            </div>
            <Building className="h-8 w-8 text-cyan-600" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountingPage;

