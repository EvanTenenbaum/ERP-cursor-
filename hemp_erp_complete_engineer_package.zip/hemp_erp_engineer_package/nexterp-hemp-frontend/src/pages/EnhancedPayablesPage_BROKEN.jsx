import React, { useState, useEffect } from 'react';
import { Search, Filter, Calendar, DollarSign, Clock, AlertTriangle, CheckCircle } from 'lucide-react';
import { nexterpAPI } from '../lib/nexterp-api';

const EnhancedPayablesPage = () => {
  const [vendors, setVendors] = useState([]);
  const [purchaseOrders, setPurchaseOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [agingData, setAgingData] = useState({
    current: 0,
    days30: 0,
    days60: 0,
    days90: 0,
    over90: 0
  });

  useEffect(() => {
    loadPayablesData();
  }, []);

  const loadPayablesData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Load vendors and purchase orders from NextERP
      const [vendorsResult, ordersResult] = await Promise.all([
        nexterpAPI.getHempVendors(),
        nexterpAPI.getHempPurchaseOrders()
      ]);

      const vendorData = vendorsResult.data || [];
      const orderData = ordersResult.data || [];

      setVendors(vendorData);
      setPurchaseOrders(orderData);
      
      // Calculate aging from purchase orders
      calculateAging(orderData);
    } catch (err) {
      setError(`Failed to load payables data: ${err.message}`);
      console.error('Payables data loading error:', err);
      
      // Fallback to mock data for development
      const mockPayables = [
        {
          name: 'PAY-001',
          vendor: 'Premium Hemp Suppliers Inc.',
          invoice_amount: 15750.00,
          due_date: '2024-01-15',
          status: 'Overdue',
          days_overdue: 45
        },
        {
          name: 'PAY-002', 
          vendor: 'Green Valley Hemp Co.',
          invoice_amount: 8900.00,
          due_date: '2024-02-01',
          status: 'Due Soon',
          days_overdue: 0
        },
        {
          name: 'PAY-003',
          vendor: 'Mountain View Cannabis',
          invoice_amount: 12300.00,
          due_date: '2024-02-15',
          status: 'Current',
          days_overdue: 0
        }
      ];
      setPurchaseOrders(mockPayables);
      calculateAging(mockPayables);
    } finally {
      setLoading(false);
    }
  };

  const calculateAging = (data) => {
    const aging = {
      current: 0,
      days30: 0,
      days60: 0,
      days90: 0,
      over90: 0
    };

    data.forEach(order => {
      const amount = parseFloat(order.total_amount || order.invoice_amount || 0);
      const daysOverdue = calculateDaysOverdue(order.due_date);
      
      if (daysOverdue <= 0) aging.current += amount;
      else if (daysOverdue <= 30) aging.days30 += amount;
      else if (daysOverdue <= 60) aging.days60 += amount;
      else if (daysOverdue <= 90) aging.days90 += amount;
      else aging.over90 += amount;
    });

    setAgingData(aging);
  };

  const calculateDaysOverdue = (dueDate) => {
    if (!dueDate) return 0;
    const today = new Date();
    const due = new Date(dueDate);
    return Math.floor((today - due) / (1000 * 60 * 60 * 24));
  };

  const getVendorName = (vendorId) => {
    const vendor = vendors.find(v => v.name === vendorId);
    return vendor ? vendor.vendor_name || vendor.name : vendorId;
  };

  const getOrderStatus = (order) => {
    const daysOverdue = calculateDaysOverdue(order.due_date);
    if (daysOverdue > 0) return 'Overdue';
    if (daysOverdue > -7) return 'Due Soon';
    return 'Current';
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Overdue': return 'text-red-600 bg-red-50';
      case 'Due Soon': return 'text-yellow-600 bg-yellow-50';
      case 'Current': return 'text-green-600 bg-green-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Overdue': return <AlertTriangle className="w-4 h-4" />;
      case 'Due Soon': return <Clock className="w-4 h-4" />;
      case 'Current': return <CheckCircle className="w-4 h-4" />;
      default: return <DollarSign className="w-4 h-4" />;
    }
  };

  const filteredPayables = purchaseOrders.filter(order => {
    const vendorName = getVendorName(order.vendor);
    const status = getOrderStatus(order);
    
    const matchesSearch = vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || status.toLowerCase() === filterStatus.toLowerCase();
    return matchesSearch && matchesFilter;
  });

  const totalPayables = purchaseOrders.reduce((sum, order) => sum + parseFloat(order.total_amount || order.invoice_amount || 0), 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
        <span className="ml-3 text-gray-600">Loading payables from NextERP...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Enhanced Payables</h1>
          <p className="text-gray-600">Professional vendor payment management with aging analysis</p>
          {error && (
            <div className="mt-2 text-sm text-red-600 bg-red-50 px-3 py-2 rounded">
              {error} - Using fallback data
            </div>
          )}
        </div>
        <div className="text-right">
          <div className="text-sm text-gray-500">Total Outstanding</div>
          <div className="text-2xl font-bold text-gray-900">${totalPayables.toLocaleString()}</div>
          <button
            onClick={loadPayablesData}
            className="mt-2 text-sm text-green-600 hover:text-green-700"
          >
            Refresh Data
          </button>
        </div>
      </div>

      {/* Aging Analysis Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Current</p>
              <p className="text-lg font-semibold text-green-600">${agingData.current.toLocaleString()}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">1-30 Days</p>
              <p className="text-lg font-semibold text-yellow-600">${agingData.days30.toLocaleString()}</p>
            </div>
            <Clock className="w-8 h-8 text-yellow-600" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">31-60 Days</p>
              <p className="text-lg font-semibold text-orange-600">${agingData.days60.toLocaleString()}</p>
            </div>
            <AlertTriangle className="w-8 h-8 text-orange-600" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">61-90 Days</p>
              <p className="text-lg font-semibold text-red-600">${agingData.days90.toLocaleString()}</p>
            </div>
            <AlertTriangle className="w-8 h-8 text-red-600" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">90+ Days</p>
              <p className="text-lg font-semibold text-red-800">${agingData.over90.toLocaleString()}</p>
            </div>
            <AlertTriangle className="w-8 h-8 text-red-800" />
          </div>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search vendors or order numbers..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <select
            className="pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent appearance-none bg-white"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="all">All Status</option>
            <option value="current">Current</option>
            <option value="due soon">Due Soon</option>
            <option value="overdue">Overdue</option>
          </select>
        </div>
      </div>

      {/* Payables Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Order
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Vendor
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Due Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredPayables.map((order) => {
                const status = getOrderStatus(order);
                const amount = parseFloat(order.total_amount || order.invoice_amount || 0);
                return (
                  <tr key={order.name} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{order.name}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{getVendorName(order.vendor)}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        ${amount.toLocaleString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {order.due_date ? new Date(order.due_date).toLocaleDateString() : '-'}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(status)}`}>
                        {getStatusIcon(status)}
                        <span className="ml-1">{status}</span>
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button className="text-green-600 hover:text-green-900 mr-3">
                        Pay Now
                      </button>
                      <button className="text-blue-600 hover:text-blue-900">
                        View Details
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {filteredPayables.length === 0 && (
        <div className="text-center py-12">
          <DollarSign className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No payables found</h3>
          <p className="mt-1 text-sm text-gray-500">
            {searchTerm || filterStatus !== 'all' 
              ? 'Try adjusting your search or filter criteria.'
              : 'No outstanding payables at this time.'}
          </p>
        </div>
      )}
    </div>
  );
};

export default EnhancedPayablesPage;

  const getStatusColor = (status) => {
    switch (status) {
      case 'Overdue': return 'text-red-600 bg-red-50';
      case 'Due Soon': return 'text-yellow-600 bg-yellow-50';
      case 'Current': return 'text-green-600 bg-green-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Overdue': return <AlertTriangle className="w-4 h-4" />;
      case 'Due Soon': return <Clock className="w-4 h-4" />;
      case 'Current': return <CheckCircle className="w-4 h-4" />;
      default: return <DollarSign className="w-4 h-4" />;
    }
  };

  const filteredPayables = payables.filter(payable => {
    const matchesSearch = payable.vendor.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         payable.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || payable.status.toLowerCase() === filterStatus.toLowerCase();
    return matchesSearch && matchesFilter;
  });

  const totalPayables = payables.reduce((sum, p) => sum + p.invoice_amount, 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Enhanced Payables</h1>
          <p className="text-gray-600">Professional vendor payment management with aging analysis</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-gray-500">Total Outstanding</div>
          <div className="text-2xl font-bold text-gray-900">${totalPayables.toLocaleString()}</div>
        </div>
      </div>

      {/* Aging Analysis Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Current</p>
              <p className="text-lg font-semibold text-green-600">${agingData.current.toLocaleString()}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">1-30 Days</p>
              <p className="text-lg font-semibold text-yellow-600">${agingData.days30.toLocaleString()}</p>
            </div>
            <Clock className="w-8 h-8 text-yellow-600" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">31-60 Days</p>
              <p className="text-lg font-semibold text-orange-600">${agingData.days60.toLocaleString()}</p>
            </div>
            <AlertTriangle className="w-8 h-8 text-orange-600" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">61-90 Days</p>
              <p className="text-lg font-semibold text-red-600">${agingData.days90.toLocaleString()}</p>
            </div>
            <AlertTriangle className="w-8 h-8 text-red-600" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">90+ Days</p>
              <p className="text-lg font-semibold text-red-800">${agingData.over90.toLocaleString()}</p>
            </div>
            <AlertTriangle className="w-8 h-8 text-red-800" />
          </div>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search vendors or invoice numbers..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <select
            className="pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent appearance-none bg-white"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="all">All Status</option>
            <option value="current">Current</option>
            <option value="due soon">Due Soon</option>
            <option value="overdue">Overdue</option>
          </select>
        </div>
      </div>

      {/* Payables Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Invoice
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Vendor
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Due Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredPayables.map((payable) => (
                <tr key={payable.name} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{payable.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{payable.vendor}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      ${payable.invoice_amount.toLocaleString()}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{payable.due_date}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(payable.status)}`}>
                      {getStatusIcon(payable.status)}
                      <span className="ml-1">{payable.status}</span>
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button className="text-green-600 hover:text-green-900 mr-3">
                      Pay Now
                    </button>
                    <button className="text-blue-600 hover:text-blue-900">
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {filteredPayables.length === 0 && (
        <div className="text-center py-12">
          <DollarSign className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No payables found</h3>
          <p className="mt-1 text-sm text-gray-500">
            {searchTerm || filterStatus !== 'all' 
              ? 'Try adjusting your search or filter criteria.'
              : 'No outstanding payables at this time.'}
          </p>
        </div>
      )}
    </div>
  );
};

export default EnhancedPayablesPage;


}

