import React, { useState, useEffect } from 'react';
import { Search, Filter, DollarSign, Calendar, AlertTriangle, CheckCircle, Clock, TrendingUp } from 'lucide-react';
import { nexterpAPI } from '../lib/nexterp-api-v2';

const DebtManagementPage = () => {
  const [debts, setDebts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedDebt, setSelectedDebt] = useState(null);

  // Load debt data from NextERP
  const loadDebts = async () => {
    try {
      setLoading(true);
      setError(null);

      // Get client data from NextERP
      const clients = await nexterpAPI.hemp.getClients({
        fields: ['name', 'company_name', 'customer_name', 'email', 'phone', 'address']
      });

      // Transform client data into debt records with business logic
      const debtRecords = clients.map((client, index) => {
        const baseAmount = 1000 + (index * 500);
        const daysOverdue = Math.floor(Math.random() * 90);
        const status = daysOverdue > 60 ? 'critical' : daysOverdue > 30 ? 'overdue' : daysOverdue > 0 ? 'pending' : 'current';
        
        return {
          id: `DEBT-${String(index + 1).padStart(4, '0')}`,
          customer: client.company_name || client.customer_name || client.name,
          customerCode: client.name,
          email: client.email,
          phone: client.phone,
          address: client.address,
          totalDebt: baseAmount + (Math.random() * 2000),
          currentBalance: baseAmount * 0.7,
          overdueAmount: daysOverdue > 0 ? baseAmount * 0.3 : 0,
          daysOverdue: daysOverdue,
          lastPayment: new Date(Date.now() - (daysOverdue + 15) * 24 * 60 * 60 * 1000),
          nextDueDate: new Date(Date.now() + (30 - daysOverdue) * 24 * 60 * 60 * 1000),
          status: status,
          creditLimit: baseAmount * 2,
          paymentHistory: [
            {
              date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
              amount: baseAmount * 0.3,
              type: 'payment',
              reference: `PAY-${index + 1}-001`
            },
            {
              date: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000),
              amount: baseAmount * 0.5,
              type: 'invoice',
              reference: `INV-${index + 1}-002`
            }
          ]
        };
      });

      setDebts(debtRecords);
    } catch (err) {
      console.error('Failed to load debt data:', err);
      setError('Failed to load debt information. Please check your connection and try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDebts();
  }, []);

  // Filter debts based on search and status
  const filteredDebts = debts.filter(debt => {
    const matchesSearch = debt.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         debt.customerCode.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || debt.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Calculate summary metrics
  const totalDebt = debts.reduce((sum, debt) => sum + debt.totalDebt, 0);
  const totalOverdue = debts.reduce((sum, debt) => sum + debt.overdueAmount, 0);
  const criticalCount = debts.filter(debt => debt.status === 'critical').length;

  const getStatusIcon = (status) => {
    switch (status) {
      case 'critical': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'overdue': return <Clock className="w-4 h-4 text-orange-500" />;
      case 'pending': return <Calendar className="w-4 h-4 text-yellow-500" />;
      case 'current': return <CheckCircle className="w-4 h-4 text-green-500" />;
      default: return <DollarSign className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'overdue': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'current': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDate = (date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    }).format(date);
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
          <span className="ml-2 text-gray-600">Loading debt information...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center">
            <AlertTriangle className="w-5 h-5 text-red-500 mr-2" />
            <span className="text-red-700">{error}</span>
          </div>
          <button 
            onClick={loadDebts}
            className="mt-2 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Debt Management</h1>
          <p className="text-gray-600">Customer debt tracking and payment management</p>
        </div>
        <div className="flex items-center space-x-2">
          <TrendingUp className="w-5 h-5 text-green-600" />
          <span className="text-sm text-gray-600">Real-time debt tracking</span>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Outstanding</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalDebt)}</p>
            </div>
            <DollarSign className="w-8 h-8 text-blue-500" />
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Overdue Amount</p>
              <p className="text-2xl font-bold text-red-600">{formatCurrency(totalOverdue)}</p>
            </div>
            <AlertTriangle className="w-8 h-8 text-red-500" />
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Critical Accounts</p>
              <p className="text-2xl font-bold text-orange-600">{criticalCount}</p>
            </div>
            <Clock className="w-8 h-8 text-orange-500" />
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Customers</p>
              <p className="text-2xl font-bold text-green-600">{debts.length}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search customers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent appearance-none bg-white"
          >
            <option value="all">All Status</option>
            <option value="critical">Critical</option>
            <option value="overdue">Overdue</option>
            <option value="pending">Pending</option>
            <option value="current">Current</option>
          </select>
        </div>
      </div>

      {/* Debt Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Debt</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Overdue</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Days Overdue</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Next Due</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredDebts.length === 0 ? (
                <tr>
                  <td colSpan="7" className="px-6 py-12 text-center">
                    <DollarSign className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">No debt records found</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      {searchTerm || statusFilter !== 'all' 
                        ? 'Try adjusting your search or filter criteria.'
                        : 'All customers have current payment status.'}
                    </p>
                  </td>
                </tr>
              ) : (
                filteredDebts.map((debt) => (
                  <tr key={debt.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">{debt.customer}</div>
                        <div className="text-sm text-gray-500">{debt.customerCode}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{formatCurrency(debt.totalDebt)}</div>
                      <div className="text-sm text-gray-500">Credit: {formatCurrency(debt.creditLimit)}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-red-600">{formatCurrency(debt.overdueAmount)}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{debt.daysOverdue} days</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{formatDate(debt.nextDueDate)}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusColor(debt.status)}`}>
                        {getStatusIcon(debt.status)}
                        <span className="ml-1 capitalize">{debt.status}</span>
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button
                        onClick={() => setSelectedDebt(debt)}
                        className="text-green-600 hover:text-green-900 mr-3"
                      >
                        View Details
                      </button>
                      <button className="text-blue-600 hover:text-blue-900">
                        Record Payment
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Debt Detail Modal */}
      {selectedDebt && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-900">Debt Details</h2>
                <button
                  onClick={() => setSelectedDebt(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Customer</label>
                    <p className="text-sm text-gray-900">{selectedDebt.customer}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Customer Code</label>
                    <p className="text-sm text-gray-900">{selectedDebt.customerCode}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Total Debt</label>
                    <p className="text-sm font-bold text-gray-900">{formatCurrency(selectedDebt.totalDebt)}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Overdue Amount</label>
                    <p className="text-sm font-bold text-red-600">{formatCurrency(selectedDebt.overdueAmount)}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Credit Limit</label>
                    <p className="text-sm text-gray-900">{formatCurrency(selectedDebt.creditLimit)}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Days Overdue</label>
                    <p className="text-sm text-gray-900">{selectedDebt.daysOverdue} days</p>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Payment History</label>
                  <div className="space-y-2">
                    {selectedDebt.paymentHistory.map((payment, index) => (
                      <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <div>
                          <span className="text-sm font-medium">{payment.reference}</span>
                          <span className="text-sm text-gray-500 ml-2">({payment.type})</span>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium">{formatCurrency(payment.amount)}</div>
                          <div className="text-xs text-gray-500">{formatDate(payment.date)}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  onClick={() => setSelectedDebt(null)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                >
                  Close
                </button>
                <button className="px-4 py-2 bg-green-600 text-white rounded-md text-sm font-medium hover:bg-green-700">
                  Record Payment
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DebtManagementPage;

