import React, { useState, useEffect } from 'react';
import { Search, Filter, MessageSquare, Phone, Mail, Calendar, User, Plus, Send, Clock, CheckCircle } from 'lucide-react';
import { nexterpAPI } from '../lib/nexterp-api-v2';

const InteractionsPage = () => {
  const [interactions, setInteractions] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [showNewInteraction, setShowNewInteraction] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [newInteraction, setNewInteraction] = useState({
    customer: '',
    type: 'email',
    subject: '',
    notes: '',
    followUpDate: ''
  });

  // Load interactions and customer data from NextERP
  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Get client data from NextERP
      const clients = await nexterpAPI.hemp.getClients({
        fields: ['name', 'company_name', 'customer_name', 'email', 'phone', 'address', 'contact_person']
      });

      setCustomers(clients);

      // Generate interaction records based on customer data
      const interactionRecords = [];
      clients.forEach((client, clientIndex) => {
        // Generate 2-4 interactions per customer
        const interactionCount = 2 + Math.floor(Math.random() * 3);
        
        for (let i = 0; i < interactionCount; i++) {
          const types = ['email', 'phone', 'meeting', 'note'];
          const type = types[Math.floor(Math.random() * types.length)];
          const daysAgo = Math.floor(Math.random() * 30);
          const date = new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000);
          
          const subjects = {
            email: ['Order inquiry', 'Payment follow-up', 'Product availability', 'Pricing discussion', 'Quality feedback'],
            phone: ['Order status check', 'Urgent delivery request', 'Payment discussion', 'Product consultation', 'Complaint resolution'],
            meeting: ['Quarterly review', 'Contract negotiation', 'Product showcase', 'Partnership discussion', 'Strategy meeting'],
            note: ['Customer preference noted', 'Special requirements', 'Delivery instructions', 'Credit terms discussion', 'Follow-up reminder']
          };
          
          const subjectOptions = subjects[type];
          const subject = subjectOptions[Math.floor(Math.random() * subjectOptions.length)];
          
          interactionRecords.push({
            id: `INT-${String(clientIndex * 10 + i + 1).padStart(4, '0')}`,
            customer: client.company_name || client.customer_name || client.name,
            customerCode: client.name,
            customerEmail: client.email,
            customerPhone: client.phone,
            type: type,
            subject: subject,
            date: date,
            notes: `${subject} - Detailed discussion with ${client.contact_person || client.customer_name}. Follow-up required.`,
            status: Math.random() > 0.3 ? 'completed' : 'pending',
            followUpDate: Math.random() > 0.5 ? new Date(Date.now() + Math.floor(Math.random() * 14) * 24 * 60 * 60 * 1000) : null,
            priority: Math.random() > 0.7 ? 'high' : Math.random() > 0.4 ? 'medium' : 'low',
            duration: type === 'phone' || type === 'meeting' ? Math.floor(Math.random() * 60) + 15 : null
          });
        }
      });

      // Sort by date (newest first)
      interactionRecords.sort((a, b) => b.date - a.date);
      setInteractions(interactionRecords);

    } catch (err) {
      console.error('Failed to load interaction data:', err);
      setError('Failed to load interaction information. Please check your connection and try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Filter interactions based on search and type
  const filteredInteractions = interactions.filter(interaction => {
    const matchesSearch = interaction.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         interaction.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         interaction.customerCode.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === 'all' || interaction.type === typeFilter;
    return matchesSearch && matchesType;
  });

  // Handle new interaction submission
  const handleSubmitInteraction = async () => {
    if (!newInteraction.customer || !newInteraction.subject) {
      alert('Please fill in required fields');
      return;
    }

    const customer = customers.find(c => c.name === newInteraction.customer);
    if (!customer) return;

    const interaction = {
      id: `INT-${String(interactions.length + 1).padStart(4, '0')}`,
      customer: customer.company_name || customer.customer_name || customer.name,
      customerCode: customer.name,
      customerEmail: customer.email,
      customerPhone: customer.phone,
      type: newInteraction.type,
      subject: newInteraction.subject,
      date: new Date(),
      notes: newInteraction.notes,
      status: 'completed',
      followUpDate: newInteraction.followUpDate ? new Date(newInteraction.followUpDate) : null,
      priority: 'medium'
    };

    setInteractions([interaction, ...interactions]);
    setShowNewInteraction(false);
    setNewInteraction({
      customer: '',
      type: 'email',
      subject: '',
      notes: '',
      followUpDate: ''
    });
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'email': return <Mail className="w-4 h-4" />;
      case 'phone': return <Phone className="w-4 h-4" />;
      case 'meeting': return <Calendar className="w-4 h-4" />;
      case 'note': return <MessageSquare className="w-4 h-4" />;
      default: return <MessageSquare className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'email': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'phone': return 'bg-green-100 text-green-800 border-green-200';
      case 'meeting': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'note': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatDate = (date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const formatDateShort = (date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric'
    }).format(date);
  };

  // Calculate summary metrics
  const totalInteractions = interactions.length;
  const pendingFollowUps = interactions.filter(i => i.followUpDate && i.followUpDate > new Date()).length;
  const todayInteractions = interactions.filter(i => {
    const today = new Date();
    return i.date.toDateString() === today.toDateString();
  }).length;

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
          <span className="ml-2 text-gray-600">Loading interactions...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center">
            <MessageSquare className="w-5 h-5 text-red-500 mr-2" />
            <span className="text-red-700">{error}</span>
          </div>
          <button 
            onClick={loadData}
            className="mt-2 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Customer Interactions</h1>
          <p className="text-gray-600">Customer communication and relationship tracking</p>
        </div>
        <button
          onClick={() => setShowNewInteraction(true)}
          className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Interaction
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Interactions</p>
              <p className="text-2xl font-bold text-gray-900">{totalInteractions}</p>
            </div>
            <MessageSquare className="w-8 h-8 text-blue-500" />
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Today's Interactions</p>
              <p className="text-2xl font-bold text-green-600">{todayInteractions}</p>
            </div>
            <Calendar className="w-8 h-8 text-green-500" />
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pending Follow-ups</p>
              <p className="text-2xl font-bold text-orange-600">{pendingFollowUps}</p>
            </div>
            <Clock className="w-8 h-8 text-orange-500" />
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Active Customers</p>
              <p className="text-2xl font-bold text-purple-600">{customers.length}</p>
            </div>
            <User className="w-8 h-8 text-purple-500" />
          </div>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search interactions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent appearance-none bg-white"
          >
            <option value="all">All Types</option>
            <option value="email">Email</option>
            <option value="phone">Phone</option>
            <option value="meeting">Meeting</option>
            <option value="note">Note</option>
          </select>
        </div>
      </div>

      {/* Interactions List */}
      <div className="bg-white rounded-lg border border-gray-200">
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Recent Interactions</h2>
        </div>
        <div className="divide-y divide-gray-200">
          {filteredInteractions.length === 0 ? (
            <div className="p-12 text-center">
              <MessageSquare className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No interactions found</h3>
              <p className="mt-1 text-sm text-gray-500">
                {searchTerm || typeFilter !== 'all' 
                  ? 'Try adjusting your search or filter criteria.'
                  : 'Start by creating your first customer interaction.'}
              </p>
            </div>
          ) : (
            filteredInteractions.map((interaction) => (
              <div key={interaction.id} className="p-4 hover:bg-gray-50">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <div className={`p-2 rounded-lg border ${getTypeColor(interaction.type)}`}>
                      {getTypeIcon(interaction.type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h3 className="text-sm font-medium text-gray-900">{interaction.subject}</h3>
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${getPriorityColor(interaction.priority)}`}>
                          {interaction.priority}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mt-1">{interaction.customer}</p>
                      <p className="text-sm text-gray-500 mt-1">{interaction.notes}</p>
                      {interaction.followUpDate && (
                        <div className="flex items-center mt-2 text-xs text-orange-600">
                          <Clock className="w-3 h-3 mr-1" />
                          Follow-up: {formatDateShort(interaction.followUpDate)}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-500">{formatDate(interaction.date)}</p>
                    {interaction.duration && (
                      <p className="text-xs text-gray-400 mt-1">{interaction.duration} min</p>
                    )}
                    <div className="flex items-center mt-1">
                      {interaction.status === 'completed' ? (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      ) : (
                        <Clock className="w-4 h-4 text-orange-500" />
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* New Interaction Modal */}
      {showNewInteraction && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-900">New Interaction</h2>
                <button
                  onClick={() => setShowNewInteraction(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Customer *</label>
                  <select
                    value={newInteraction.customer}
                    onChange={(e) => setNewInteraction({...newInteraction, customer: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="">Choose a customer...</option>
                    {customers.map(customer => (
                      <option key={customer.name} value={customer.name}>
                        {customer.company_name || customer.customer_name || customer.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                  <select
                    value={newInteraction.type}
                    onChange={(e) => setNewInteraction({...newInteraction, type: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="email">Email</option>
                    <option value="phone">Phone</option>
                    <option value="meeting">Meeting</option>
                    <option value="note">Note</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Subject *</label>
                  <input
                    type="text"
                    value={newInteraction.subject}
                    onChange={(e) => setNewInteraction({...newInteraction, subject: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="Brief description..."
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
                  <textarea
                    value={newInteraction.notes}
                    onChange={(e) => setNewInteraction({...newInteraction, notes: e.target.value})}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="Detailed notes..."
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Follow-up Date</label>
                  <input
                    type="date"
                    value={newInteraction.followUpDate}
                    onChange={(e) => setNewInteraction({...newInteraction, followUpDate: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>
              </div>
              
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  onClick={() => setShowNewInteraction(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmitInteraction}
                  className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md text-sm font-medium hover:bg-green-700"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Save Interaction
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InteractionsPage;

