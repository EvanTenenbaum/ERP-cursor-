import React from 'react';

const TestPage = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-4">Test Page</h1>
      <p className="text-gray-600">This is a minimal test component to verify rendering works.</p>
      <div className="mt-4 p-4 bg-green-100 rounded-lg">
        <p className="text-green-800">If you can see this, React rendering is working correctly.</p>
      </div>
    </div>
  );
};

export default TestPage;

