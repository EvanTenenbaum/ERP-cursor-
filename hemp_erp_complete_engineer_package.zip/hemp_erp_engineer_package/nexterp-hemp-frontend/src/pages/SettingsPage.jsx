// Cannabis ERP - Settings Page
// ATOMIC PRINCIPLE: System configuration and preferences
// MODIFICATION RULE: Update CONFIG to modify available settings

import { Settings, User, Shield, Database, Bell, Palette } from 'lucide-react';
import { Button } from '@/components/ui/button';

const SettingsPage = () => {
  const settingsSections = [
    {
      title: 'User Profile',
      description: 'Manage your account settings',
      icon: User,
      color: 'text-blue-600 bg-blue-50'
    },
    {
      title: 'Security',
      description: 'Password and authentication',
      icon: Shield,
      color: 'text-red-600 bg-red-50'
    },
    {
      title: 'System',
      description: 'System configuration',
      icon: Database,
      color: 'text-green-600 bg-green-50'
    },
    {
      title: 'Notifications',
      description: 'Email and alert preferences',
      icon: Bell,
      color: 'text-yellow-600 bg-yellow-50'
    },
    {
      title: 'Appearance',
      description: 'Theme and display options',
      icon: Palette,
      color: 'text-purple-600 bg-purple-50'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <Settings className="h-8 w-8 text-primary" />
        <div>
          <h1 className="text-2xl font-bold text-foreground">Settings</h1>
          <p className="text-muted-foreground">Configure your Cannabis ERP system</p>
        </div>
      </div>

      {/* Settings Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {settingsSections.map((section) => {
          const Icon = section.icon;
          return (
            <div
              key={section.title}
              className="bg-card border border-border rounded-lg p-6"
            >
              <div className="flex items-center space-x-3 mb-3">
                <div className={`p-2 rounded-lg ${section.color}`}>
                  <Icon className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">
                  {section.title}
                </h3>
              </div>
              <p className="text-muted-foreground text-sm mb-4">
                {section.description}
              </p>
              <Button variant="outline" size="sm">
                Configure
              </Button>
            </div>
          );
        })}
      </div>

      {/* System Information */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">System Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Version</p>
            <p className="font-medium">Cannabis ERP v0.1</p>
          </div>
          <div>
            <p className="text-muted-foreground">Backend</p>
            <p className="font-medium">Hemp ERP v0.1 (ERPNext)</p>
          </div>
          <div>
            <p className="text-muted-foreground">Payment Methods</p>
            <p className="font-medium">CASH, CHECK only</p>
          </div>
          <div>
            <p className="text-muted-foreground">Architecture</p>
            <p className="font-medium">Modular, Configuration-Driven</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;

