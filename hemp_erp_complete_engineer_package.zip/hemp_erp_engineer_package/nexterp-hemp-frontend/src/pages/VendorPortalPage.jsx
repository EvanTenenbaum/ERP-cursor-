import React, { useState, useEffect } from 'react';
import { createListPage } from '../lib/pageFactory';
import { api } from '../lib/api';

const VendorPortalPage = () => {
  const [vendors, setVendors] = useState([]);
  const [samples, setSamples] = useState([]);
  const [selectedVendor, setSelectedVendor] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadVendorData();
  }, []);

  const loadVendorData = async () => {
    try {
      setLoading(true);
      const vendorData = await api.getList('Hemp Vendor Profile');
      const sampleData = await api.getList('Hemp Sample');
      
      setVendors(vendorData);
      setSamples(sampleData);
    } catch (error) {
      console.error('Error loading vendor data:', error);
      // Use mock data as fallback
      setVendors([
        {
          name: 'VENDOR-001',
          vendor_name: 'Premium Hemp Suppliers Inc.',
          email: 'sales@premiumhemp.com',
          phone: '(555) 987-6543',
          portal_enabled: 1,
          sample_calendar_enabled: 1
        },
        {
          name: 'VENDOR-002', 
          vendor_name: 'Green Valley Hemp Co.',
          email: 'contact@greenvalleyhemp.com',
          phone: '(555) 123-4567',
          portal_enabled: 1,
          sample_calendar_enabled: 0
        }
      ]);
      
      setSamples([
        {
          name: 'SAMPLE-001',
          vendor: 'VENDOR-001',
          sample_name: 'Blue Dream Sample - Batch A',
          sample_date: '2024-01-15',
          status: 'Pending Review'
        },
        {
          name: 'SAMPLE-002',
          vendor: 'VENDOR-001', 
          sample_name: 'White Widow Sample - Batch B',
          sample_date: '2024-01-20',
          status: 'Approved'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const getVendorSamples = (vendorId) => {
    return samples.filter(sample => sample.vendor === vendorId);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg text-gray-600">Loading vendor portal...</div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Vendor Portal</h1>
        <p className="text-gray-600">Self-service portal for vendor management and sample scheduling</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Vendor List */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Active Vendors</h2>
              <p className="text-sm text-gray-600">{vendors.length} vendors with portal access</p>
            </div>
            <div className="divide-y divide-gray-200">
              {vendors.map((vendor) => (
                <div
                  key={vendor.name}
                  className={`p-4 cursor-pointer hover:bg-gray-50 transition-colors ${
                    selectedVendor?.name === vendor.name ? 'bg-green-50 border-r-4 border-green-500' : ''
                  }`}
                  onClick={() => setSelectedVendor(vendor)}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium text-gray-900">{vendor.vendor_name}</h3>
                      <p className="text-sm text-gray-600">{vendor.email}</p>
                    </div>
                    <div className="flex flex-col items-end space-y-1">
                      {vendor.portal_enabled && (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Portal Active
                        </span>
                      )}
                      {vendor.sample_calendar_enabled && (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                          Samples Enabled
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Vendor Details & Sample Management */}
        <div className="lg:col-span-2">
          {selectedVendor ? (
            <div className="space-y-6">
              {/* Vendor Details */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="p-4 border-b border-gray-200">
                  <h2 className="text-lg font-semibold text-gray-900">Vendor Details</h2>
                </div>
                <div className="p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Vendor Name</label>
                      <p className="text-gray-900">{selectedVendor.vendor_name}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                      <p className="text-gray-900">{selectedVendor.email}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                      <p className="text-gray-900">{selectedVendor.phone}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Portal Status</label>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        selectedVendor.portal_enabled 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {selectedVendor.portal_enabled ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Sample Management */}
              {selectedVendor.sample_calendar_enabled && (
                <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                  <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                    <div>
                      <h2 className="text-lg font-semibold text-gray-900">Sample Management</h2>
                      <p className="text-sm text-gray-600">Manage vendor sample submissions and scheduling</p>
                    </div>
                    <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                      Schedule Sample
                    </button>
                  </div>
                  <div className="p-4">
                    {getVendorSamples(selectedVendor.name).length > 0 ? (
                      <div className="space-y-3">
                        {getVendorSamples(selectedVendor.name).map((sample) => (
                          <div key={sample.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div>
                              <h4 className="font-medium text-gray-900">{sample.sample_name}</h4>
                              <p className="text-sm text-gray-600">Submitted: {sample.sample_date}</p>
                            </div>
                            <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                              sample.status === 'Approved' 
                                ? 'bg-green-100 text-green-800'
                                : sample.status === 'Pending Review'
                                ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}>
                              {sample.status}
                            </span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-gray-600">No samples submitted yet</p>
                        <button className="mt-2 text-green-600 hover:text-green-700 font-medium">
                          Submit First Sample
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 text-center">
              <div className="text-gray-400 mb-4">
                <svg className="mx-auto h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-4m-5 0H3m2 0h3M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Select a Vendor</h3>
              <p className="text-gray-600">Choose a vendor from the list to view details and manage samples</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VendorPortalPage;

