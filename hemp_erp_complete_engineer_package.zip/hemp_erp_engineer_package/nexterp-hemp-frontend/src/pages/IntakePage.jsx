// Cannabis ERP - Intake Page (Product Creation Form)
// ATOMIC PRINCIPLE: Form-based product intake with OpenTHC strain validation
// MODIFICATION RULE: Update CONFIG.VALIDATION.REQUIRED_FIELDS.PRODUCT to modify requirements

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Package, Save, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import api from '@/lib/api';
import { CONFIG } from '@/lib/config';
import StrainAutocomplete from '../components/StrainAutocomplete.jsx';

const IntakePage = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [strains, setStrains] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [selectedStrain, setSelectedStrain] = useState(null);
  const [formData, setFormData] = useState({
    product_name: '',
    strain: '',
    vendor: ''
  });
  const [errors, setErrors] = useState({});

  // Load reference data
  useEffect(() => {
    const loadReferenceData = async () => {
      try {
        const [strainsResponse, vendorsResponse] = await Promise.all([
          api.getStrains(),
          api.getVendors()
        ]);
        
        if (strainsResponse?.data) setStrains(strainsResponse.data);
        if (vendorsResponse?.data) setVendors(vendorsResponse.data);
      } catch (error) {
        console.error('Failed to load reference data:', error);
      }
    };

    loadReferenceData();
  }, []);

  const validateForm = () => {
    const newErrors = {};
    const requiredFields = CONFIG.VALIDATION.REQUIRED_FIELDS.PRODUCT;

    requiredFields.forEach(field => {
      if (!formData[field] || formData[field].trim() === '') {
        newErrors[field] = `${field.replace('_', ' ')} is required`;
      }
    });

    // Validate field lengths
    Object.entries(CONFIG.VALIDATION.FIELD_LENGTHS).forEach(([field, maxLength]) => {
      const fieldKey = field.toLowerCase();
      if (formData[fieldKey] && formData[fieldKey].length > maxLength) {
        newErrors[fieldKey] = `${field} must be less than ${maxLength} characters`;
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));

    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const handleStrainSelect = (strain) => {
    setSelectedStrain(strain);
    setFormData(prev => ({
      ...prev,
      strain: strain.name
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      // Include OpenTHC strain data in submission
      const productData = {
        ...formData,
        openthc_id: selectedStrain?.id || null,
        strain_stub: selectedStrain?.stub || null,
        strain_type: selectedStrain?.type || null
      };

      await api.createProduct(productData);
      
      // Success - navigate back to inventory
      navigate('/inventory');
    } catch (error) {
      console.error('Failed to create product:', error);
      setErrors({ submit: 'Failed to create product. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    navigate('/inventory');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Package className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-2xl font-bold text-foreground">Product Intake</h1>
            <p className="text-muted-foreground">Add new hemp products with OpenTHC strain validation</p>
          </div>
        </div>
        
        <Button variant="outline" onClick={handleBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Inventory
        </Button>
      </div>

      {/* Form */}
      <div className="max-w-2xl">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-lg font-semibold mb-4">Product Information</h2>
            
            <div className="space-y-4">
              {/* Product Name */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Product Name *
                </label>
                <input
                  type="text"
                  value={formData.product_name}
                  onChange={(e) => handleInputChange('product_name', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring ${
                    errors.product_name ? 'border-destructive' : 'border-border'
                  }`}
                  placeholder="Enter product name"
                  maxLength={CONFIG.VALIDATION.FIELD_LENGTHS.NAME}
                />
                {errors.product_name && (
                  <p className="text-destructive text-sm mt-1">{errors.product_name}</p>
                )}
              </div>

              {/* Strain Selection with OpenTHC Autocomplete */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Strain * <span className="text-xs text-green-600">(OpenTHC Verified)</span>
                </label>
                <StrainAutocomplete
                  value={formData.strain}
                  onChange={(value) => handleInputChange('strain', value)}
                  onStrainSelect={handleStrainSelect}
                  placeholder="Search 12,804+ verified strains..."
                  className="w-full"
                />
                {selectedStrain && (
                  <div className="mt-2 p-3 bg-green-50 border border-green-200 rounded-md">
                    <div className="text-sm text-green-800">
                      ✅ Verified strain: <strong>{selectedStrain.name}</strong>
                      {selectedStrain.type && selectedStrain.type !== 'Unknown' && (
                        <span className="ml-2 px-2 py-1 text-xs bg-green-100 text-green-700 rounded-full">
                          {selectedStrain.type}
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-green-600 mt-1">
                      OpenTHC ID: {selectedStrain.id}
                    </div>
                  </div>
                )}
                {errors.strain && (
                  <p className="text-destructive text-sm mt-1">{errors.strain}</p>
                )}
              </div>

              {/* Vendor Selection */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Vendor
                </label>
                <select
                  value={formData.vendor}
                  onChange={(e) => handleInputChange('vendor', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring ${
                    errors.vendor ? 'border-destructive' : 'border-border'
                  }`}
                >
                  <option value="">Select a vendor</option>
                  {vendors.map((vendor) => (
                    <option key={vendor.name} value={vendor.name}>
                      {vendor.vendor_name}
                    </option>
                  ))}
                </select>
                {errors.vendor && (
                  <p className="text-destructive text-sm mt-1">{errors.vendor}</p>
                )}
              </div>
            </div>
          </div>

          {/* OpenTHC Integration Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="text-sm text-blue-800">
              <strong>🔬 OpenTHC Integration Active</strong>
            </div>
            <div className="text-xs text-blue-600 mt-1">
              Strain validation powered by OpenTHC Variety Database with 12,804+ verified cannabis strains
            </div>
          </div>

          {/* Submit Error */}
          {errors.submit && (
            <div className="bg-destructive/10 border border-destructive/20 rounded-md p-4">
              <p className="text-destructive font-medium">{errors.submit}</p>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-end space-x-4">
            <Button type="button" variant="outline" onClick={handleBack}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2"></div>
                  Creating...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Create Product
                </>
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default IntakePage;

