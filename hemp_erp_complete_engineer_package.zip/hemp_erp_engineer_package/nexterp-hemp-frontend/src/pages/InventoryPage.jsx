// Cannabis ERP - Inventory Page (Generated via Page Factory)
// ATOMIC PRINCIPLE: Auto-generated from configuration
// MODIFICATION RULE: Update CONFIG.DOCTYPES.INVENTORY to modify behavior

import { Package } from 'lucide-react';
import { createListPage } from '@/lib/pageFactory.jsx';

// Generate page using factory system
const InventoryPageComponent = createListPage('INVENTORY', {
  title: 'Inventory',
  description: 'Manage your hemp product inventory',
  buttonText: 'Product',
  newRecordPath: '/intake',
  icon: <Package className="h-8 w-8" />
});

// Export with display name for debugging
InventoryPageComponent.displayName = 'InventoryPage';

export default InventoryPageComponent;

