// Cannabis ERP - Customer Workspace (Enhanced with account balance and order history)
// ATOMIC PRINCIPLE: Extends existing customer management with workspace functionality
// MODIFICATION RULE: Maintains pageFactory pattern while adding customer detail drawer

import React, { useState } from 'react';
import { Users } from 'lucide-react';
import { createListPage } from '../lib/pageFactory.jsx';
import CustomerDetailDrawer from '../components/CustomerDetailDrawer.jsx';

const CustomersPage = () => {
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const handleRowClick = (customer) => {
    setSelectedCustomer(customer);
    setIsDrawerOpen(true);
  };

  const handleCloseDrawer = () => {
    setIsDrawerOpen(false);
    setSelectedCustomer(null);
  };

  // Generate base page using factory system with enhanced functionality
  const BasePage = createListPage('CUSTOMERS', {
    title: 'Customer Workspace',
    description: 'Manage customer relationships with account balance and order history',
    buttonText: 'Customer',
    icon: <Users className="h-8 w-8" />,
    onRowClick: handleRowClick
  });

  return (
    <>
      <BasePage />
      <CustomerDetailDrawer 
        customer={selectedCustomer}
        isOpen={isDrawerOpen}
        onClose={handleCloseDrawer}
      />
    </>
  );
};

// Export with display name for debugging
CustomersPage.displayName = 'CustomersPage';

export default CustomersPage;

