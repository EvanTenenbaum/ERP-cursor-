// Cannabis ERP - Vendors Page (Generated via Page Factory)
// ATOMIC PRINCIPLE: Auto-generated from configuration
// MODIFICATION RULE: Update CONFIG.DOCTYPES.VENDORS to modify behavior

import { Building2 } from 'lucide-react';
import { createListPage } from '@/lib/pageFactory.jsx';

// Generate page using factory system
const VendorsPageComponent = createListPage('VENDORS', {
  title: 'Vendors',
  description: 'Manage your hemp wholesale vendors',
  buttonText: 'Vendor',
  icon: <Building2 className="h-8 w-8" />
});

// Export with display name for debugging
VendorsPageComponent.displayName = 'VendorsPage';

export default VendorsPageComponent;

