// Cannabis ERP - Invoices Page (Placeholder)
// ATOMIC PRINCIPLE: Will be implemented in Phase 3
// MODIFICATION RULE: Replace with full implementation

import { FileText } from 'lucide-react';

const InvoicesPage = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <FileText className="h-8 w-8 text-primary" />
        <div>
          <h1 className="text-2xl font-bold text-foreground">Invoices</h1>
          <p className="text-muted-foreground">Customer invoices and billing (CASH/CHECK only)</p>
        </div>
      </div>
      
      <div className="bg-card border border-border rounded-lg p-8 text-center">
        <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-foreground mb-2">Coming Soon</h3>
        <p className="text-muted-foreground">Invoice management will be implemented in Phase 3</p>
      </div>
    </div>
  );
};

export default InvoicesPage;

