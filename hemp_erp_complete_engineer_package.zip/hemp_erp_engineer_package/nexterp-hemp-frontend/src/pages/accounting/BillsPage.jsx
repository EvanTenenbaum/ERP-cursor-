// Cannabis ERP - Enhanced Payables (Bills) Page
// ATOMIC COMPLETE: Full business logic implementation with vendor bill management
// MODIFICATION RULE: Complete implementation replacing placeholder

import React, { useState, useEffect } from 'react';
import { Receipt, Plus, Search, Filter, Calendar, DollarSign, Clock, CheckCircle, AlertCircle, Eye, Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { mockData } from '@/lib/mockData';

const BillsPage = () => {
  const [bills, setBills] = useState([]);
  const [vendors, setVendors] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isNewBillOpen, setIsNewBillOpen] = useState(false);
  const [selectedBill, setSelectedBill] = useState(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);

  // Initialize data
  useEffect(() => {
    setBills(mockData.BILLS || []);
    setVendors(mockData.VENDORS || []);
  }, []);

  // Filter bills based on search and status
  const filteredBills = bills.filter(bill => {
    const matchesSearch = bill.vendor_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         bill.bill_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         bill.reference?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || bill.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Calculate summary statistics
  const totalBills = bills.length;
  const pendingBills = bills.filter(b => b.status === 'pending').length;
  const overdueBills = bills.filter(b => b.status === 'overdue').length;
  const totalAmount = bills.reduce((sum, bill) => sum + (bill.amount || 0), 0);
  const pendingAmount = bills.filter(b => b.status === 'pending').reduce((sum, bill) => sum + (bill.amount || 0), 0);

  // Status badge styling
  const getStatusBadge = (status) => {
    const statusConfig = {
      pending: { variant: 'secondary', icon: Clock, color: 'text-yellow-600' },
      approved: { variant: 'default', icon: CheckCircle, color: 'text-green-600' },
      paid: { variant: 'default', icon: CheckCircle, color: 'text-blue-600' },
      overdue: { variant: 'destructive', icon: AlertCircle, color: 'text-red-600' }
    };
    
    const config = statusConfig[status] || statusConfig.pending;
    const Icon = config.icon;
    
    return (
      <Badge variant={config.variant} className="flex items-center space-x-1">
        <Icon className="h-3 w-3" />
        <span className="capitalize">{status}</span>
      </Badge>
    );
  };

  // Format currency
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount || 0);
  };

  // Format date
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Handle new bill creation
  const handleCreateBill = (formData) => {
    const newBill = {
      id: `BILL-${Date.now()}`,
      bill_number: `BILL-${String(bills.length + 1).padStart(4, '0')}`,
      vendor_id: formData.vendor_id,
      vendor_name: vendors.find(v => v.id === formData.vendor_id)?.company_name || 'Unknown Vendor',
      amount: parseFloat(formData.amount),
      due_date: formData.due_date,
      bill_date: formData.bill_date,
      reference: formData.reference,
      description: formData.description,
      status: 'pending',
      created_at: new Date().toISOString()
    };
    
    setBills([newBill, ...bills]);
    setIsNewBillOpen(false);
  };

  // Handle bill status update
  const handleStatusUpdate = (billId, newStatus) => {
    setBills(bills.map(bill => 
      bill.id === billId ? { ...bill, status: newStatus } : bill
    ));
  };

  // Handle bill deletion
  const handleDeleteBill = (billId) => {
    setBills(bills.filter(bill => bill.id !== billId));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Receipt className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-2xl font-bold text-foreground">Enhanced Payables</h1>
            <p className="text-muted-foreground">Vendor bills and payment management</p>
          </div>
        </div>
        
        <Dialog open={isNewBillOpen} onOpenChange={setIsNewBillOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center space-x-2">
              <Plus className="h-4 w-4" />
              <span>New Bill</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Create New Bill</DialogTitle>
            </DialogHeader>
            <NewBillForm 
              vendors={vendors} 
              onSubmit={handleCreateBill}
              onCancel={() => setIsNewBillOpen(false)}
            />
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Bills</p>
                <p className="text-2xl font-bold text-foreground">{totalBills}</p>
              </div>
              <Receipt className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending Bills</p>
                <p className="text-2xl font-bold text-yellow-600">{pendingBills}</p>
              </div>
              <Clock className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Overdue Bills</p>
                <p className="text-2xl font-bold text-red-600">{overdueBills}</p>
              </div>
              <AlertCircle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Amount</p>
                <p className="text-2xl font-bold text-foreground">{formatCurrency(totalAmount)}</p>
              </div>
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search bills by vendor, number, or reference..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="paid">Paid</SelectItem>
            <SelectItem value="overdue">Overdue</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Bills Table */}
      <Card>
        <CardHeader>
          <CardTitle>Bills List</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-3 font-medium">Bill Number</th>
                  <th className="text-left p-3 font-medium">Vendor</th>
                  <th className="text-left p-3 font-medium">Amount</th>
                  <th className="text-left p-3 font-medium">Due Date</th>
                  <th className="text-left p-3 font-medium">Status</th>
                  <th className="text-left p-3 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredBills.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="text-center p-8 text-muted-foreground">
                      {bills.length === 0 ? 'No bills found. Create your first bill to get started.' : 'No bills match your search criteria.'}
                    </td>
                  </tr>
                ) : (
                  filteredBills.map((bill) => (
                    <tr key={bill.id} className="border-b hover:bg-muted/50">
                      <td className="p-3 font-medium">{bill.bill_number}</td>
                      <td className="p-3">{bill.vendor_name}</td>
                      <td className="p-3 font-medium">{formatCurrency(bill.amount)}</td>
                      <td className="p-3">{formatDate(bill.due_date)}</td>
                      <td className="p-3">{getStatusBadge(bill.status)}</td>
                      <td className="p-3">
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSelectedBill(bill);
                              setIsViewModalOpen(true);
                            }}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          
                          {bill.status === 'pending' && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleStatusUpdate(bill.id, 'approved')}
                            >
                              <CheckCircle className="h-4 w-4" />
                            </Button>
                          )}
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteBill(bill.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Bill Detail Modal */}
      <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Bill Details</DialogTitle>
          </DialogHeader>
          {selectedBill && (
            <BillDetailView 
              bill={selectedBill} 
              onStatusUpdate={handleStatusUpdate}
              onClose={() => setIsViewModalOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

// New Bill Form Component
const NewBillForm = ({ vendors, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    vendor_id: '',
    amount: '',
    due_date: '',
    bill_date: new Date().toISOString().split('T')[0],
    reference: '',
    description: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.vendor_id && formData.amount && formData.due_date) {
      onSubmit(formData);
      setFormData({
        vendor_id: '',
        amount: '',
        due_date: '',
        bill_date: new Date().toISOString().split('T')[0],
        reference: '',
        description: ''
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="vendor_id">Vendor *</Label>
        <Select value={formData.vendor_id} onValueChange={(value) => setFormData({...formData, vendor_id: value})}>
          <SelectTrigger>
            <SelectValue placeholder="Select vendor" />
          </SelectTrigger>
          <SelectContent>
            {vendors.map((vendor) => (
              <SelectItem key={vendor.id} value={vendor.id}>
                {vendor.company_name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="amount">Amount *</Label>
        <Input
          id="amount"
          type="number"
          step="0.01"
          placeholder="0.00"
          value={formData.amount}
          onChange={(e) => setFormData({...formData, amount: e.target.value})}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="bill_date">Bill Date</Label>
          <Input
            id="bill_date"
            type="date"
            value={formData.bill_date}
            onChange={(e) => setFormData({...formData, bill_date: e.target.value})}
          />
        </div>
        
        <div>
          <Label htmlFor="due_date">Due Date *</Label>
          <Input
            id="due_date"
            type="date"
            value={formData.due_date}
            onChange={(e) => setFormData({...formData, due_date: e.target.value})}
            required
          />
        </div>
      </div>

      <div>
        <Label htmlFor="reference">Reference</Label>
        <Input
          id="reference"
          placeholder="Invoice number, PO number, etc."
          value={formData.reference}
          onChange={(e) => setFormData({...formData, reference: e.target.value})}
        />
      </div>

      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          placeholder="Bill description or notes"
          value={formData.description}
          onChange={(e) => setFormData({...formData, description: e.target.value})}
        />
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          Create Bill
        </Button>
      </div>
    </form>
  );
};

// Bill Detail View Component
const BillDetailView = ({ bill, onStatusUpdate, onClose }) => {
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount || 0);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-sm font-medium text-muted-foreground">Bill Number</Label>
          <p className="text-lg font-semibold">{bill.bill_number}</p>
        </div>
        
        <div>
          <Label className="text-sm font-medium text-muted-foreground">Vendor</Label>
          <p className="text-lg font-semibold">{bill.vendor_name}</p>
        </div>
        
        <div>
          <Label className="text-sm font-medium text-muted-foreground">Amount</Label>
          <p className="text-lg font-semibold">{formatCurrency(bill.amount)}</p>
        </div>
        
        <div>
          <Label className="text-sm font-medium text-muted-foreground">Status</Label>
          <div className="mt-1">
            <Badge variant={bill.status === 'paid' ? 'default' : 'secondary'}>
              {bill.status}
            </Badge>
          </div>
        </div>
        
        <div>
          <Label className="text-sm font-medium text-muted-foreground">Bill Date</Label>
          <p>{formatDate(bill.bill_date)}</p>
        </div>
        
        <div>
          <Label className="text-sm font-medium text-muted-foreground">Due Date</Label>
          <p>{formatDate(bill.due_date)}</p>
        </div>
      </div>

      {bill.reference && (
        <div>
          <Label className="text-sm font-medium text-muted-foreground">Reference</Label>
          <p>{bill.reference}</p>
        </div>
      )}

      {bill.description && (
        <div>
          <Label className="text-sm font-medium text-muted-foreground">Description</Label>
          <p>{bill.description}</p>
        </div>
      )}

      <div className="flex justify-between">
        <div className="space-x-2">
          {bill.status === 'pending' && (
            <Button onClick={() => onStatusUpdate(bill.id, 'approved')}>
              Approve Bill
            </Button>
          )}
          
          {bill.status === 'approved' && (
            <Button onClick={() => onStatusUpdate(bill.id, 'paid')}>
              Mark as Paid
            </Button>
          )}
        </div>
        
        <Button variant="outline" onClick={onClose}>
          Close
        </Button>
      </div>
    </div>
  );
};

export default BillsPage;

