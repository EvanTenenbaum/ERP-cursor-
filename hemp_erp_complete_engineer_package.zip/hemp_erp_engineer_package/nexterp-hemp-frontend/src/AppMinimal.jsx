import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import MinimalTest from './MinimalTest.jsx';

function AppMinimal() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<MinimalTest />} />
        <Route path="/test" element={<MinimalTest />} />
      </Routes>
    </Router>
  );
}

export default AppMinimal;

