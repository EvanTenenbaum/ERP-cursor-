/**
 * NextERP Data Service - Production Implementation
 * Based on official Frappe REST API documentation
 * https://docs.frappe.io/framework/user/en/api/rest
 */

class NextERPDataService {
  constructor() {
    // Use environment variables with fallbacks
    this.baseURL = import.meta.env.VITE_NEXTERP_BASE_URL || 'http://72.60.67.104:8000';
    this.apiKey = import.meta.env.VITE_NEXTERP_API_KEY || 'fe3daf97feaace4';
    this.apiSecret = import.meta.env.VITE_NEXTERP_API_SECRET || '4ca8ea56e336cc4';
    
    // Cache configuration
    this.cache = new Map();
    this.cacheTimeout = 5 * 60 * 1000; // 5 minutes
    this.cacheStats = { hits: 0, misses: 0 };
  }

  /**
   * Get authorization header using official Frappe token format
   * Format: "token api_key:api_secret"
   */
  getAuthHeaders() {
    return {
      'Authorization': `token ${this.apiKey}:${this.apiSecret}`,
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    };
  }

  /**
   * Make API request with proper error handling
   */
  async makeRequest(endpoint, options = {}) {
    const url = `${this.baseURL}/api/resource/${endpoint}`;
    
    const config = {
      headers: this.getAuthHeaders(),
      ...options
    };

    try {
      console.log(`Making request to: ${url}`);
      const response = await fetch(url, config);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      // Frappe returns data in { data: [...] } format
      return data.data || data;
      
    } catch (error) {
      console.error(`API Request failed for ${endpoint}:`, error);
      throw new Error(`Failed to fetch ${endpoint}: ${error.message}`);
    }
  }

  /**
   * Get cached data or fetch from API
   */
  async getCachedData(cacheKey, fetchFunction) {
    // Check cache first
    if (this.cache.has(cacheKey)) {
      const cached = this.cache.get(cacheKey);
      if (Date.now() - cached.timestamp < this.cacheTimeout) {
        this.cacheStats.hits++;
        console.log(`Cache hit for ${cacheKey}`);
        return cached.data;
      } else {
        // Remove expired cache
        this.cache.delete(cacheKey);
      }
    }

    // Cache miss - fetch from API
    this.cacheStats.misses++;
    console.log(`Cache miss for ${cacheKey} - fetching from API`);
    
    const data = await fetchFunction();
    
    // Store in cache
    this.cache.set(cacheKey, {
      data,
      timestamp: Date.now()
    });

    return data;
  }

  /**
   * Get Purchase Invoices (Payables)
   * DocType: Purchase Invoice
   */
  async getPayables(options = {}) {
    const { limit = 20, fields = ['name', 'supplier', 'grand_total', 'due_date', 'status', 'posting_date'] } = options;
    
    const cacheKey = `payables_${limit}_${JSON.stringify(fields)}`;
    
    return this.getCachedData(cacheKey, async () => {
      const queryParams = new URLSearchParams({
        fields: JSON.stringify(fields),
        limit: limit.toString(),
        order_by: 'posting_date desc'
      });

      return this.makeRequest(`Purchase Invoice?${queryParams}`);
    });
  }

  /**
   * Get Hemp Client Profiles (Customers)
   * DocType: Hemp Client Profile
   * Available fields: client_name, email, phone, license_number, creation, modified
   */
  async getCustomers(options = {}) {
    const { limit = 20, fields = ['name', 'client_name', 'email', 'phone', 'license_number', 'creation'] } = options;
    
    const cacheKey = `customers_${limit}_${JSON.stringify(fields)}`;
    
    return this.getCachedData(cacheKey, async () => {
      const queryParams = new URLSearchParams({
        fields: JSON.stringify(fields),
        limit: limit.toString(),
        order_by: 'creation desc'
      });

      return this.makeRequest(`Hemp Client Profile?${queryParams}`);
    });
  }

  /**
   * Get Hemp Products (Inventory)
   * DocType: Hemp Product
   */
  async getInventory(options = {}) {
    const { limit = 20, fields = ['name', 'item_name', 'item_code', 'creation'] } = options;
    
    const cacheKey = `inventory_${limit}_${JSON.stringify(fields)}`;
    
    return this.getCachedData(cacheKey, async () => {
      const queryParams = new URLSearchParams({
        fields: JSON.stringify(fields),
        limit: limit.toString(),
        order_by: 'creation desc'
      });

      return this.makeRequest(`Hemp Product?${queryParams}`);
    });
  }

  /**
   * Get Stock Ledger Entries
   * DocType: Stock Ledger Entry
   */
  async getStockLedger(options = {}) {
    const { limit = 50, fields = ['name', 'item_code', 'warehouse', 'actual_qty', 'posting_date', 'voucher_type'] } = options;
    
    const cacheKey = `stock_ledger_${limit}_${JSON.stringify(fields)}`;
    
    return this.getCachedData(cacheKey, async () => {
      const queryParams = new URLSearchParams({
        fields: JSON.stringify(fields),
        limit: limit.toString(),
        order_by: 'posting_date desc'
      });

      return this.makeRequest(`Stock Ledger Entry?${queryParams}`);
    });
  }

  /**
   * Get Warehouses
   * DocType: Warehouse
   */
  async getWarehouses(options = {}) {
    const { limit = 20, fields = ['name', 'warehouse_name', 'warehouse_type', 'creation'] } = options;
    
    const cacheKey = `warehouses_${limit}_${JSON.stringify(fields)}`;
    
    return this.getCachedData(cacheKey, async () => {
      const queryParams = new URLSearchParams({
        fields: JSON.stringify(fields),
        limit: limit.toString(),
        order_by: 'creation desc'
      });

      return this.makeRequest(`Warehouse?${queryParams}`);
    });
  }

  /**
   * Test API connectivity
   */
  async testConnection() {
    try {
      // Test with a simple request to get current user
      const url = `${this.baseURL}/api/method/frappe.auth.get_logged_user`;
      const response = await fetch(url, {
        headers: this.getAuthHeaders()
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      console.log('NextERP connection test successful:', data);
      
      return {
        success: true,
        user: data.message,
        baseURL: this.baseURL
      };
      
    } catch (error) {
      console.error('NextERP connection test failed:', error);
      throw new Error(`Connection test failed: ${error.message}`);
    }
  }

  /**
   * Clear cache
   */
  clearCache() {
    this.cache.clear();
    this.cacheStats = { hits: 0, misses: 0 };
    console.log('Cache cleared');
  }

  /**
   * Get cache statistics
   */
  getCacheStats() {
    return {
      ...this.cacheStats,
      cacheSize: this.cache.size,
      hitRate: this.cacheStats.hits / (this.cacheStats.hits + this.cacheStats.misses) || 0
    };
  }
}

// Export singleton instance
const nexterpDataService = new NextERPDataService();
export default nexterpDataService;

