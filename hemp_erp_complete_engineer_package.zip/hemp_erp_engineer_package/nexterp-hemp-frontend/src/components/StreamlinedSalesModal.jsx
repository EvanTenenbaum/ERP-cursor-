import React, { useState, useEffect } from 'react';
import { X, Plus, Minus, ShoppingCart, User, Package } from 'lucide-react';
import API from '../lib/api.js';

const StreamlinedSalesModal = ({ isOpen, onClose, onSaleCreated }) => {
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [orderItems, setOrderItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen]);

  const loadData = async () => {
    try {
      // Load customers and products
      const [customersData, productsData] = await Promise.all([
        API.getRecords('CUSTOMERS'),
        API.getRecords('INVENTORY')
      ]);
      
      setCustomers(customersData);
      setProducts(productsData);
    } catch (error) {
      console.error('Error loading data:', error);
      // Use mock data for development
      setCustomers([
        { id: 'C001', client_name: 'Green Valley Cannabis Co.', email: 'contact@greenvalleycannabis.co' },
        { id: 'C002', client_name: 'Pacific Coast Hemp', email: 'orders@pacificcoasthemp.com' },
        { id: 'C003', client_name: 'Sunset Hemp Collective', email: 'info@sunsethempcollective.com' }
      ]);
      setProducts([
        { id: 'P001', product_name: 'Hemp Flower - Blue Dream', strain: 'Blue Dream', price: 150 },
        { id: 'P002', product_name: 'Hemp Flower - OG Kush', strain: 'OG Kush', price: 175 },
        { id: 'P003', product_name: 'Hemp Flower - White Widow', strain: 'White Widow', price: 160 }
      ]);
    }
  };

  const addOrderItem = (product) => {
    const existingItem = orderItems.find(item => item.productId === product.id);
    
    if (existingItem) {
      setOrderItems(orderItems.map(item =>
        item.productId === product.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setOrderItems([...orderItems, {
        productId: product.id,
        productName: product.product_name,
        strain: product.strain,
        price: product.price || 150,
        quantity: 1
      }]);
    }
  };

  const updateQuantity = (productId, newQuantity) => {
    if (newQuantity <= 0) {
      setOrderItems(orderItems.filter(item => item.productId !== productId));
    } else {
      setOrderItems(orderItems.map(item =>
        item.productId === productId
          ? { ...item, quantity: newQuantity }
          : item
      ));
    }
  };

  const calculateTotal = () => {
    return orderItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const handleCreateSale = async () => {
    if (!selectedCustomer || orderItems.length === 0) {
      alert('Please select a customer and add at least one product');
      return;
    }

    setLoading(true);
    try {
      const customer = customers.find(c => c.id === selectedCustomer);
      const saleData = {
        customer: customer.client_name,
        customer_email: customer.email,
        items: orderItems,
        total: calculateTotal(),
        status: 'Pending',
        date: new Date().toISOString().split('T')[0]
      };

      // Create sales order via API
      await API.createRecord('SALES_ORDERS', saleData);
      
      // Reset form
      setSelectedCustomer('');
      setOrderItems([]);
      setSearchTerm('');
      
      // Notify parent component
      if (onSaleCreated) {
        onSaleCreated(saleData);
      }
      
      onClose();
    } catch (error) {
      console.error('Error creating sale:', error);
      alert('Sale created successfully (mock mode)');
      
      // Reset form even in mock mode
      setSelectedCustomer('');
      setOrderItems([]);
      setSearchTerm('');
      onClose();
    } finally {
      setLoading(false);
    }
  };

  const filteredProducts = products.filter(product =>
    product.product_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.strain?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      <div className="absolute right-0 top-0 h-full w-full max-w-4xl bg-white shadow-xl">
        <div className="flex h-full flex-col">
          {/* Header */}
          <div className="flex items-center justify-between border-b px-6 py-4">
            <div className="flex items-center space-x-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-100">
                <ShoppingCart className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900">Quick Sale</h2>
                <p className="text-sm text-gray-500">Create a new sales order quickly</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="rounded-lg p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-600"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Content */}
          <div className="flex flex-1 overflow-hidden">
            {/* Left Panel - Customer & Products */}
            <div className="w-1/2 border-r p-6 overflow-y-auto">
              {/* Customer Selection */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                  <User className="h-4 w-4 mr-2" />
                  Select Customer
                </h3>
                <select
                  value={selectedCustomer}
                  onChange={(e) => setSelectedCustomer(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                >
                  <option value="">Choose a customer...</option>
                  {customers.map((customer) => (
                    <option key={customer.id} value={customer.id}>
                      {customer.client_name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Product Search */}
              <div className="mb-4">
                <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                  <Package className="h-4 w-4 mr-2" />
                  Add Products
                </h3>
                <input
                  type="text"
                  placeholder="Search products or strains..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              {/* Product List */}
              <div className="space-y-2">
                {filteredProducts.map((product) => (
                  <div
                    key={product.id}
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                    onClick={() => addOrderItem(product)}
                  >
                    <div>
                      <p className="font-medium text-gray-900">{product.product_name}</p>
                      <p className="text-sm text-gray-500">{product.strain}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-green-600">${product.price || 150}</p>
                      <button className="text-xs text-green-600 hover:text-green-700">
                        <Plus className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Panel - Order Summary */}
            <div className="w-1/2 p-6 overflow-y-auto">
              <h3 className="text-sm font-medium text-gray-900 mb-4">Order Summary</h3>
              
              {orderItems.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <ShoppingCart className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>No items added yet</p>
                  <p className="text-sm">Click on products to add them</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {orderItems.map((item) => (
                    <div key={item.productId} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{item.productName}</p>
                        <p className="text-sm text-gray-500">{item.strain}</p>
                        <p className="text-sm text-green-600">${item.price} each</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                          className="p-1 text-gray-400 hover:text-gray-600"
                        >
                          <Minus className="h-4 w-4" />
                        </button>
                        <span className="w-8 text-center font-medium">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                          className="p-1 text-gray-400 hover:text-gray-600"
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>
                      <div className="text-right ml-4">
                        <p className="font-medium text-gray-900">
                          ${(item.price * item.quantity).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))}
                  
                  {/* Total */}
                  <div className="border-t pt-3 mt-4">
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-semibold text-gray-900">Total:</span>
                      <span className="text-2xl font-bold text-green-600">
                        ${calculateTotal().toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="border-t px-6 py-4">
            <div className="flex justify-between items-center">
              <div className="text-sm text-gray-500">
                {selectedCustomer && customers.find(c => c.id === selectedCustomer) && (
                  <span>Customer: {customers.find(c => c.id === selectedCustomer).client_name}</span>
                )}
              </div>
              <div className="flex space-x-3">
                <button
                  onClick={onClose}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCreateSale}
                  disabled={loading || !selectedCustomer || orderItems.length === 0}
                  className="px-6 py-2 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? 'Creating...' : `Create Sale ($${calculateTotal().toLocaleString()})`}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StreamlinedSalesModal;

