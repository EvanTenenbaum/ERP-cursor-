import React, { useState } from 'react';

const RealFoundationTestFixed = () => {
  const [testResults, setTestResults] = useState({});
  const [isRunning, setIsRunning] = useState(false);

  const runFoundationTests = async () => {
    setIsRunning(true);
    const results = {};

    // Test 1: Basic NextERP API Connectivity with correct endpoint
    try {
      console.log('Testing NextERP API connectivity with correct endpoint...');
      
      // Use backend proxy instead of direct NextERP call for security
      const token = localStorage.getItem('hemp_erp_token');
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/nexterp/foundation-test`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        results.apiConnectivity = {
          status: 'PASS',
          message: `Successfully connected to NextERP API. Retrieved ${data.data?.length || 0} hemp client profiles.`,
          data: data.data?.slice(0, 2) || [], // Show first 2 for verification
          endpoint: 'http://72.60.67.104:8000/api/resource/Hemp Client Profile'
        };
      } else {
        const errorText = await response.text();
        results.apiConnectivity = {
          status: 'FAIL',
          message: `API request failed with status: ${response.status} ${response.statusText}`,
          error: errorText,
          endpoint: 'http://72.60.67.104:8000/api/resource/Hemp Client Profile'
        };
      }
    } catch (error) {
      results.apiConnectivity = {
        status: 'FAIL',
        message: `Network error: ${error.message}`,
        error: error.toString(),
        endpoint: 'http://72.60.67.104:8000/api/resource/Hemp Client Profile'
      };
    }

    // Test 2: Data Structure Validation (only if API works)
    if (results.apiConnectivity.status === 'PASS' && results.apiConnectivity.data.length > 0) {
      try {
        const sampleRecord = results.apiConnectivity.data[0];
        const expectedFields = ['name', 'client_name', 'email', 'phone', 'license_number', 'creation'];
        const presentFields = expectedFields.filter(field => sampleRecord.hasOwnProperty(field));
        const missingFields = expectedFields.filter(field => !sampleRecord.hasOwnProperty(field));

        results.dataStructure = {
          status: missingFields.length === 0 ? 'PASS' : 'PARTIAL',
          message: missingFields.length === 0 
            ? 'All expected fields present in Hemp Client Profile'
            : `Missing fields: ${missingFields.join(', ')}`,
          presentFields,
          missingFields,
          sampleData: sampleRecord
        };
      } catch (error) {
        results.dataStructure = {
          status: 'FAIL',
          message: `Data structure validation error: ${error.message}`,
          error: error.toString()
        };
      }
    } else {
      results.dataStructure = {
        status: 'SKIP',
        message: 'Skipped due to API connectivity failure'
      };
    }

    // Test 3: Data Transformation Logic
    if (results.dataStructure.status === 'PASS') {
      try {
        const rawData = results.apiConnectivity.data;
        const transformedData = rawData.map(client => ({
          id: client.name || `CUST-${Date.now()}`,
          name: client.client_name || client.name || 'Unknown Customer',
          email: client.email || '',
          phone: client.phone || '',
          licenseNumber: client.license_number || '',
          createdDate: new Date(client.creation || Date.now()),
          // UI-friendly formats
          createdDateFormatted: new Date(client.creation || Date.now()).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
          })
        }));

        results.dataTransformation = {
          status: 'PASS',
          message: `Successfully transformed ${transformedData.length} client records`,
          transformedData: transformedData.slice(0, 2), // Show first 2
          transformationRules: {
            'client_name → name': 'Field mapping successful',
            'email → email': 'Direct field copy',
            'phone → phone': 'Direct field copy',
            'license_number → licenseNumber': 'CamelCase conversion',
            'creation → createdDate': 'Date object conversion'
          }
        };
      } catch (error) {
        results.dataTransformation = {
          status: 'FAIL',
          message: `Data transformation error: ${error.message}`,
          error: error.toString()
        };
      }
    } else {
      results.dataTransformation = {
        status: 'SKIP',
        message: 'Skipped due to data structure validation failure'
      };
    }

    // Test 4: NextERP Service Layer Integration
    if (results.dataTransformation.status === 'PASS') {
      try {
        // Test the actual NextERP Data Service integration
        const NextERPDataService = {
          async getHempClients() {
            const response = await fetch('http://72.60.67.104:8000/api/resource/Hemp Client Profile?fields=["name","client_name","email","phone","license_number","creation"]&limit=10', {
              method: 'GET',
              headers: {
                'Authorization': 'token fe3daf97feaace4:4ca8ea56e336cc4',
                'Accept': 'application/json',
                'Content-Type': 'application/json'
              }
            });
            
            if (!response.ok) {
              throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            return data.data || [];
          }
        };

        const serviceData = await NextERPDataService.getHempClients();
        
        results.serviceIntegration = {
          status: 'PASS',
          message: `NextERP Data Service working correctly. Retrieved ${serviceData.length} records.`,
          serviceData: serviceData.slice(0, 2),
          patterns: {
            'API Abstraction': 'Service layer successfully abstracts NextERP API calls',
            'Error Handling': 'Proper HTTP status code checking implemented',
            'Data Format': 'Consistent data structure returned from service'
          }
        };
      } catch (error) {
        results.serviceIntegration = {
          status: 'FAIL',
          message: `Service integration error: ${error.message}`,
          error: error.toString()
        };
      }
    } else {
      results.serviceIntegration = {
        status: 'SKIP',
        message: 'Skipped due to data transformation failure'
      };
    }

    setTestResults(results);
    setIsRunning(false);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'PASS': return { color: '#2e7d32', backgroundColor: '#e8f5e8' };
      case 'FAIL': return { color: '#d32f2f', backgroundColor: '#ffeaea' };
      case 'PARTIAL': return { color: '#f57c00', backgroundColor: '#fff3e0' };
      case 'SKIP': return { color: '#757575', backgroundColor: '#f5f5f5' };
      default: return { color: '#757575', backgroundColor: '#f5f5f5' };
    }
  };

  return (
    <div style={{ padding: '2rem', maxWidth: '1200px', margin: '0 auto' }}>
      <div style={{ marginBottom: '2rem' }}>
        <h2 style={{ color: '#333', marginBottom: '0.5rem' }}>
          Real NextERP Foundation Test (Fixed)
        </h2>
        <p style={{ color: '#666', marginBottom: '1rem' }}>
          Testing actual NextERP API integration with correct endpoint and credentials
        </p>
        <div style={{ 
          padding: '1rem', 
          backgroundColor: '#e3f2fd', 
          border: '1px solid #2196f3',
          borderRadius: '6px',
          marginBottom: '1.5rem'
        }}>
          <p style={{ margin: 0, color: '#1565c0', fontSize: '0.875rem' }}>
            <strong>Endpoint:</strong> http://72.60.67.104:8000/api/resource/Hemp Client Profile<br/>
            <strong>Authentication:</strong> Token-based authentication with correct credentials<br/>
            <strong>Purpose:</strong> Validate real NextERP connectivity and data transformation patterns
          </p>
        </div>
        
        <button
          onClick={runFoundationTests}
          disabled={isRunning}
          style={{
            padding: '0.75rem 1.5rem',
            backgroundColor: isRunning ? '#ccc' : '#2563eb',
            color: 'white',
            border: 'none',
            borderRadius: '6px',
            cursor: isRunning ? 'not-allowed' : 'pointer',
            fontSize: '1rem',
            fontWeight: '500'
          }}
        >
          {isRunning ? 'Running Real Foundation Tests...' : 'Run Real Foundation Tests (Fixed)'}
        </button>
      </div>

      {Object.keys(testResults).length > 0 && (
        <div style={{ display: 'grid', gap: '1.5rem' }}>
          {/* Test 1: API Connectivity */}
          <div style={{ 
            border: '1px solid #e0e0e0', 
            borderRadius: '8px', 
            padding: '1.5rem',
            backgroundColor: 'white'
          }}>
            <div style={{
              display: 'inline-flex',
              padding: '0.5rem 1rem',
              borderRadius: '20px',
              fontSize: '0.875rem',
              fontWeight: '600',
              marginBottom: '1rem',
              ...getStatusColor(testResults.apiConnectivity?.status)
            }}>
              {testResults.apiConnectivity?.status || 'PENDING'}
            </div>
            <h3 style={{ margin: '0 0 0.5rem 0', color: '#333' }}>NextERP API Connectivity</h3>
            <p style={{ color: '#666', margin: '0 0 1rem 0' }}>{testResults.apiConnectivity?.message}</p>
            
            {testResults.apiConnectivity?.endpoint && (
              <div style={{ 
                padding: '0.5rem 1rem', 
                backgroundColor: '#f8f9fa',
                borderRadius: '4px',
                marginBottom: '1rem',
                fontSize: '0.875rem'
              }}>
                <strong>Endpoint:</strong> {testResults.apiConnectivity.endpoint}
              </div>
            )}

            {testResults.apiConnectivity?.data && (
              <div style={{ 
                padding: '1rem', 
                backgroundColor: '#f8f9fa', 
                borderRadius: '6px',
                marginTop: '1rem'
              }}>
                <h4 style={{ margin: '0 0 0.75rem 0', color: '#333' }}>Sample Hemp Client Data:</h4>
                <pre style={{ 
                  fontSize: '0.875rem', 
                  overflow: 'auto',
                  margin: 0,
                  color: '#333'
                }}>
                  {JSON.stringify(testResults.apiConnectivity.data, null, 2)}
                </pre>
              </div>
            )}
            
            {testResults.apiConnectivity?.error && (
              <div style={{ 
                padding: '1rem', 
                backgroundColor: '#ffeaea', 
                borderRadius: '6px',
                marginTop: '1rem'
              }}>
                <h4 style={{ margin: '0 0 0.75rem 0', color: '#d32f2f' }}>Error Details:</h4>
                <pre style={{ fontSize: '0.875rem', color: '#d32f2f', margin: 0 }}>
                  {testResults.apiConnectivity.error}
                </pre>
              </div>
            )}
          </div>

          {/* Test 2: Data Structure */}
          <div style={{ 
            border: '1px solid #e0e0e0', 
            borderRadius: '8px', 
            padding: '1.5rem',
            backgroundColor: 'white'
          }}>
            <div style={{
              display: 'inline-flex',
              padding: '0.5rem 1rem',
              borderRadius: '20px',
              fontSize: '0.875rem',
              fontWeight: '600',
              marginBottom: '1rem',
              ...getStatusColor(testResults.dataStructure?.status)
            }}>
              {testResults.dataStructure?.status || 'PENDING'}
            </div>
            <h3 style={{ margin: '0 0 0.5rem 0', color: '#333' }}>Data Structure Validation</h3>
            <p style={{ color: '#666', margin: '0 0 1rem 0' }}>{testResults.dataStructure?.message}</p>
            
            {testResults.dataStructure?.presentFields && (
              <div style={{ 
                padding: '1rem', 
                backgroundColor: '#f8f9fa', 
                borderRadius: '6px',
                marginTop: '1rem'
              }}>
                <h4 style={{ margin: '0 0 0.75rem 0', color: '#333' }}>Field Analysis:</h4>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div>
                    <strong style={{ color: '#2e7d32' }}>Present Fields:</strong>
                    <ul style={{ margin: '0.5rem 0', paddingLeft: '1.5rem' }}>
                      {testResults.dataStructure.presentFields.map(field => (
                        <li key={field} style={{ color: '#2e7d32' }}>{field}</li>
                      ))}
                    </ul>
                  </div>
                  {testResults.dataStructure.missingFields?.length > 0 && (
                    <div>
                      <strong style={{ color: '#d32f2f' }}>Missing Fields:</strong>
                      <ul style={{ margin: '0.5rem 0', paddingLeft: '1.5rem' }}>
                        {testResults.dataStructure.missingFields.map(field => (
                          <li key={field} style={{ color: '#d32f2f' }}>{field}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Test 3: Data Transformation */}
          <div style={{ 
            border: '1px solid #e0e0e0', 
            borderRadius: '8px', 
            padding: '1.5rem',
            backgroundColor: 'white'
          }}>
            <div style={{
              display: 'inline-flex',
              padding: '0.5rem 1rem',
              borderRadius: '20px',
              fontSize: '0.875rem',
              fontWeight: '600',
              marginBottom: '1rem',
              ...getStatusColor(testResults.dataTransformation?.status)
            }}>
              {testResults.dataTransformation?.status || 'PENDING'}
            </div>
            <h3 style={{ margin: '0 0 0.5rem 0', color: '#333' }}>Data Transformation</h3>
            <p style={{ color: '#666', margin: '0 0 1rem 0' }}>{testResults.dataTransformation?.message}</p>
            
            {testResults.dataTransformation?.transformationRules && (
              <div style={{ 
                padding: '1rem', 
                backgroundColor: '#f8f9fa', 
                borderRadius: '6px',
                marginTop: '1rem'
              }}>
                <h4 style={{ margin: '0 0 0.75rem 0', color: '#333' }}>Transformation Rules:</h4>
                <div style={{ display: 'grid', gap: '0.5rem' }}>
                  {Object.entries(testResults.dataTransformation.transformationRules).map(([rule, status]) => (
                    <div key={rule} style={{ 
                      display: 'flex', 
                      justifyContent: 'space-between',
                      padding: '0.5rem',
                      backgroundColor: 'white',
                      borderRadius: '4px',
                      fontSize: '0.875rem'
                    }}>
                      <span style={{ fontWeight: '500', color: '#333' }}>{rule}</span>
                      <span style={{ color: '#2e7d32' }}>{status}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Test 4: Service Integration */}
          {testResults.serviceIntegration && (
            <div style={{ 
              border: '1px solid #e0e0e0', 
              borderRadius: '8px', 
              padding: '1.5rem',
              backgroundColor: 'white'
            }}>
              <div style={{
                display: 'inline-flex',
                padding: '0.5rem 1rem',
                borderRadius: '20px',
                fontSize: '0.875rem',
                fontWeight: '600',
                marginBottom: '1rem',
                ...getStatusColor(testResults.serviceIntegration?.status)
              }}>
                {testResults.serviceIntegration?.status || 'PENDING'}
              </div>
              <h3 style={{ margin: '0 0 0.5rem 0', color: '#333' }}>NextERP Service Integration</h3>
              <p style={{ color: '#666', margin: '0 0 1rem 0' }}>{testResults.serviceIntegration?.message}</p>
              
              {testResults.serviceIntegration?.patterns && (
                <div style={{ 
                  padding: '1rem', 
                  backgroundColor: '#f8f9fa', 
                  borderRadius: '6px',
                  marginTop: '1rem'
                }}>
                  <h4 style={{ margin: '0 0 0.75rem 0', color: '#333' }}>Service Layer Patterns:</h4>
                  <div style={{ display: 'grid', gap: '0.5rem' }}>
                    {Object.entries(testResults.serviceIntegration.patterns).map(([pattern, description]) => (
                      <div key={pattern} style={{ 
                        display: 'flex', 
                        justifyContent: 'space-between',
                        padding: '0.5rem',
                        backgroundColor: 'white',
                        borderRadius: '4px',
                        fontSize: '0.875rem'
                      }}>
                        <span style={{ fontWeight: '500', color: '#333' }}>{pattern}</span>
                        <span style={{ color: '#2e7d32' }}>✓</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {Object.keys(testResults).length > 0 && (
        <div style={{ 
          marginTop: '2rem', 
          padding: '1.5rem', 
          backgroundColor: '#e3f2fd', 
          borderRadius: '8px',
          border: '1px solid #2196f3'
        }}>
          <h3 style={{ margin: '0 0 1rem 0', color: '#1565c0' }}>Foundation Test Summary</h3>
          <div style={{ fontSize: '0.875rem', color: '#1565c0' }}>
            <p style={{ margin: '0.25rem 0' }}>• API Connectivity: {testResults.apiConnectivity?.status}</p>
            <p style={{ margin: '0.25rem 0' }}>• Data Structure: {testResults.dataStructure?.status}</p>
            <p style={{ margin: '0.25rem 0' }}>• Data Transformation: {testResults.dataTransformation?.status}</p>
            <p style={{ margin: '0.25rem 0' }}>• Service Integration: {testResults.serviceIntegration?.status}</p>
          </div>
          
          {testResults.apiConnectivity?.status === 'PASS' && 
           testResults.dataStructure?.status === 'PASS' && 
           testResults.dataTransformation?.status === 'PASS' &&
           testResults.serviceIntegration?.status === 'PASS' && (
            <div style={{ 
              marginTop: '1rem', 
              padding: '1rem', 
              backgroundColor: '#e8f5e8', 
              borderRadius: '6px',
              border: '1px solid #4caf50'
            }}>
              <p style={{ margin: 0, color: '#2e7d32', fontWeight: '600' }}>
                🎉 ATOMIC COMPLETE FOUNDATION READY!
              </p>
              <p style={{ margin: '0.5rem 0 0 0', color: '#2e7d32', fontSize: '0.875rem' }}>
                Real NextERP integration validated. Foundation architecture is solid and ready for cookie-cutter template development.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default RealFoundationTestFixed;

