import React, { useState, useEffect, useRef } from 'react';
import { searchStrains } from '../data/openthc-strains.js';

const StrainAutocomplete = ({ 
  value = '', 
  onChange, 
  placeholder = 'Search strains...', 
  className = '',
  onStrainSelect 
}) => {
  const [query, setQuery] = useState(value);
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef(null);
  const suggestionsRef = useRef(null);

  useEffect(() => {
    setQuery(value);
  }, [value]);

  useEffect(() => {
    if (query.length >= 2) {
      const results = searchStrains(query);
      setSuggestions(results);
      setShowSuggestions(results.length > 0);
      setSelectedIndex(-1);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [query]);

  const handleInputChange = (e) => {
    const newQuery = e.target.value;
    setQuery(newQuery);
    if (onChange) {
      onChange(newQuery);
    }
  };

  const handleSuggestionClick = (strain) => {
    setQuery(strain.name);
    setShowSuggestions(false);
    if (onChange) {
      onChange(strain.name);
    }
    if (onStrainSelect) {
      onStrainSelect(strain);
    }
  };

  const handleKeyDown = (e) => {
    if (!showSuggestions) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => 
          prev < suggestions.length - 1 ? prev + 1 : prev
        );
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => prev > 0 ? prev - 1 : -1);
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0) {
          handleSuggestionClick(suggestions[selectedIndex]);
        }
        break;
      case 'Escape':
        setShowSuggestions(false);
        setSelectedIndex(-1);
        break;
    }
  };

  const handleBlur = (e) => {
    // Delay hiding suggestions to allow click events
    setTimeout(() => {
      setShowSuggestions(false);
    }, 200);
  };

  return (
    <div className={`relative ${className}`}>
      <input
        ref={inputRef}
        type="text"
        value={query}
        onChange={handleInputChange}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
        onFocus={() => {
          if (suggestions.length > 0) {
            setShowSuggestions(true);
          }
        }}
        placeholder={placeholder}
        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
        autoComplete="off"
      />
      
      {showSuggestions && suggestions.length > 0 && (
        <div 
          ref={suggestionsRef}
          className="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-y-auto"
        >
          {suggestions.map((strain, index) => (
            <div
              key={strain.id}
              onClick={() => handleSuggestionClick(strain)}
              className={`px-3 py-2 cursor-pointer hover:bg-green-50 ${
                index === selectedIndex ? 'bg-green-100' : ''
              }`}
            >
              <div className="flex justify-between items-center">
                <div>
                  <div className="font-medium text-gray-900">{strain.name}</div>
                  <div className="text-sm text-gray-500">{strain.stub}</div>
                </div>
                {strain.type && strain.type !== 'Unknown' && (
                  <span className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">
                    {strain.type}
                  </span>
                )}
              </div>
            </div>
          ))}
          
          <div className="px-3 py-2 text-xs text-gray-500 border-t border-gray-200 bg-gray-50">
            Powered by OpenTHC Variety Database
          </div>
        </div>
      )}
    </div>
  );
};

export default StrainAutocomplete;

