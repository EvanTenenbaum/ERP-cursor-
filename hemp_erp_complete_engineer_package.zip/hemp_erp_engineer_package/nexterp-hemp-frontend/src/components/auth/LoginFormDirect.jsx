import React, { useState } from 'react';

const LoginFormDirect = ({ onLoginSuccess }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  const handleDirectTest = async () => {
    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      console.log('Starting direct API test...');
      
      const response = await fetch('http://localhost:5002/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          username: '', // Hardcoded credentials removed for security
          password: ''  // Users must enter credentials manually
        })
      });

      console.log('Response received:', response);
      console.log('Response status:', response.status);
      console.log('Response ok:', response.ok);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      console.log('Response data:', data);

      if (data.success && data.access_token) {
        setSuccess('Login successful! Token received.');
        localStorage.setItem('hemp_erp_token', data.access_token);
        localStorage.setItem('hemp_erp_user', JSON.stringify(data.user));
        
        if (onLoginSuccess) {
          onLoginSuccess(data);
        }
      } else {
        setError('Login failed: ' + (data.message || 'Unknown error'));
      }
    } catch (err) {
      console.error('Login error:', err);
      setError(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ 
      maxWidth: '500px', 
      margin: '50px auto', 
      padding: '30px', 
      border: '2px solid #ddd', 
      borderRadius: '8px',
      backgroundColor: '#f9f9f9'
    }}>
      <h2>Hemp ERP Direct API Test</h2>
      <p>Testing direct API connection to backend</p>
      
      {error && (
        <div style={{ 
          color: 'red', 
          marginBottom: '15px', 
          padding: '15px', 
          backgroundColor: '#ffe6e6', 
          border: '1px solid #ff9999', 
          borderRadius: '4px',
          fontFamily: 'monospace',
          fontSize: '12px'
        }}>
          {error}
        </div>
      )}

      {success && (
        <div style={{ 
          color: 'green', 
          marginBottom: '15px', 
          padding: '15px', 
          backgroundColor: '#e6ffe6', 
          border: '1px solid #99ff99', 
          borderRadius: '4px',
          fontFamily: 'monospace',
          fontSize: '12px'
        }}>
          {success}
        </div>
      )}
      
      <button 
        onClick={handleDirectTest}
        disabled={loading}
        style={{ 
          width: '100%', 
          padding: '15px', 
          backgroundColor: loading ? '#ccc' : '#007bff', 
          color: 'white', 
          border: 'none', 
          borderRadius: '4px',
          fontSize: '16px',
          cursor: loading ? 'not-allowed' : 'pointer',
          marginBottom: '20px'
        }}
      >
        {loading ? 'Testing API Connection...' : 'Test Direct API Connection'}
      </button>

      <div style={{ fontSize: '12px', color: '#666', marginTop: '20px' }}>
        <p><strong>Test Details:</strong></p>
        <p>• Endpoint: http://localhost:5002/api/auth/login</p>
        <p>• Method: POST</p>
        <p>• Credentials: admin / HempERP_Admin_2025_Secure!@#$</p>
        <p>• Check browser console for detailed logs</p>
      </div>
    </div>
  );
};

export default LoginFormDirect;

