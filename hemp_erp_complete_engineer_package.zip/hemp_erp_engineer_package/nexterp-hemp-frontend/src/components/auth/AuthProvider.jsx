import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing token on app load
    const token = localStorage.getItem('hemp_erp_token');
    const userData = localStorage.getItem('hemp_erp_user');
    
    if (token && userData) {
      try {
        setUser(JSON.parse(userData));
        setIsAuthenticated(true);
      } catch (err) {
        // Invalid stored data, clear it
        localStorage.removeItem('hemp_erp_token');
        localStorage.removeItem('hemp_erp_user');
      }
    }
    
    setLoading(false);
  }, []);

  const login = (loginData) => {
    localStorage.setItem('hemp_erp_token', loginData.access_token);
    localStorage.setItem('hemp_erp_user', JSON.stringify(loginData.user));
    setUser(loginData.user);
    setIsAuthenticated(true);
  };

  const logout = () => {
    localStorage.removeItem('hemp_erp_token');
    localStorage.removeItem('hemp_erp_user');
    setUser(null);
    setIsAuthenticated(false);
  };

  const value = {
    isAuthenticated,
    user,
    login,
    logout,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;

