// Cannabis ERP - Record Drawer Component
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  X, 
  FileText, 
  Paperclip, 
  Activity, 
  Edit,
  Save,
  Calendar,
  User
} from 'lucide-react';

const RecordDrawer = ({ 
  isOpen, 
  onClose, 
  record = null, 
  title = '',
  onSave = () => {},
  onEdit = () => {},
  loading = false 
}) => {
  const [activeTab, setActiveTab] = useState('summary');
  const [isEditing, setIsEditing] = useState(false);

  if (!isOpen || !record) return null;

  const tabs = [
    { id: 'summary', label: 'Summary', icon: FileText },
    { id: 'details', label: 'Details', icon: Edit },
    { id: 'files', label: 'Files', icon: Paperclip },
    { id: 'activity', label: 'Activity', icon: Activity }
  ];

  const handleSave = () => {
    onSave(record);
    setIsEditing(false);
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString();
  };

  const formatCurrency = (amount) => {
    if (!amount) return '$0.00';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      
      {/* Drawer */}
      <div className="absolute right-0 top-0 h-full w-full max-w-2xl bg-background border-l border-border shadow-xl">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-border">
            <div className="flex items-center space-x-3">
              <h2 className="text-lg font-semibold text-foreground">{title}</h2>
              {record.name && (
                <span className="text-sm text-muted-foreground">#{record.name}</span>
              )}
            </div>
            
            <div className="flex items-center space-x-2">
              {isEditing ? (
                <>
                  <Button size="sm" onClick={handleSave} disabled={loading}>
                    <Save className="h-4 w-4 mr-2" />
                    Save
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => setIsEditing(false)}
                  >
                    Cancel
                  </Button>
                </>
              ) : (
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={() => setIsEditing(true)}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              )}
              
              <Button size="sm" variant="ghost" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-border">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'border-primary text-primary'
                      : 'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-4">
            {activeTab === 'summary' && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Created</label>
                    <div className="flex items-center space-x-2 mt-1">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{formatDate(record.creation)}</span>
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Modified</label>
                    <div className="flex items-center space-x-2 mt-1">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{formatDate(record.modified)}</span>
                    </div>
                  </div>
                </div>

                {record.owner && (
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Owner</label>
                    <div className="flex items-center space-x-2 mt-1">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{record.owner}</span>
                    </div>
                  </div>
                )}

                {/* Dynamic summary fields based on record type */}
                {record.client_name && (
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Client Name</label>
                    <p className="text-lg font-semibold mt-1">{record.client_name}</p>
                  </div>
                )}

                {record.vendor_name && (
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Vendor Name</label>
                    <p className="text-lg font-semibold mt-1">{record.vendor_name}</p>
                  </div>
                )}

                {record.product_name && (
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Product Name</label>
                    <p className="text-lg font-semibold mt-1">{record.product_name}</p>
                  </div>
                )}

                {record.total_amount && (
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Total Amount</label>
                    <p className="text-2xl font-bold text-green-600 mt-1">
                      {formatCurrency(record.total_amount)}
                    </p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'details' && (
              <div className="space-y-4">
                {Object.entries(record).map(([key, value]) => {
                  if (['name', 'creation', 'modified', 'owner'].includes(key)) return null;
                  
                  return (
                    <div key={key}>
                      <label className="text-sm font-medium text-muted-foreground capitalize">
                        {key.replace(/_/g, ' ')}
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={value || ''}
                          onChange={(e) => {
                            // Handle field updates
                            console.log(`Update ${key}:`, e.target.value);
                          }}
                          className="w-full mt-1 px-3 py-2 border border-border rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                        />
                      ) : (
                        <p className="mt-1 text-sm">{value || 'N/A'}</p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {activeTab === 'files' && (
              <div className="text-center py-8">
                <Paperclip className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No files attached</p>
                <Button variant="outline" size="sm" className="mt-4">
                  Upload File
                </Button>
              </div>
            )}

            {activeTab === 'activity' && (
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <User className="h-4 w-4 text-primary-foreground" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm">
                      <span className="font-medium">System</span> created this record
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {formatDate(record.creation)}
                    </p>
                  </div>
                </div>

                {record.modified !== record.creation && (
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                      <Edit className="h-4 w-4 text-secondary-foreground" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm">
                        <span className="font-medium">System</span> updated this record
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {formatDate(record.modified)}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecordDrawer;

