import React, { useState } from 'react';

const ProxyFoundationTest = () => {
  const [testResults, setTestResults] = useState({});
  const [isRunning, setIsRunning] = useState(false);

  const runProxyFoundationTests = async () => {
    setIsRunning(true);
    
    try {
      console.log('Running foundation tests via NextERP proxy...');
      
      // Call the NextERP proxy foundation test endpoint using environment variable
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/nexterp/foundation-test`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        setTestResults(data);
      } else {
        const errorText = await response.text();
        setTestResults({
          success: false,
          error: `Proxy request failed with status: ${response.status} ${response.statusText}`,
          details: errorText
        });
      }
    } catch (error) {
      setTestResults({
        success: false,
        error: `Network error: ${error.message}`,
        details: error.toString()
      });
    }
    
    setIsRunning(false);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'PASS': return { color: '#2e7d32', backgroundColor: '#e8f5e8' };
      case 'FAIL': return { color: '#d32f2f', backgroundColor: '#ffeaea' };
      case 'PARTIAL': return { color: '#f57c00', backgroundColor: '#fff3e0' };
      case 'SKIP': return { color: '#757575', backgroundColor: '#f5f5f5' };
      default: return { color: '#757575', backgroundColor: '#f5f5f5' };
    }
  };

  return (
    <div style={{ padding: '2rem', maxWidth: '1200px', margin: '0 auto' }}>
      <div style={{ marginBottom: '2rem' }}>
        <h2 style={{ color: '#333', marginBottom: '0.5rem' }}>
          NextERP Proxy Foundation Test
        </h2>
        <p style={{ color: '#666', marginBottom: '1rem' }}>
          Testing NextERP integration via server-side proxy (CORS-free)
        </p>
        <div style={{ 
          padding: '1rem', 
          backgroundColor: '#e8f5e8', 
          border: '1px solid #4caf50',
          borderRadius: '6px',
          marginBottom: '1.5rem'
        }}>
          <p style={{ margin: 0, color: '#2e7d32', fontSize: '0.875rem' }}>
            <strong>✅ CORS Resolved:</strong> Using server-side proxy at http://localhost:5001<br/>
            <strong>✅ Real API:</strong> Direct NextERP connectivity with proper authentication<br/>
            <strong>✅ Production Ready:</strong> Scalable architecture for deployment
          </p>
        </div>
        
        <button
          onClick={runProxyFoundationTests}
          disabled={isRunning}
          style={{
            padding: '0.75rem 1.5rem',
            backgroundColor: isRunning ? '#ccc' : '#4caf50',
            color: 'white',
            border: 'none',
            borderRadius: '6px',
            cursor: isRunning ? 'not-allowed' : 'pointer',
            fontSize: '1rem',
            fontWeight: '500'
          }}
        >
          {isRunning ? 'Running Proxy Foundation Tests...' : 'Run Proxy Foundation Tests'}
        </button>
      </div>

      {testResults.success === false && (
        <div style={{ 
          padding: '1.5rem', 
          backgroundColor: '#ffeaea', 
          border: '1px solid #d32f2f',
          borderRadius: '8px',
          marginBottom: '2rem'
        }}>
          <h3 style={{ margin: '0 0 1rem 0', color: '#d32f2f' }}>Proxy Connection Error</h3>
          <p style={{ color: '#d32f2f', margin: '0 0 1rem 0' }}>{testResults.error}</p>
          {testResults.details && (
            <pre style={{ fontSize: '0.875rem', color: '#d32f2f', margin: 0, overflow: 'auto' }}>
              {testResults.details}
            </pre>
          )}
        </div>
      )}

      {testResults.success && (
        <div style={{ display: 'grid', gap: '1.5rem' }}>
          {/* Test Results Grid */}
          {Object.entries(testResults.test_results || {}).map(([testName, result]) => (
            <div key={testName} style={{ 
              border: '1px solid #e0e0e0', 
              borderRadius: '8px', 
              padding: '1.5rem',
              backgroundColor: 'white'
            }}>
              <div style={{
                display: 'inline-flex',
                padding: '0.5rem 1rem',
                borderRadius: '20px',
                fontSize: '0.875rem',
                fontWeight: '600',
                marginBottom: '1rem',
                ...getStatusColor(result.status)
              }}>
                {result.status}
              </div>
              
              <h3 style={{ margin: '0 0 0.5rem 0', color: '#333', textTransform: 'capitalize' }}>
                {testName.replace(/_/g, ' ')}
              </h3>
              <p style={{ color: '#666', margin: '0 0 1rem 0' }}>{result.message}</p>
              
              {/* Sample Data Display */}
              {result.data && (
                <div style={{ 
                  padding: '1rem', 
                  backgroundColor: '#f8f9fa', 
                  borderRadius: '6px',
                  marginTop: '1rem'
                }}>
                  <h4 style={{ margin: '0 0 0.75rem 0', color: '#333' }}>Sample Data:</h4>
                  <pre style={{ 
                    fontSize: '0.875rem', 
                    overflow: 'auto',
                    margin: 0,
                    color: '#333'
                  }}>
                    {JSON.stringify(result.data.slice(0, 1), null, 2)}
                  </pre>
                </div>
              )}

              {/* Sample Data Display for single record */}
              {result.sample_data && (
                <div style={{ 
                  padding: '1rem', 
                  backgroundColor: '#f8f9fa', 
                  borderRadius: '6px',
                  marginTop: '1rem'
                }}>
                  <h4 style={{ margin: '0 0 0.75rem 0', color: '#333' }}>Sample Record:</h4>
                  <pre style={{ 
                    fontSize: '0.875rem', 
                    overflow: 'auto',
                    margin: 0,
                    color: '#333'
                  }}>
                    {JSON.stringify(result.sample_data, null, 2)}
                  </pre>
                </div>
              )}

              {/* Field Analysis */}
              {result.present_fields && (
                <div style={{ 
                  padding: '1rem', 
                  backgroundColor: '#f8f9fa', 
                  borderRadius: '6px',
                  marginTop: '1rem'
                }}>
                  <h4 style={{ margin: '0 0 0.75rem 0', color: '#333' }}>Field Analysis:</h4>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                    <div>
                      <strong style={{ color: '#2e7d32' }}>Present Fields ({result.present_fields.length}):</strong>
                      <ul style={{ margin: '0.5rem 0', paddingLeft: '1.5rem' }}>
                        {result.present_fields.map(field => (
                          <li key={field} style={{ color: '#2e7d32' }}>{field}</li>
                        ))}
                      </ul>
                    </div>
                    {result.missing_fields?.length > 0 && (
                      <div>
                        <strong style={{ color: '#d32f2f' }}>Missing Fields ({result.missing_fields.length}):</strong>
                        <ul style={{ margin: '0.5rem 0', paddingLeft: '1.5rem' }}>
                          {result.missing_fields.map(field => (
                            <li key={field} style={{ color: '#d32f2f' }}>{field}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Transformation Rules */}
              {result.transformation_rules && (
                <div style={{ 
                  padding: '1rem', 
                  backgroundColor: '#f8f9fa', 
                  borderRadius: '6px',
                  marginTop: '1rem'
                }}>
                  <h4 style={{ margin: '0 0 0.75rem 0', color: '#333' }}>Transformation Rules:</h4>
                  <div style={{ display: 'grid', gap: '0.5rem' }}>
                    {Object.entries(result.transformation_rules).map(([rule, status]) => (
                      <div key={rule} style={{ 
                        display: 'flex', 
                        justifyContent: 'space-between',
                        padding: '0.5rem',
                        backgroundColor: 'white',
                        borderRadius: '4px',
                        fontSize: '0.875rem'
                      }}>
                        <span style={{ fontWeight: '500', color: '#333' }}>{rule}</span>
                        <span style={{ color: '#2e7d32' }}>✓</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Service Patterns */}
              {result.patterns && (
                <div style={{ 
                  padding: '1rem', 
                  backgroundColor: '#f8f9fa', 
                  borderRadius: '6px',
                  marginTop: '1rem'
                }}>
                  <h4 style={{ margin: '0 0 0.75rem 0', color: '#333' }}>Service Patterns:</h4>
                  <div style={{ display: 'grid', gap: '0.5rem' }}>
                    {Object.entries(result.patterns).map(([pattern, description]) => (
                      <div key={pattern} style={{ 
                        padding: '0.5rem',
                        backgroundColor: 'white',
                        borderRadius: '4px',
                        fontSize: '0.875rem'
                      }}>
                        <div style={{ fontWeight: '500', color: '#333', marginBottom: '0.25rem' }}>
                          {pattern} ✓
                        </div>
                        <div style={{ color: '#666', fontSize: '0.8rem' }}>
                          {description}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Transformed Data */}
              {result.transformed_data && (
                <div style={{ 
                  padding: '1rem', 
                  backgroundColor: '#f8f9fa', 
                  borderRadius: '6px',
                  marginTop: '1rem'
                }}>
                  <h4 style={{ margin: '0 0 0.75rem 0', color: '#333' }}>Transformed Data Sample:</h4>
                  <pre style={{ 
                    fontSize: '0.875rem', 
                    overflow: 'auto',
                    margin: 0,
                    color: '#333'
                  }}>
                    {JSON.stringify(result.transformed_data.slice(0, 1), null, 2)}
                  </pre>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {testResults.success && (
        <div style={{ 
          marginTop: '2rem', 
          padding: '1.5rem', 
          backgroundColor: testResults.foundation_ready ? '#e8f5e8' : '#e3f2fd', 
          borderRadius: '8px',
          border: `1px solid ${testResults.foundation_ready ? '#4caf50' : '#2196f3'}`
        }}>
          <h3 style={{ 
            margin: '0 0 1rem 0', 
            color: testResults.foundation_ready ? '#2e7d32' : '#1565c0' 
          }}>
            Foundation Test Summary
          </h3>
          
          <div style={{ 
            fontSize: '0.875rem', 
            color: testResults.foundation_ready ? '#2e7d32' : '#1565c0' 
          }}>
            {testResults.summary && Object.entries(testResults.summary).map(([test, status]) => (
              <p key={test} style={{ margin: '0.25rem 0' }}>
                • {test.replace(/_/g, ' ')}: {status}
              </p>
            ))}
          </div>
          
          {testResults.foundation_ready && (
            <div style={{ 
              marginTop: '1rem', 
              padding: '1rem', 
              backgroundColor: '#c8e6c9', 
              borderRadius: '6px',
              border: '1px solid #4caf50'
            }}>
              <p style={{ margin: 0, color: '#1b5e20', fontWeight: '600' }}>
                🎉 ATOMIC COMPLETE FOUNDATION ACHIEVED!
              </p>
              <p style={{ margin: '0.5rem 0 0 0', color: '#1b5e20', fontSize: '0.875rem' }}>
                NextERP integration fully validated. Foundation architecture is solid and ready for cookie-cutter template development with real data.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ProxyFoundationTest;

