import React from 'react';
import { CONFIG } from '../lib/config.js';

const CompanyTypeSelect = ({ value, onChange, placeholder = "Select company type..." }) => {
  return (
    <div className="relative">
      <select
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
      >
        <option value="">{placeholder}</option>
        {CONFIG.OPENTHC.COMPANY_TYPES.map((type) => (
          <option key={type} value={type}>
            {type}
          </option>
        ))}
      </select>
      <div className="absolute right-2 top-2 text-xs text-gray-400">
        OpenTHC Standard
      </div>
    </div>
  );
};

export default CompanyTypeSelect;

