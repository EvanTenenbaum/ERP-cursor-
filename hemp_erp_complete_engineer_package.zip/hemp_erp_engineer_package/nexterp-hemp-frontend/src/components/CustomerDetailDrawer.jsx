import React, { useState, useEffect } from 'react';
import { X, User, Mail, Phone, MapPin, DollarSign, ShoppingCart, Calendar } from 'lucide-react';
import API from '../lib/api.js';

const CustomerDetailDrawer = ({ customer, isOpen, onClose }) => {
  const [orderHistory, setOrderHistory] = useState([]);
  const [accountBalance, setAccountBalance] = useState({
    totalSpent: 0,
    orderCount: 0,
    lastOrderDate: null,
    averageOrderValue: 0
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen && customer) {
      loadCustomerData();
    }
  }, [isOpen, customer]);

  const loadCustomerData = async () => {
    setLoading(true);
    try {
      // Load order history for this customer
      const orders = await API.getRecords('SALES_ORDERS', {
        filters: { customer: customer.client_name }
      });
      
      setOrderHistory(orders.slice(0, 10)); // Show last 10 orders
      
      // Calculate account balance metrics
      const totalSpent = orders.reduce((sum, order) => sum + (order.total || 0), 0);
      const orderCount = orders.length;
      const lastOrder = orders.length > 0 ? orders[0] : null;
      const averageOrderValue = orderCount > 0 ? totalSpent / orderCount : 0;
      
      setAccountBalance({
        totalSpent,
        orderCount,
        lastOrderDate: lastOrder?.date,
        averageOrderValue
      });
    } catch (error) {
      console.error('Error loading customer data:', error);
      // Use mock data for development
      setOrderHistory([
        { id: 'SO-001', date: '2024-01-15', total: 2500, status: 'Completed' },
        { id: 'SO-002', date: '2024-01-08', total: 1800, status: 'Completed' },
        { id: 'SO-003', date: '2023-12-22', total: 3200, status: 'Completed' }
      ]);
      setAccountBalance({
        totalSpent: 7500,
        orderCount: 3,
        lastOrderDate: '2024-01-15',
        averageOrderValue: 2500
      });
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen || !customer) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      <div className="absolute right-0 top-0 h-full w-full max-w-2xl bg-white shadow-xl">
        <div className="flex h-full flex-col">
          {/* Header */}
          <div className="flex items-center justify-between border-b px-6 py-4">
            <div className="flex items-center space-x-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-100">
                <User className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900">
                  {customer.client_name}
                </h2>
                <p className="text-sm text-gray-500">Customer Details</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="rounded-lg p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-600"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-gray-500">Loading customer data...</div>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Contact Information */}
                <div>
                  <h3 className="text-sm font-medium text-gray-900 mb-3">Contact Information</h3>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <Mail className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{customer.email || 'No email provided'}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Phone className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{customer.phone || 'No phone provided'}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <MapPin className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{customer.address || 'No address provided'}</span>
                    </div>
                  </div>
                </div>

                {/* Account Balance */}
                <div>
                  <h3 className="text-sm font-medium text-gray-900 mb-3">Account Summary</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-green-50 rounded-lg p-4">
                      <div className="flex items-center space-x-2">
                        <DollarSign className="h-4 w-4 text-green-600" />
                        <span className="text-sm font-medium text-green-900">Total Spent</span>
                      </div>
                      <p className="text-2xl font-bold text-green-600 mt-1">
                        ${accountBalance.totalSpent.toLocaleString()}
                      </p>
                    </div>
                    <div className="bg-blue-50 rounded-lg p-4">
                      <div className="flex items-center space-x-2">
                        <ShoppingCart className="h-4 w-4 text-blue-600" />
                        <span className="text-sm font-medium text-blue-900">Total Orders</span>
                      </div>
                      <p className="text-2xl font-bold text-blue-600 mt-1">
                        {accountBalance.orderCount}
                      </p>
                    </div>
                    <div className="bg-purple-50 rounded-lg p-4">
                      <div className="flex items-center space-x-2">
                        <DollarSign className="h-4 w-4 text-purple-600" />
                        <span className="text-sm font-medium text-purple-900">Avg Order</span>
                      </div>
                      <p className="text-2xl font-bold text-purple-600 mt-1">
                        ${accountBalance.averageOrderValue.toLocaleString()}
                      </p>
                    </div>
                    <div className="bg-orange-50 rounded-lg p-4">
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4 text-orange-600" />
                        <span className="text-sm font-medium text-orange-900">Last Order</span>
                      </div>
                      <p className="text-sm font-bold text-orange-600 mt-1">
                        {accountBalance.lastOrderDate || 'No orders'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Order History */}
                <div>
                  <h3 className="text-sm font-medium text-gray-900 mb-3">Recent Orders</h3>
                  {orderHistory.length > 0 ? (
                    <div className="space-y-3">
                      {orderHistory.map((order) => (
                        <div key={order.id} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium text-gray-900">{order.id}</p>
                              <p className="text-sm text-gray-500">{order.date}</p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium text-gray-900">${order.total?.toLocaleString()}</p>
                              <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                                order.status === 'Completed' 
                                  ? 'bg-green-100 text-green-800'
                                  : order.status === 'Pending'
                                  ? 'bg-yellow-100 text-yellow-800'
                                  : 'bg-gray-100 text-gray-800'
                              }`}>
                                {order.status}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      No orders found for this customer
                    </div>
                  )}
                </div>

                {/* License Information */}
                {customer.license_number && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-900 mb-3">License Information</h3>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <p className="text-sm font-medium text-gray-900">License Number</p>
                      <p className="text-sm text-gray-600 mt-1">{customer.license_number}</p>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="border-t px-6 py-4">
            <div className="flex justify-end space-x-3">
              <button
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Close
              </button>
              <button className="px-4 py-2 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md hover:bg-green-700">
                Edit Customer
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerDetailDrawer;

