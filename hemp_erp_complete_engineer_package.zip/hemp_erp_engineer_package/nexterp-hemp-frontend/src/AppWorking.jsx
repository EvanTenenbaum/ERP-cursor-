import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import MinimalTest from './MinimalTest.jsx';
import FoundationTestFixed from './test/FoundationTestFixed.jsx';

// Simple Layout Component
const SimpleLayout = ({ children }) => {
  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f8f9fa' }}>
      <nav style={{ 
        backgroundColor: '#2563eb', 
        color: 'white', 
        padding: '1rem',
        marginBottom: '2rem'
      }}>
        <h1 style={{ margin: 0, fontSize: '1.5rem' }}>Hemp ERP System</h1>
        <div style={{ marginTop: '0.5rem' }}>
          <a href="/" style={{ color: 'white', marginRight: '1rem', textDecoration: 'none' }}>Home</a>
          <a href="/foundation-test-fixed" style={{ color: 'white', marginRight: '1rem', textDecoration: 'none' }}>Foundation Test</a>
          <a href="/enhanced-payables" style={{ color: 'white', marginRight: '1rem', textDecoration: 'none' }}>Enhanced Payables</a>
        </div>
      </nav>
      <div style={{ padding: '0 2rem' }}>
        {children}
      </div>
    </div>
  );
};

function AppWorking() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={
          <SimpleLayout>
            <MinimalTest />
          </SimpleLayout>
        } />
        <Route path="/foundation-test-fixed" element={
          <SimpleLayout>
            <FoundationTestFixed />
          </SimpleLayout>
        } />
        <Route path="/enhanced-payables" element={
          <SimpleLayout>
            <div style={{ padding: '2rem', textAlign: 'center' }}>
              <h2>Enhanced Payables</h2>
              <p>This feature will be restored after foundation testing is complete.</p>
            </div>
          </SimpleLayout>
        } />
      </Routes>
    </Router>
  );
}

export default AppWorking;

