const http = require('http');
const httpProxy = require('http-proxy');

// Create a proxy server with custom application logic
const proxy = httpProxy.createProxyServer({});

// Create your custom server and just tell node-http-proxy
// to proxy requests to a different server
const server = http.createServer(function(req, res) {
  // Set CORS headers to allow all origins
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  
  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  // Modify the request to make it look like it's coming from localhost
  req.headers.host = 'localhost:5176';
  req.headers.origin = 'http://localhost:5176';
  
  // Proxy the request to the Vite dev server
  proxy.web(req, res, {
    target: 'http://localhost:5176',
    changeOrigin: true,
    secure: false,
    ws: true, // Enable WebSocket proxying for HMR
    headers: {
      'Host': 'localhost:5176',
      'Origin': 'http://localhost:5176'
    }
  });
});

// Handle WebSocket connections for HMR
server.on('upgrade', function (req, socket, head) {
  req.headers.host = 'localhost:5176';
  req.headers.origin = 'http://localhost:5176';
  
  proxy.ws(req, socket, head, {
    target: 'ws://localhost:5176',
    changeOrigin: true,
    ws: true
  });
});

// Handle proxy errors
proxy.on('error', function (err, req, res) {
  console.error('Proxy error:', err);
  if (res && !res.headersSent) {
    res.writeHead(500, {
      'Content-Type': 'text/plain'
    });
    res.end('Proxy error: ' + err.message);
  }
});

// Start the proxy server on port 5178
const PORT = 5178;
server.listen(PORT, '0.0.0.0', function() {
  console.log(`🚀 Proxy server running on http://0.0.0.0:${PORT}`);
  console.log(`🔗 External access: Use port ${PORT} instead of 5176`);
  console.log(`📡 Proxying to Vite dev server at http://localhost:5176`);
});

