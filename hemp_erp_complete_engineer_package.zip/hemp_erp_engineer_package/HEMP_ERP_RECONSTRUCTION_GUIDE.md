# 🔧 **HEMP ERP SYSTEM RECONSTRUCTION GUIDE**

## **📋 OVERVIEW**

This guide explains how to reconstruct the complete Hemp ERP system from individual files provided to an AI reviewer.

## **🗂️ DIRECTORY STRUCTURE TO CREATE**

### **Frontend Structure (nexterp-hemp-frontend/)**
```
nexterp-hemp-frontend/
├── package.json
├── vite.config.js
├── tailwind.config.js
├── eslint.config.js
├── jsconfig.json
├── components.json
├── index.html
├── .env.development
├── .env.production
├── serve-production.cjs
├── proxy-server.cjs
├── API_DOCUMENTATION.md
├── SECURITY.md
├── public/
│   └── favicon.ico
├── dist/
│   ├── index.html
│   └── assets/
│       └── index-B77CyGlb.js
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── App.css
    ├── AppMinimal.jsx
    ├── AppSimple.jsx
    ├── AppWorking.jsx
    ├── MinimalTest.jsx
    ├── assets/
    │   └── react.svg
    ├── components/
    │   ├── SimpleLayout.jsx
    │   ├── Layout.jsx
    │   ├── DataTable.jsx
    │   ├── PaginatedTable.jsx
    │   ├── RecordDrawer.jsx
    │   ├── CustomerDetailDrawer.jsx
    │   ├── StreamlinedSalesModal.jsx
    │   ├── CompanyTypeSelect.jsx
    │   ├── ProductCategorySelect.jsx
    │   ├── StrainAutocomplete.jsx
    │   ├── FoundationTestWithFallback.jsx
    │   ├── ProxyFoundationTest.jsx
    │   ├── RealFoundationTest.jsx
    │   ├── RealFoundationTestFixed.jsx
    │   ├── auth/
    │   │   ├── AuthProvider.jsx
    │   │   ├── LoginForm.jsx
    │   │   ├── LoginFormFixed.jsx
    │   │   └── LoginFormDirect.jsx
    │   ├── customers/
    │   │   ├── CustomerForm.jsx
    │   │   └── CustomerList.jsx
    │   ├── inventory/
    │   │   └── InventoryList.jsx
    │   └── ui/
    │       ├── accordion.jsx
    │       ├── alert-dialog.jsx
    │       ├── alert.jsx
    │       ├── aspect-ratio.jsx
    │       ├── avatar.jsx
    │       ├── badge.jsx
    │       ├── breadcrumb.jsx
    │       ├── button.jsx
    │       ├── calendar.jsx
    │       ├── card.jsx
    │       ├── carousel.jsx
    │       ├── chart.jsx
    │       ├── checkbox.jsx
    │       ├── collapsible.jsx
    │       ├── command.jsx
    │       ├── context-menu.jsx
    │       ├── dialog.jsx
    │       ├── drawer.jsx
    │       ├── dropdown-menu.jsx
    │       ├── form.jsx
    │       ├── hover-card.jsx
    │       ├── input-otp.jsx
    │       ├── input.jsx
    │       ├── label.jsx
    │       ├── menubar.jsx
    │       ├── navigation-menu.jsx
    │       ├── pagination.jsx
    │       ├── popover.jsx
    │       ├── progress.jsx
    │       ├── radio-group.jsx
    │       ├── resizable.jsx
    │       ├── scroll-area.jsx
    │       ├── select.jsx
    │       ├── separator.jsx
    │       ├── sheet.jsx
    │       ├── sidebar.jsx
    │       ├── skeleton.jsx
    │       ├── slider.jsx
    │       ├── sonner.jsx
    │       ├── switch.jsx
    │       ├── table.jsx
    │       ├── tabs.jsx
    │       ├── textarea.jsx
    │       ├── toast.jsx
    │       ├── toaster.jsx
    │       └── tooltip.jsx
    ├── lib/
    │   ├── nexterp-api.js
    │   ├── utils.js
    │   └── pageFactory.jsx
    ├── pages/
    │   ├── TestPage.jsx
    │   ├── CustomerWorkspacePage.jsx
    │   ├── StreamlinedSalesPage.jsx
    │   ├── DebtManagementPage.jsx
    │   ├── InteractionsPage.jsx
    │   ├── InventoryManagementPage.jsx
    │   ├── ReportingDashboardPage.jsx
    │   ├── EnhancedPayablesWorking.jsx
    │   ├── CustomersPage.jsx
    │   ├── VendorsPage.jsx
    │   ├── OrdersPage.jsx
    │   ├── InventoryPage.jsx
    │   ├── AccountingPage.jsx
    │   ├── IntakePage.jsx
    │   ├── SettingsPage.jsx
    │   ├── VendorPortalPage.jsx
    │   └── accounting/
    │       ├── InvoicesPage.jsx
    │       ├── BillsPage.jsx
    │       ├── PaymentsPage.jsx
    │       ├── CreditNotesPage.jsx
    │       ├── ChartOfAccountsPage.jsx
    │       ├── JournalEntriesPage.jsx
    │       ├── LedgersPage.jsx
    │       ├── BanksPage.jsx
    │       └── ReconcilePage.jsx
    ├── test/
    │   ├── FoundationTest.jsx
    │   └── FoundationTestFixed.jsx
    └── transformers/
        └── DataTransformers.js
```

### **Backend Structure (nexterp-proxy/)**
```
nexterp-proxy/
├── requirements.txt
├── gunicorn.conf.py
├── .env
├── .env.production
└── src/
    ├── main.py
    └── routes/
        ├── auth.py
        └── nexterp.py
```

### **Templates Structure (templates/)**
```
templates/
├── cors-config-template.js
├── nexterp-integration-template.py
├── auth-flow-template.jsx
└── development-checklist.md
```

## **🔧 RECONSTRUCTION STEPS**

### **Step 1: Create Directory Structure**
```bash
# Create main directories
mkdir -p nexterp-hemp-frontend/src/{components/{ui,auth,customers,inventory},pages/accounting,lib,test,transformers,assets,dist/assets}
mkdir -p nexterp-hemp-frontend/public
mkdir -p nexterp-proxy/src/routes
mkdir -p templates

# Create empty directories that might be needed
mkdir -p nexterp-hemp-frontend/node_modules
```

### **Step 2: Place Files According to Naming Convention**

**Frontend Files (FRONTEND_*):**
- `FRONTEND_package.json` → `nexterp-hemp-frontend/package.json`
- `FRONTEND_src_App.jsx` → `nexterp-hemp-frontend/src/App.jsx`
- `FRONTEND_src_components_ui_button.jsx` → `nexterp-hemp-frontend/src/components/ui/button.jsx`
- And so on...

**Backend Files (BACKEND_*):**
- `BACKEND_src_main.py` → `nexterp-proxy/src/main.py`
- `BACKEND_requirements.txt` → `nexterp-proxy/requirements.txt`
- And so on...

**Template Files (TEMPLATE_*):**
- `TEMPLATE_cors-config-template.js` → `templates/cors-config-template.js`
- And so on...

### **Step 3: File Naming Convention Decoder**

**Pattern**: `PREFIX_path_with_underscores.extension`
- Replace underscores with forward slashes
- Remove the prefix
- Place in appropriate directory

**Examples**:
```bash
FRONTEND_src_components_ui_button.jsx → src/components/ui/button.jsx
BACKEND_src_routes_auth.py → src/routes/auth.py
TEMPLATE_cors-config-template.js → cors-config-template.js
```

### **Step 4: Set Permissions and Environment**
```bash
# Make scripts executable
chmod +x nexterp-hemp-frontend/serve-production.cjs
chmod +x nexterp-hemp-frontend/proxy-server.cjs

# Set up environment files
cp nexterp-hemp-frontend/.env.development nexterp-hemp-frontend/.env
cp nexterp-proxy/.env.production nexterp-proxy/.env
```

## **🚀 QUICK SETUP SCRIPT**

```bash
#!/bin/bash
# Hemp ERP Reconstruction Script

# Create directory structure
mkdir -p nexterp-hemp-frontend/src/{components/{ui,auth,customers,inventory},pages/accounting,lib,test,transformers,assets,dist/assets}
mkdir -p nexterp-hemp-frontend/public
mkdir -p nexterp-proxy/src/routes
mkdir -p templates

# Function to place files
place_file() {
    local file="$1"
    local prefix="${file%%_*}"
    local path="${file#*_}"
    local target_path="${path//_//}"
    
    case "$prefix" in
        "FRONTEND")
            cp "$file" "nexterp-hemp-frontend/$target_path"
            ;;
        "BACKEND")
            cp "$file" "nexterp-proxy/$target_path"
            ;;
        "TEMPLATE")
            cp "$file" "templates/$target_path"
            ;;
        "DOC")
            cp "$file" "$target_path"
            ;;
    esac
}

# Process all files
for file in *_*; do
    if [ -f "$file" ]; then
        place_file "$file"
    fi
done

# Set permissions
chmod +x nexterp-hemp-frontend/serve-production.cjs 2>/dev/null
chmod +x nexterp-hemp-frontend/proxy-server.cjs 2>/dev/null

echo "Hemp ERP system reconstructed successfully!"
```

## **🔍 VERIFICATION STEPS**

### **1. Check Directory Structure**
```bash
tree nexterp-hemp-frontend -I node_modules
tree nexterp-proxy
tree templates
```

### **2. Verify Key Files**
```bash
# Frontend
ls nexterp-hemp-frontend/src/App.jsx
ls nexterp-hemp-frontend/package.json
ls nexterp-hemp-frontend/src/components/ui/button.jsx

# Backend
ls nexterp-proxy/src/main.py
ls nexterp-proxy/requirements.txt
ls nexterp-proxy/src/routes/auth.py
```

### **3. Test Setup**
```bash
# Backend
cd nexterp-proxy
pip install -r requirements.txt
python src/main.py

# Frontend (new terminal)
cd nexterp-hemp-frontend
npm install
npm run dev
```

## **📋 EXPECTED RESULTS**

After reconstruction:
- **Frontend**: React app should start on `http://localhost:5176`
- **Backend**: Flask API should start on `http://localhost:5000`
- **Integration**: Frontend should connect to backend successfully
- **Features**: All Hemp ERP features should be functional

## **🚨 TROUBLESHOOTING**

### **Missing Files**
- Check file naming convention
- Verify all prefixed files are present
- Ensure no special characters in filenames

### **Permission Issues**
```bash
chmod -R 755 nexterp-hemp-frontend/
chmod -R 755 nexterp-proxy/
```

### **Environment Issues**
- Copy `.env.development` to `.env` for local development
- Update API URLs if needed
- Check NextERP credentials

---

**This guide ensures the complete Hemp ERP system can be reconstructed from individual files provided to an AI reviewer.**

